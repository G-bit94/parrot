function calculateKeywordDensity(content, keyword) {
	keyword = keyword.toLowerCase().trim();
	content = content.toLowerCase().replace(/<\/?[^>]+(>|$)/g, ""); // Strip HTML tags
	const wordCount = content.split(/\s+/).length;
	const keywordCount = content.split(keyword).length - 1;
	if (wordCount === 0) {
		return 0;
	}
	const density = (keywordCount / wordCount) * 100;
	return parseFloat(density.toFixed(2));
}

document.addEventListener("DOMContentLoaded", function() {
	var titleInput = document.getElementById("custom_meta_title");

	if (titleInput === null) return false;

    var descriptionInput = document.getElementById("custom_meta_description");
    var previewTitle = document.querySelector(".serp-preview-title");
    var previewDescription = document.querySelector(".serp-preview-description");
    titleInput.addEventListener("input", function() {
        var titleValue = titleInput.value.trim();
    	previewTitle.textContent = titleValue.length > 0 ? titleValue : "Page Title";
	});
	descriptionInput.addEventListener("input", function() {
    	var descriptionValue = descriptionInput.value.trim();
        previewDescription.textContent = descriptionValue.length > 0 ? descriptionValue : "Page description will appear here";
    });
	for (let index = 1; index <= 6; index++) {
		let el = document.getElementById("div_h" + index + "_heading");
		if (document.getElementById("div_h" + index + "_heading")) {
        	el.addEventListener("click", function() {
				if (this.classList.contains("heading_open")) {
                	this.classList.remove("heading_open");
                    this.classList.add("heading_closed");
                    this.querySelector("div > p").classList.remove("heading_open");
                    this.querySelector("div > p").classList.add("heading_closed");
				}
                else {
                    this.classList.remove("heading_closed");
					this.classList.add("heading_open");
                    this.querySelector("div > p").classList.remove("heading_closed");
                    this.querySelector("div > p").classList.add("heading_open");
				}
			});
		}
	}
	
	let tab_links = document.querySelectorAll('.nav-tab-wrapper a');
	tab_links.forEach(function(link) {
    	link.addEventListener('click', function(event) {
      		event.preventDefault();
      		let target = this.getAttribute('href');

      		// Remove active class from all tab links
      		tab_links.forEach(function(tab_link) {
        		tab_link.classList.remove('nav-tab-active');
      		});

      		// Hide all tab content
      		let tab_contents = document.querySelectorAll('.tab-content');
      		tab_contents.forEach(function(tab_content) {
        		tab_content.style.display = 'none';
      		});
			
      		// Show the clicked tab content
			if (target == '#seo-signals') {
				document.querySelector(target).style.display = 'flex';
			}
			else {
				document.querySelector(target).style.display = 'block';
			}
      		
      		// Add active class to the clicked tab link
      		this.classList.add('nav-tab-active');
		});
  	});
	
});

jQuery( document ).ready( function( $ ) {

	var custom_uploader;

	$( '.remove-image' ).on( 'click', function( e ) {
		var object_id = $( this ).data( 'id' );
		var $input_object = $( '#'+object_id );

		$input_object.val( '' );
		$( '#'+object_id+'-preview .image' ).html( '' );
		$( this ).hide( 0 );
	} );

	$( '.upload-image' ).on( 'click', function( e ) {
		e.preventDefault();

		var object_id = $( this ).data( 'id' );
		var $input_object = $( '#'+object_id );
		var $remove_button = $( this ).next();

		if ( custom_uploader ) {
			custom_uploader.open();
			return;
		}

		custom_uploader = wp.media.frames.file_frame = wp.media( {
			title: og_image.title,
			button: {
				text: og_image.button
			},
			multiple: false
		} );

		custom_uploader.on( 'select', function() {
			attachment = custom_uploader.state().get( 'selection' ).first().toJSON();

			var image_url = attachment.url;

			if( attachment.sizes.medium !== undefined ){
				image_url = attachment.sizes.medium.url;
			}

			$input_object.val( attachment.id );
			$( '#'+object_id+'-preview .image' ).html( '<img src="'+image_url+'" alt="">' );
			$remove_button.show( 0 );
		} );

		custom_uploader.open();
	} );

	$( '#custom_meta_og_image_button' ).on( 'click', function( e ) {
		e.preventDefault();

		if ( custom_uploader ) {
			custom_uploader.open();
			return;
		}

		custom_uploader = wp.media.frames.file_frame = wp.media( {
			title: og_image.title,
			button: {
				text: og_image.button
			},
			multiple: false
		} );

		custom_uploader.on( 'select', function() {
			attachment = custom_uploader.state().get( 'selection' ).first().toJSON();
            $("#custom_meta_og_image").val( attachment.url );
		} );

		custom_uploader.open();
	} );

	$( '.color-picker' ).wpColorPicker();
	
	$( 'select.styled-select, select.select2' ).select2();

	if ($('#redirects-table').length > 0) {
		$(document).on('change', '#redirects-table select[name="type"]', function () {
			var value = $(this).val();

			$(this).parent().find('[name^="to_"]').hide(0).removeAttr('required');
			$(this).parent().find('[name="to_' + value + '"]').show(0).attr('required', 'required');
		});

		$(document).on('submit', '#redirects-table form', function (e) {
			e.preventDefault();

			var $this = $(this);
			var is_404_table = $('#redirects-table').hasClass('redirects-table-404');

			if ($this.find('.action').hasClass('update')) {
				$this.find('.action.update').addClass('spin');
			}

			$.ajax({
				type: 'POST',
				data: {
					redirect_action: 'save_redirect',
					payload: $this.serializeArray()
				}
			}).done(function (response) {
				if (response.success) {
					if (is_404_table) {
						$this.find('.action.save span').toggleClass('dashicons-yes-alt dashicons-saved');

						setTimeout(function () {
							$this.closest('tr').remove();

							if ($('#redirects-table > tbody > tr').length < 2) {
								$('.tab-content > *').hide(0);
								$('.tab-content > .no-results').show(0);
							}
						}, 1200);
					} else {
						if (response.id) {
							$this.find('.action.save span').toggleClass('dashicons-yes-alt dashicons-update').parent().next().show(0);
							$this.append('<input type="hidden" name="redirect_id" value="' + response.id + '">');

							var template = $('#redirect-template').clone().html();

							$('#redirects-table tr').first().after('<tr><td colspan="6">' + template + '</td></tr>');
						} else {
							$this.find('.action.update').removeClass('spin');
							$this.find('.action.save span').toggleClass('dashicons-saved dashicons-update');
							setTimeout(function () {
								$this.find('.action.save span').toggleClass('dashicons-saved dashicons-update');
							}, 1200);
						}
					}
				} else {
					alert(response.message);
				}
			});
		});

		$('a.add-row').on('click', function (e) {
			e.preventDefault();

			var template = $('#redirect-template').clone().html();

			$('#redirects-table tr').first().after('<tr><td colspan="6">' + template + '</td></tr>');
		});

		$(document).on('click', 'a.action', function () {
			var $this = $(this);
			var action = $this.data('action');

			var confirmation = $this.data('confirm');
			if (typeof confirmation !== 'undefined') {
				if (!confirm(confirmation)) {
					return;
				}
			}

			var form = $this.closest('form');
			var is_404_table = $('#redirects-table').hasClass('redirects-table-404');

			var redirect_id = form.find('[name="redirect_id"]').val();

			form.closest('tr').remove();

			$.ajax({
				type: 'POST',
				data: {
					redirect_action: action + '_redirect',
					payload: redirect_id
				}
			}).done(function (response) {
				if (response.success) {
					form.closest('tr').remove();

					if (is_404_table && $('#redirects-table > tbody > tr').length < 2) {
						$('.tab-content > *').hide(0);
						$('.tab-content > .no-results').show(0);
					}
				} else {
					alert(response.message);
				}
			});
		});
	}

	$('a.zynith-button.purge').on('click', function (e) {
		var $this = $(this);
		e.preventDefault();

		$this.prop('disabled', true);

		var confirmation = $this.data('confirm');
		if (typeof confirmation !== 'undefined') {
			if (!confirm(confirmation)) {
				$this.prop('disabled', false);
				return;
			}
		}

		var input = $this.prev('input');
		var option = input.attr( 'name' );

		$.ajax({
			type: 'POST',
			data: {
				action: 'purge-option',
				option: option
			}
		}).done(function (response) {
			if (response.success) {
				input.val('');
				$this.remove();
			} else {
				alert(response.message);
			}
		});
	});
    
    // Function to update keyword density live
    function updateKeywordDensity() {
        const content = $("#content").val();
        const targetKeyword = $("#custom_target_keyword").val();
        const keywordDensity = calculateKeywordDensity(content, targetKeyword);

        $("#p_density").text("Keyword Density: " + keywordDensity + "%");
    }

    $("#content, #custom_target_keyword").on("input", updateKeywordDensity);
	
} );