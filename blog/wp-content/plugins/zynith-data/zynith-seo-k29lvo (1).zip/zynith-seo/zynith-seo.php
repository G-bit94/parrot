<?php
/**
 * Plugin Name: Z Y N I T H
 * Plugin URI: https://zynith.app/
 * Description: Your one-stop plugin for elevating search engine rankings, driving traffic, and boosting conversions with streamlined on-page optimization tools and automatic sitemap updates!
 * Version: 3.0.0
 * Author: Google SEO Mastermind
 * Author URI: https://www.facebook.com/groups/368478557332648
 * License: GPL-3.0
 * License URI: https://www.gnu.org/licenses/gpl-3.0.html
 * Donate link: https://www.paypal.com/donate/?hosted_button_id=XVXQ3RX7N4SQN
 * Contributors: Schieler Mew, Kellie Watson, Daniel Nielsen
 * Tags: plugin, WordPress, SEO, search engine optimization, meta tags, XML sitemap, breadcrumbs, schema markup
 * Support: https://www.facebook.com/groups/761871078859984
 * Warning: Touching the plugin source code could lead to catastrophic failure!
 */

/*`....... `..     `..      `..     `...     `..     `..     `... `......     `..     `..
       `..        `..    `..      `. `..   `..     `..          `..         `..     `..
      `..          `.. `..        `.. `..  `..     `..          `..         `..     `..
    `..              `..          `..  `.. `..     `..          `..         `...... `..
   `..               `..          `..   `. `..     `..          `..         `..     `..
 `..                 `..          `..    `. ..     `..          `..         `..     `..
`...........         `..          `..      `..     `..          `..         `..     `..
                                                                                       */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'ZYNITH_SEO_FILE', __FILE__ );
define( 'ZYNITH_SEO_SLUG', plugin_basename( __DIR__ ) );
define( 'ZYNITH_SEO_NAME', 'Z Y N I T H' );
//define( 'ZYNITH_SEO_VERSION', '3.0.0' );
define( 'ZYNITH_SEO_VERSION', time() );
define( 'ZYNITH_SEO_UPDATE_URL', 'https://zynith.app/wp-json/zynith/v1/update-info/' ); // Change to the actual update URL
define( 'ZYNITH_SEO_TEXT_DOMAIN', 'zynith-seo' );
define('ZYNITH_SEO_PLUGIN_URI', 'https://zynith.app/');
define( 'ZYNITH_SEO_IS_WOOCOMMERCE', (bool) class_exists( 'WooCommerce' ) );

// Load language early
load_plugin_textdomain( ZYNITH_SEO_TEXT_DOMAIN, false, dirname( plugin_basename( __FILE__ ) ) . '/lang/' );

// Initialize Plugin
require_once( __DIR__ . '/includes/init.php' );

// Add plugin action links
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'zynith_seo_action_links' );
function zynith_seo_action_links( $links ) {
	$links[] = '<a href="' . esc_url( admin_url( 'admin.php?page=zynith-seo-settings' ) ) . '">' . __( 'Settings', ZYNITH_SEO_TEXT_DOMAIN ) . '</a>';
	
	return $links;
}

// Add plugin meta links
add_filter( 'plugin_row_meta' , 'zynith_seo_meta_links', 10, 2 );
function zynith_seo_meta_links( $plugin_meta, $plugin_file ) {
	if ( $plugin_file === plugin_basename( ZYNITH_SEO_FILE ) ) {
		$plugin_version_style = 'display: inline-block; margin: 0 11px 0 0; padding: 6px 10px;
			background-color: #313131; border: rgba(128,128,128,0.4) solid 1px; border-radius: 5px;
			box-shadow: -2px -2px 3px rgba(255, 255, 255, 1), -2px -2px 3px rgba(255, 255, 255, 1), 2px 2px 3px rgba(0, 0, 0, 0.3), 2px 2px 3px rgba(0, 0, 0, 0.2);
			color: #f1f1f1; letter-spacing: 0.1em; outline: none;
			cursor: default;';
		$author_link_style = 'display: inline-block; padding: 6px 10px;
			background-image: linear-gradient(to right, #0476e6, #ff09ff); border: rgba(128,128,128,0.4) solid 1px; border-radius: 5px;
			box-shadow: -2px -2px 3px rgba(255, 255, 255, 1), -2px -2px 3px rgba(255, 255, 255, 1), 2px 2px 3px rgba(0, 0, 0, 0.3), 2px 2px 3px rgba(0, 0, 0, 0.2);
			color: #fff; letter-spacing: 0.1em; text-decoration: none; outline: none; ';
		$plugin_meta = [
			'<span style="' . esc_attr($plugin_version_style) . '">' . __('Version', ZYNITH_SEO_TEXT_DOMAIN) . ' ' . ZYNITH_SEO_VERSION . '</span>' .
			'<a href="' . ZYNITH_SEO_PLUGIN_URI . '" target="_blank" style="' . esc_attr($author_link_style) . '"><span class="dashicons dashicons-external"></span> ' . __(ZYNITH_SEO_NAME, ZYNITH_SEO_TEXT_DOMAIN) . '</a>'
		];
	}
    return $plugin_meta;
}

// Initialize classes
ZynithSEOUpdater::init();
ZynithSEORedirects::init();
ZynithSEOCategoryBase::init();
ZynithSEOSettings::init();
// ZynithSEOSignalsOverview::init();
ZynithSEOBrokenLinks::init();
ZynithSEOSecurity::init();
ZynithSEOPostTypes::init();
ZynithSEOMetaBoxes::init();
ZynithSEOTaxonomies::init();
ZynithSEOAuthors::init();
ZynithSEOImport::init();
ZynithSEOSitemap::init();
ZynithSEOContent::init();
ZynithSEOBreadcrumbs::init();