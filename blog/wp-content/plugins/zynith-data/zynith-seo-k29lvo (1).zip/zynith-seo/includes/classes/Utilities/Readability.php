<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class ZynithSEOReadability {

    // Flesch-Kincaid grade level function
    public static function flesch_kincaid_grade_level( $content ) {
        $content = wp_strip_all_tags( $content );
        $words = str_word_count( $content );
        $sentences = preg_match_all( '/[.!?]+/', $content, $matches );
        $syllables = self::count_syllables( $content );

        if ($words === 0 || $sentences === 0) {
            return 0;
        }

        $average_words_per_sentence = $words / $sentences;
        $average_syllables_per_word = $syllables / $words;

        return (0.39 * $average_words_per_sentence) + (11.8 * $average_syllables_per_word) - 15.59;
    }

    public static function flesch_kincaid_difficulty( $level ) {
        if ( $level > 12) {
            return __( 'Knowledegable', ZYNITH_SEO_TEXT_DOMAIN );
        }
        
        if ($level >= 6) {
            return __( 'Standard', ZYNITH_SEO_TEXT_DOMAIN );
        }

        return __( 'Basic', ZYNITH_SEO_TEXT_DOMAIN );
    }

    public static function count_syllables( $text ) {
        $text = mb_strtolower( $text );
        $words = preg_split( '/\s+/', $text, -1, PREG_SPLIT_NO_EMPTY );
        $total_syllables = 0;
    
        foreach ( $words as $word ) {
            $total_syllables += self::count_syllables_in_word( $word );
        }
    
        return $total_syllables;
    }
    
    public static function count_syllables_in_word( $word ) {
        $word = preg_replace( '/[^a-z]/', '', $word );
        $syllable_count = 0;
        $vowels = 'aeiouy';
    
        if ( mb_strlen( $word ) > 0 ) {
            if ( mb_stripos( $vowels, $word[0] ) !== false ) {
                $syllable_count++;
            }
    
            for ( $i = 1; $i < mb_strlen( $word ); $i++ ) {
                if ( mb_stripos( $vowels, $word[ $i ] ) !== false && mb_stripos( $vowels, $word[ $i - 1 ] ) === false ) {
                    $syllable_count++;
                }
            }
    
            if ( mb_strlen( $word ) > 1 && $word[ mb_strlen( $word ) - 1 ] == 'e' && $word[ mb_strlen( $word ) - 2 ] != 'l' ) {
                $syllable_count--;
            }
        }
        return max( 1, $syllable_count );
    }

}
