<?php

class ZynithSEOSecurity {
	
	public function __construct() {
		add_action( 'init', [ $this, 'remove_generator_tags' ] );
	}

    public static function init() {
        return new self();
    }

    public function remove_generator_tags() {
        if ( is_admin() ) {
            return;
        }

        $remove_generator = get_option( 'zynith_remove_generator_tags', false );

        if ( $remove_generator ) {
            remove_action( 'wp_head', 'wc_generator' );
            remove_action( 'wp_head', 'wp_generator' );
        }
    }

}
