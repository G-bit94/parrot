<?php

if ( ! function_exists( 'zynith_seo_breadcrumbs' ) ) {
    function zynith_seo_breadcrumbs( $echo = true ) {
        $breadcrumbs = apply_shortcodes( '[zynith-breadcrumbs]' );

        if ( ! $echo ) {
            return $breadcrumbs;
        }

        echo $breadcrumbs;
    }
}
