<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class ZynithSEOSignalsOverview {

    public function __construct() {
        $seo_signals_enabled = get_option( 'zynith_seo_signals_metabox_enabled', true );

        if ( ! $seo_signals_enabled ) {
            return;
        }

        add_action( 'admin_menu', [ $this, 'add_seo_signals_pages' ], 99 );
    }

    public static function init() {
        return new self();
    }

    public function add_seo_signals_pages() {
        add_menu_page(
            esc_html__( 'SEO Signals Overview', ZYNITH_SEO_TEXT_DOMAIN ), // Document Title
            esc_html__( 'SEO Signals', ZYNITH_SEO_TEXT_DOMAIN ), // Menu Title
            'edit_posts', // Capability
            'seo-signals', // Menu Slug
            [ $this, 'add_seo_signals_table' ], // Callback
            'dashicons-chart-pie', // Icon
            95, // Position
        );
    }

    public function add_seo_signals_table() {
        echo '<div class="wrap">
            <h1>' . sprintf( __( 'Zynith SEO Signals Global Overview', ZYNITH_SEO_TEXT_DOMAIN ) ) . '</h1>';
        
            $this->add_tabs();

            $current_tab = filter_input( INPUT_GET, 'tab' );
            $type = filter_input( INPUT_GET, 'type' );
            $items = [];

            if ( empty( $current_tab ) || empty( $type ) ) {
                $tabs = $this->get_tabs();

                foreach ( $tabs as $tab ) {
                    if ( ! empty( $tab['active'] ) ) {
                        $current_tab = $tab['key'];
                        $type = $tab['type'];
                    }
                }
            }
            
            if ( empty( $current_tab ) || empty( $type ) ) {
                echo '<div class="tab-content">
                    <p>' . __( 'We did not find any content here...', ZYNITH_SEO_TEXT_DOMAIN ) . '</p>
                </div>';

                return;
            }

            if ( $type === 'post_type' ) {
                $items = $this->get_post_data( $current_tab );
            }

            if ( $type === 'taxonomy' ) {
                $items = $this->get_term_data( $current_tab );
            }

            if ( $type === 'user' ) {
                $items = $this->get_user_data();
            }
            
            if ( empty( $items ) ) {
                echo '<div class="tab-content">
                    <p>' . __( 'We did not find any content here...', ZYNITH_SEO_TEXT_DOMAIN ) . '</p>
                </div>';

                return;
            }
        
            echo '<div class="tab-content">
                <table id="analysis-table" class="form-table" cellpadding="0" cellspacing="0">
                    <tr>
                        <th>' . __( 'Name/Title', ZYNITH_SEO_TEXT_DOMAIN ) . '</th>
                    </tr>';

                    foreach ( $items as $item ) {
                        // echo '<tr>
                        //     <td data-label="' . __( 'Name/Title', ZYNITH_SEO_TEXT_DOMAIN ) . '"><a href="' . $item['edit_link'] . '">' . $item['name'] . '</a></td>
                        // </tr>';
                    }

                    // echo '<tfoot><tr>
                    //     <th>' . __( 'Overall Average', ZYNITH_SEO_TEXT_DOMAIN ) . '</th>
                    //     <th data-label="' . __( 'SEO Score', ZYNITH_SEO_TEXT_DOMAIN ) . '">' . $average_seo_score . '</th>
                    //     <th data-label="' . __( 'Readability Difficulty', ZYNITH_SEO_TEXT_DOMAIN ) . '">' . $average_readability_difficulty['description'] . ' (' . $average_readability_difficulty['level'] . '/5)</th>
                    //     <th data-label="' . __( 'Estimated Reading Time', ZYNITH_SEO_TEXT_DOMAIN ) . '" colspan="2">' . $average_reading_time . '</th>
                    // </tr></tfoot>';
                    
                echo '</table>
            </div>
        </div>';
    }

    private function get_tabs() {
        $current_tab = filter_input( INPUT_GET, 'tab' );

        $post_types = ZynithSEOPostTypes::get_post_types();
        $taxonomies = ZynithSEOTaxonomies::get_taxonomies();
        
        unset( $taxonomies['product_shipping_class'] );

        $all_tabs = [];
        $i = 1;

        foreach ( $post_types as $post_type => $label ) {
            $all_tabs[] = [
                'key' => $post_type,
                'type' => 'post_type',
                'label' => $label,
                'active' => (bool) ( $current_tab === $post_type || ( empty( $current_tab ) && $i === 1 ) ? true : false ),
            ];

            ++$i;
        }
        
        foreach ( $taxonomies as $taxonomy => $label ) {
            $all_tabs[] = [
                'key' => $taxonomy,
                'type' => 'taxonomy',
                'label' => $label,
                'active' => (bool) ( $current_tab === $taxonomy || ( empty( $current_tab ) && $i === 1 ) ? true : false ),
            ];

            ++$i;
        }

        $all_tabs[] = [
            'key' => 'user',
            'type' => 'user',
            'label' => __( 'Users', ZYNITH_SEO_TEXT_DOMAIN ),
            'active' => (bool) ( $current_tab === 'user' || ( empty( $current_tab ) && $i === 1 ) ? true : false ),
        ];

        return $all_tabs;
    }

    private function add_tabs() {
        $page = filter_input( INPUT_GET, 'page' );
        $all_tabs = $this->get_tabs();
		
		echo '<h2 class="nav-tab-wrapper zynith-tabs">';

        $i = 1;

        foreach ( $all_tabs as $tab ) {
            $tab_key = $tab['key'];
            $type = $tab['type'];
            $label = $tab['label'];
            $current_tab_active = (bool) $tab['active'];

            echo '<a href="' . admin_url( "/admin.php?page=$page&tab=$tab_key&type=$type" ) . '" class="nav-tab' . ( $current_tab_active ? ' nav-tab-active' : '' ) . '">' . $label . '</a>';

            ++$i;
        }
        
		echo '</h2>' . "\n";
    }

    private function get_post_data( $post_type ) {
        $items = [];

        $posts = get_posts( [
            'numberposts' => -1,
            'post_type' => $post_type,
            'post_status' => 'publish',
            'suppress_filters' => 0,
        ] );

        if ( ! empty( $posts ) ) {
            foreach ( $posts as $post ) {
                $items[] = $post;
            }
        }

        return $items;
    }

    private function get_term_data( $taxonomy ) {
        $items = [];

        $terms = get_terms( [
            'taxonomy' => $taxonomy,
            'hide_empty' => false,
        ] );

        if ( ! empty( $terms ) ) {
            foreach ( $terms as $term ) {
                $items[] = $term;
            }
        }

        return $items;
    }

    private function get_user_data() {
        $items = [];

        $users = get_users( [
            'role__in' => [ 'administrator', 'editor', 'author' ]
        ] );

        if ( ! empty( $users ) ) {
            foreach ( $users as $user ) {
                $items[] = $user;
            }
        }

        return $items;
    }

}
