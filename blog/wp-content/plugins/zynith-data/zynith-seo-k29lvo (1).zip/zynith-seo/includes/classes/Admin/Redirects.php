<?php

class ZynithSEORedirects {
	
	public $post_types;
	public $to_fields;
	
	public function __construct() {
		add_action( 'admin_menu', [ $this, 'add_redirect_menus' ], 99 );
		
		add_action( 'template_redirect', [ $this, 'do_redirect' ], 10 );
		add_action( 'template_redirect', [ $this, 'redirect_attachments' ], 15 );
		add_action( 'template_redirect', [ $this, 'redirect_to_lowercase' ], 20 );
		add_action( 'template_redirect', [ $this, 'log_404s' ], 25 );
		
		add_action( 'admin_init', [ $this, 'pre_render_post_types' ], 0 );
		add_action( 'admin_init', [ $this, 'create_redirects_table' ], 0 );
		add_action( 'admin_init', [ $this, 'manage_redirects' ], 0 );
		
		add_action( 'admin_notices', [ $this, 'redirect_notice' ] );
	}

    public static function init() {
        return new self();
    }
	
	public function redirect_notice() {
		if ( ! empty( $_SESSION['redirect_notice'] ) ) {
			echo '<div class="updated">
				<p>' . $_SESSION['redirect_notice'] . '</p>
			</div>';
			
			unset( $_SESSION['redirect_notice'] );
		}
	}
	
	public function pre_render_post_types() {
		$this->post_types = ZynithSEOPostTypes::get_post_types();
	}
	
	public function manage_redirects() {
		$action = filter_input( INPUT_POST, 'redirect_action' );
		
		if ( empty( $action ) ) {
			return;
		}
		
		global $wpdb;
		
		if ( $action === 'save_settings' ) {
			if ( ! wp_verify_nonce( $_POST['redirect-settings-nonce'], 'save-redirect-settings' ) ) {
				wp_die( __( "Something didn't add up. Please try again", ZYNITH_SEO_TEXT_DOMAIN ) );
			}
			
			$settings = $_POST['zynith_redirect_settings'] ?? [];
			
			if ( ! isset( $settings['confirm_delete'] ) ) {
				$settings['confirm_delete'] = 0;
			}
			
			if ( ! isset( $settings['redirect_attachments'] ) ) {
				$settings['redirect_attachments'] = 0;
			}
			
			if ( ! isset( $settings['force_lowercase'] ) ) {
				$settings['force_lowercase'] = 0;
			}
			
			update_option( 'zynith_redirect_settings', $settings );
			
			$_SESSION['redirect_notice'] = __( 'Settings Saved', ZYNITH_SEO_TEXT_DOMAIN );
		}
		
		if ( $action === 'save_redirect' ) {
			$payload = [];
			$this_type = '';

			foreach ( $_POST['payload'] as $field ) {
				$name = $field['name'];
				$value = htmlspecialchars( trim( $field['value'] ) );

				if ( $name === 'type' ) {
					$this_type = $value;
				}

				if ( strpos( $name, 'to_' ) !== false ) {
					if ( $name !== 'to_' . $this_type ) {
						continue;
					}

					$name = 'to';
				}

				$payload[ $name ] = $value;
			}

			$http = $payload['http'];
			$from = ltrim( str_replace( home_url(), '', $payload['from'] ), '/' );
			$type = $payload['type'];
			$to = $payload['to'];
			$active = intval( (bool) ( $payload['active'] ?? false ) );
			$update = intval( $payload['redirect_id'] ?? 0 );

			$query = "INSERT INTO `{$wpdb->base_prefix}zynith_redirects` (`http`, `from`, `type`, `to`, `active`) VALUES (%d, %s, %s, %s, %d) ON DUPLICATE KEY UPDATE `http` = %d, `type` = %s, `to` = %s, `active` = %d";
			$prepare = $wpdb->prepare( $query, $http, $from, $type, $to, $active, $http, $type, $to, $active );
			$wpdb->query( $prepare );

			if ( ! empty( $wpdb->last_error ) ) {
				wp_send_json( [ 'error' => 1, 'message' => $wpdb->last_result ] );
			}

			wp_send_json( [ 'success' => 1, 'id' => $update ? 0 : $wpdb->insert_id ] );
		}
		
		if ( $action === 'delete_redirect' ) {
			$redirect_id = filter_input( INPUT_POST, 'payload' );
			
			$query = "DELETE FROM `{$wpdb->base_prefix}zynith_redirects` WHERE `id` = %d";
			$prepare = $wpdb->prepare( $query, $redirect_id );
			$wpdb->query( $prepare );

			if ( ! empty( $wpdb->last_error ) ) {
				wp_send_json( [ 'error' => 1, 'message' => $wpdb->last_result ] );
			}

			wp_send_json( [ 'success' => 1, 'id' => $redirect_id ] );
		}
		
		if ( $action === 'ignore_redirect' ) {
			$redirect_id = filter_input( INPUT_POST, 'payload' );
			
			$query = "UPDATE `{$wpdb->base_prefix}zynith_redirects` SET `ignored` = 1 WHERE `id` = %d";
			$prepare = $wpdb->prepare( $query, $redirect_id );
			$wpdb->query( $prepare );

			if ( ! empty( $wpdb->last_error ) ) {
				wp_send_json( [ 'error' => 1, 'message' => $wpdb->last_result ] );
			}

			wp_send_json( [ 'success' => 1, 'id' => $redirect_id ] );
		}
	}
	
	public function add_redirect_menus() {
		// add_menu_page( __( 'Redirect Manager', ZYNITH_SEO_TEXT_DOMAIN ), __( 'Redirect Manager', ZYNITH_SEO_TEXT_DOMAIN ), 'manage_options', 'zynith-redirects', [ $this, 'render_zynith_redirect_page' ], 'dashicons-randomize	', 89 );
		// add_submenu_page( 'zynith-redirects', __( '404 errors', ZYNITH_SEO_TEXT_DOMAIN ), __( '404 errors', ZYNITH_SEO_TEXT_DOMAIN ), 'manage_options', 'zynith-redirects-404', [ $this, 'render_zynith_404_page' ] );
		// add_submenu_page( 'zynith-redirects', __( 'Redirect Settings', ZYNITH_SEO_TEXT_DOMAIN ), __( 'Settings', ZYNITH_SEO_TEXT_DOMAIN ), 'manage_options', 'zynith-redirects-settings', [ $this, 'render_zynith_redirect_settings' ] );
		add_submenu_page( 'zynith-seo-settings', __( 'Redirect Manager', ZYNITH_SEO_TEXT_DOMAIN ), __( 'Redirect Manager', ZYNITH_SEO_TEXT_DOMAIN ), 'manage_options', 'zynith-redirects', [ $this, 'render_zynith_redirect_page' ] );
		add_submenu_page( 'zynith-seo-settings', __( '404 errors', ZYNITH_SEO_TEXT_DOMAIN ), __( '404 Manager', ZYNITH_SEO_TEXT_DOMAIN ), 'manage_options', 'zynith-redirects-404', [ $this, 'render_zynith_404_page' ] );
		add_submenu_page( 'zynith-seo-settings', __( 'Redirect Settings', ZYNITH_SEO_TEXT_DOMAIN ), __( 'Redirect Settings', ZYNITH_SEO_TEXT_DOMAIN ), 'manage_options', 'zynith-redirects-settings', [ $this, 'render_zynith_redirect_settings' ] );
	}
	
	public function post_type_options( $selected = '' ) {
		global $wpdb;
		
		$post_type_options = '<option value="url">' . __( 'Custom URL', ZYNITH_SEO_TEXT_DOMAIN ) . '</option>' . "\n";
		
		foreach ( $this->post_types as $post_type => $post_type_label ) {
			$post_type_has_content = (bool) ! empty( $wpdb->get_var( "SELECT `ID` FROM `{$wpdb->base_prefix}posts` WHERE `post_type` = '{$post_type}' AND `post_status` = 'publish' LIMIT 1" ) );
			
			if ( ! $post_type_has_content ) {
				continue;
			}
			
			$post_type_options .= '<option value="' . $post_type . '"' . ( $selected === $post_type ? ' selected' : '' ) . '>' . $post_type_label . '</option>' . "\n";
		}
		
		return $post_type_options;
	}
	
	public function post_type_fields( $selected = '' ) {
		$post_type_fields = '<input type="text" name="to_url"' . ( is_numeric( $selected ) ? ' style="display: none;"' : ' value="' . $selected . '" required="required"' ) . '>' . "\n";
		
		foreach ( $this->post_types as $post_type => $post_type_label ) {
			$pages = $this->dropdown_pages( [ 'post_type' => $post_type ] );
			
			if ( empty( $pages ) ) {
				continue;
			}
			
			$post_type_fields_options = '';
			$is_visible = false;
			
			foreach ( $pages as $post_id => $post_title ) {
				$this_selected = is_numeric( $selected ) && $selected == $post_id ? ' selected' : '';
				$post_type_fields_options .= '<option value="' . $post_id . '"' . $this_selected . '>' . $post_title . '</option>' . "\n";
				
				if ( ! empty( $this_selected ) ) {
					$is_visible = true;
				}
			}
			
			$post_type_fields .= '<select name="to_' . $post_type . '"' . ( ! $is_visible ? ' style="display: none;"' : ' required="required"' ) . '>' . "\n";
			$post_type_fields .= $post_type_fields_options;
			$post_type_fields .= '</select>' . "\n";
		}
		
		return $post_type_fields;
	}
	
	public function render_zynith_redirect_page() {
		global $wpdb;
		
		$home_url = trailingslashit( home_url() );
		if ( strlen( $home_url ) > 15 ) {
			$home_url = rtrim( substr( $home_url, 0, 10 ), '.' ) . '.../';
		}
		
		$redirect_settings = get_option( 'zynith_redirect_settings', [] );
		$confirm_delete = (bool) ( $redirect_settings['confirm_delete'] ?? true );
		
		echo '<div class="wrap">
			<h1>' . __( 'Zynith SEO Redirect Manager', ZYNITH_SEO_TEXT_DOMAIN ) . '</h1>';

			$this->add_tabs();

			echo '<div id="redirect-template" style="display: none !important;">
				<form method="post" action="" novalidate="novalidate">
					<table class="form-table" cellpadding="0" cellspacing="0"><tr>
						<td data-label="' . __( 'HTTP', ZYNITH_SEO_TEXT_DOMAIN ) . '"><select name="http">
							<option value="301">301 ' . __( 'Permanent', ZYNITH_SEO_TEXT_DOMAIN ) . '</option>
							<option value="302">302 ' . __( 'Temporary', ZYNITH_SEO_TEXT_DOMAIN ) . '</option>
						</select></td>
						<td data-label="' . __( 'From', ZYNITH_SEO_TEXT_DOMAIN ) . '"><input type="text" value="' . $home_url . '" readonly><input type="text" name="from" required="required"></td>
						<td data-label="' . __( 'To', ZYNITH_SEO_TEXT_DOMAIN ) . '">
							<select name="type">' . $this->post_type_options() . '</select>
							' . $this->post_type_fields() . '
						</td>
						<td data-label="' . __( 'Active', ZYNITH_SEO_TEXT_DOMAIN ) . '"><label class="check-switch">
							<input type="checkbox" name="active" checked>
							<span class="slider"></span>
						</label></td>
						<td data-label="' . __( 'Hits', ZYNITH_SEO_TEXT_DOMAIN ) . '">0</td>
						<td data-label="' . __( 'Actions', ZYNITH_SEO_TEXT_DOMAIN ) . '"><button type="submit" class="action save" data-action="save"><span class="dashicons dashicons-yes-alt"></span></button><a href="#" class="action delete" data-action="delete"' . ( $confirm_delete ? ' data-confirm="' . __( 'Are you sure you want to delete this redirect?', ZYNITH_SEO_TEXT_DOMAIN ) . '"' : '' ) . ' style="display: none;"><span class="dashicons dashicons-trash"></span></a></td>
					</tr></table>
				</form>
			</div>';
			
			$existing_redirects = $wpdb->get_results( "SELECT `id`, `http`, `from`, `type`, `to`, `active`, `hits` FROM `{$wpdb->base_prefix}zynith_redirects` WHERE `http` = 301 OR `http` = 302 ORDER BY `id` DESC" );

			echo '<div class="tab-content">
				<a href="#" class="button button-primary button-hero add-row zynith-button" style="margin: 1rem 0 1.5rem;"><span class="dashicons dashicons-plus"></span> ' . __( 'Add Row', ZYNITH_SEO_TEXT_DOMAIN ) . '</a>
				<table id="redirects-table" cellpadding="0" cellspacing="0">
					<tr>
						<th>' . __( 'HTTP', ZYNITH_SEO_TEXT_DOMAIN ) . '</th>
						<th>' . __( 'From', ZYNITH_SEO_TEXT_DOMAIN ) . '</th>
						<th>' . __( 'To', ZYNITH_SEO_TEXT_DOMAIN ) . '</th>
						<th>' . __( 'Active', ZYNITH_SEO_TEXT_DOMAIN ) . '</th>
						<th>' . _x( 'Hits', 'Redirects', ZYNITH_SEO_TEXT_DOMAIN ) . '</th>
						<th>' . __( 'Actions', ZYNITH_SEO_TEXT_DOMAIN ) . '</th>
					</tr>
					<tr>
						<td colspan="6">
							<form method="post" action="">
								<table class="form-table" cellpadding="0" cellspacing="0"><tr>
									<td data-label="' . __( 'HTTP', ZYNITH_SEO_TEXT_DOMAIN ) . '"><select name="http">
										<option value="301">301 ' . __( 'Permanent', ZYNITH_SEO_TEXT_DOMAIN ) . '</option>
										<option value="302">302 ' . __( 'Temporary', ZYNITH_SEO_TEXT_DOMAIN ) . '</option>
									</select></td>
									<td data-label="' . __( 'From', ZYNITH_SEO_TEXT_DOMAIN ) . '"><input type="text" value="' . $home_url . '" readonly><input type="text" name="from" required="required"></td>
									<td data-label="' . __( 'To', ZYNITH_SEO_TEXT_DOMAIN ) . '">
										<select name="type">' . $this->post_type_options() . '</select>
										' . $this->post_type_fields() . '
									</td>
									<td data-label="' . __( 'Active', ZYNITH_SEO_TEXT_DOMAIN ) . '"><label class="check-switch">
										<input type="checkbox" name="active" checked>
										<span class="slider"></span>
									</label></td>
									<td data-label="' . __( 'Hits', ZYNITH_SEO_TEXT_DOMAIN ) . '">0</td>
									<td data-label="' . __( 'Actions', ZYNITH_SEO_TEXT_DOMAIN ) . '"><button type="submit" class="action save" data-action="save" title="' . __( 'Save', ZYNITH_SEO_TEXT_DOMAIN ) . '"><span class="dashicons dashicons-yes-alt"></span></button><a href="#" class="action delete" data-action="delete"' . ( $confirm_delete ? ' data-confirm="' . __( 'Are you sure you want to delete this redirect?', ZYNITH_SEO_TEXT_DOMAIN ) . '"' : '' ) . ' style="display: none;" title="' . __( 'Delete', ZYNITH_SEO_TEXT_DOMAIN ) . '"><span class="dashicons dashicons-trash"></span></a></td>
								</tr></table>
							</form>
						</td>
					</tr>';
					
					foreach ( $existing_redirects as $redirect ) {
						echo '<tr>
							<td colspan="6">
								<form method="post" action="">
									<table class="form-table" cellpadding="0" cellspacing="0"><tr>
										<td data-label="' . __( 'HTTP', ZYNITH_SEO_TEXT_DOMAIN ) . '"><select name="http">
											<option value="301">301 ' . __( 'Permanent', ZYNITH_SEO_TEXT_DOMAIN ) . '</option>
											<option value="302">302 ' . __( 'Temporary', ZYNITH_SEO_TEXT_DOMAIN ) . '</option>
										</select></td>
										<td data-label="' . __( 'From', ZYNITH_SEO_TEXT_DOMAIN ) . '"><input type="text" value="' . $home_url . '" readonly><input type="text" name="from" value="' . $redirect->from . '" required="required"></td>
										<td data-label="' . __( 'To', ZYNITH_SEO_TEXT_DOMAIN ) . '">
											<select name="type">' . $this->post_type_options( $redirect->type ) . '</select>
											' . $this->post_type_fields( $redirect->to ) . '
										</td>
										<td data-label="' . __( 'Active', ZYNITH_SEO_TEXT_DOMAIN ) . '"><label class="check-switch">
											<input type="checkbox" name="active"' . ( (bool) $redirect->active ? ' checked' : '' ) . '>
											<span class="slider"></span>
										</label></td>
										<td data-label="' . __( 'Hits', ZYNITH_SEO_TEXT_DOMAIN ) . '">' . $redirect->hits . '</td>
										<td data-label="' . __( 'Actions', ZYNITH_SEO_TEXT_DOMAIN ) . '"><button type="submit" class="action save update" data-action="save" title="' . __( 'Save', ZYNITH_SEO_TEXT_DOMAIN ) . '"><span class="dashicons dashicons-update"></span></button><a href="#" class="action delete" data-action="delete"' . ( $confirm_delete ? ' data-confirm="' . __( 'Are you sure you want to delete this redirect?', ZYNITH_SEO_TEXT_DOMAIN ) . '"' : '' ) . ' title="' . __( 'Delete', ZYNITH_SEO_TEXT_DOMAIN ) . '"><span class="dashicons dashicons-trash"></span></a></td>
									</tr></table>
									<input type="hidden" name="redirect_id" value="' . $redirect->id . '">
								</form>
							</td>
						</tr>';
					}
					
				echo '</table>
			</div>
		</div>';
	}
	
	public function render_zynith_404_page() {
		global $wpdb;
		
		$home_url = trailingslashit( home_url() );
		if ( strlen( $home_url ) > 15 ) {
			$home_url = rtrim( substr( $home_url, 0, 10 ), '.' ) . '.../';
		}
		
		echo '<div class="wrap">
			<h1>' . __( 'Zynith SEO Redirect Manager (404)', ZYNITH_SEO_TEXT_DOMAIN ) . '</h1>';

			$this->add_tabs();
			
			$missing_redirects = $wpdb->get_results( "SELECT `id`, `from`, `hits`, `referrer` FROM `{$wpdb->base_prefix}zynith_redirects` WHERE `http` = 404 AND NOT `ignored` = 1" );

			if ( ! empty( $missing_redirects ) ) {
				echo '<div class="tab-content">';
				echo '<p class="no-results" style="display: none;">' . __( 'We did not register any 404 errors from visitors on your website. Well done!', ZYNITH_SEO_TEXT_DOMAIN ) . '</p>';
				echo '<p>' . __( 'Below is a list of all the 404 errors we registered from visitors. Ignore them or add them directly as redirects? The choice is yours.', ZYNITH_SEO_TEXT_DOMAIN ) . '</p>
					<table id="redirects-table" class="redirects-table-404" cellpadding="0" cellspacing="0">
						<tr>
							<th>' . __( 'HTTP', ZYNITH_SEO_TEXT_DOMAIN ) . '</th>
							<th>' . __( 'From', ZYNITH_SEO_TEXT_DOMAIN ) . '</th>
							<th>' . __( 'To', ZYNITH_SEO_TEXT_DOMAIN ) . '</th>
							<th>' . _x( 'Hits', 'Redirects', ZYNITH_SEO_TEXT_DOMAIN ) . '</th>
							<th>' . __( 'Actions', ZYNITH_SEO_TEXT_DOMAIN ) . '</th>
						</tr>';

						foreach ( $missing_redirects as $potential_redirect ) {
							$referrers = json_decode( $potential_redirect->referrer );
							$referrer_output = ! empty( $referrers ) ? '<span class="referrers" title="' . implode( ', ', $referrers ) . '"><strong>' . __( 'Referrer', ZYNITH_SEO_TEXT_DOMAIN ) . ':</strong> ' . implode( ', ', $referrers ) . '</span>' : '';
							
							echo '<tr>
								<td colspan="6">
									<form method="post" action="">
										<table class="form-table" cellpadding="0" cellspacing="0"><tr>
											<td data-label="' . __( 'HTTP', ZYNITH_SEO_TEXT_DOMAIN ) . '"><select name="http">
												<option value="301">301 ' . __( 'Permanent', ZYNITH_SEO_TEXT_DOMAIN ) . '</option>
												<option value="302">302 ' . __( 'Temporary', ZYNITH_SEO_TEXT_DOMAIN ) . '</option>
											</select></td>
											<td data-label="' . __( 'From', ZYNITH_SEO_TEXT_DOMAIN ) . '"><input type="text" name="from" value="' . home_url( $potential_redirect->from ) . '" readonly>' . $referrer_output . '</td>
											<td data-label="' . __( 'To', ZYNITH_SEO_TEXT_DOMAIN ) . '">
												<select name="type">' . $this->post_type_options() . '</select>
												' . $this->post_type_fields() . '
											</td>
											<td data-label="' . __( 'Hits', ZYNITH_SEO_TEXT_DOMAIN ) . '">' . $potential_redirect->hits . '</td>
											<td data-label="' . __( 'Actions', ZYNITH_SEO_TEXT_DOMAIN ) . '"><button type="submit" class="action save" data-action="save" title="' . __( 'Save', ZYNITH_SEO_TEXT_DOMAIN ) . '"><span class="dashicons dashicons-yes-alt"></span></button><a href="#" class="action ignore" data-action="ignore" title="' . __( 'Ignore', ZYNITH_SEO_TEXT_DOMAIN ) . '"><span class="dashicons dashicons-hidden"></span></a></td>
										</tr></table>
										<input type="hidden" name="active" value="1">
										<input type="hidden" name="redirect_id" value="' . $potential_redirect->id . '">
									</form>
								</td>
							</tr>';
						}

					echo '</table>
				</div>';
			} else {
				echo '<div class="tab-content"><p>' . __( 'We did not register any 404 errors from visitors on your website. Well done!', ZYNITH_SEO_TEXT_DOMAIN ) . '</p></div>';
			}
		echo '</div>';
	}
	
	public function render_zynith_redirect_settings() {
		echo '<div class="wrap">
			<h1>' . __( 'Zynith SEO Redirects - Settings', ZYNITH_SEO_TEXT_DOMAIN ) . '</h1>';

			$this->add_tabs();
			
			$redirect_settings = get_option( 'zynith_redirect_settings', [] );
			$confirm_delete = (bool) ( $redirect_settings['confirm_delete'] ?? true );
			$redirect_attachments = (bool) ( $redirect_settings['redirect_attachments'] ?? true );
			$force_lowercase = (bool) ( $redirect_settings['force_lowercase'] ?? true );
			
			echo '<div class="tab-content">
			<form class="form-table" method="post" action="">
				<div class="postbox zynith_seo zynith-settings"><div class="inside"><h2>' . __( 'Redirect Settings', ZYNITH_SEO_TEXT_DOMAIN ) . '</h2>
					<table id="redirects-settings-table" class="redirects-settings-table" cellpadding="0" cellspacing="0">
						<tr>
							<th scope="row">
								' . __( 'Confirm deletion', ZYNITH_SEO_TEXT_DOMAIN ) . '
							</th>
							<td>
								<fieldset>
									<label for="confirm_delete" class="check-switch"><input name="zynith_redirect_settings[confirm_delete]" id="confirm_delete" type="checkbox" value="1"' . ( $confirm_delete ? ' checked' : '' ) . '><span class="slider"></span></label>' . __( 'Show confirmation dialog when deleting redirects', ZYNITH_SEO_TEXT_DOMAIN ) . '
								</fieldset>
							</td>
						</tr>
						<tr>
							<th scope="row">
								' . __( 'Attachments', ZYNITH_SEO_TEXT_DOMAIN ) . '
							</th>
							<td>
								<fieldset>
									<label for="redirect_attachments" class="check-switch"><input name="zynith_redirect_settings[redirect_attachments]" id="redirect_attachments" type="checkbox" value="1"' . ( $redirect_attachments ? ' checked' : '' ) . '><span class="slider"></span></label>' . __( 'Redirect attachments to parent post', ZYNITH_SEO_TEXT_DOMAIN ) . '
								</fieldset>
							</td>
						</tr>
						<tr>
							<th scope="row">
								' . __( 'Inconsistent URLs', ZYNITH_SEO_TEXT_DOMAIN ) . '
							</th>
							<td>
								<fieldset>
									<label for="force_lowercase" class="check-switch"><input name="zynith_redirect_settings[force_lowercase]" id="force_lowercase" type="checkbox" value="1"' . ( $force_lowercase ? ' checked' : '' ) . '><span class="slider"></span></label>' . __( 'Force lowercase URLs', ZYNITH_SEO_TEXT_DOMAIN ) . '
								</fieldset>
							</td>
						</tr>
					</table></div></div>
					' . get_submit_button() . '
					' . wp_nonce_field( 'save-redirect-settings', 'redirect-settings-nonce', true, false ) . '
					<input type="hidden" name="redirect_action" value="save_settings">
				</form>
			</div>';
			
		echo '</div>';
	}
	
	public function add_tabs() {
		$page = filter_input( INPUT_GET, 'page' );
		
		$redirects_active = $page === 'zynith-redirects' ? true : false;
		$redirects_404_active = $page === 'zynith-redirects-404' ? true : false;
		$redirects_settings_active = $page === 'zynith-redirects-settings' ? true : false;
		
		echo '<h2 class="nav-tab-wrapper zynith-tabs">
			<a href="' . admin_url( '/admin.php?page=zynith-redirects' ) . '" class="nav-tab' . ( $redirects_active ? ' nav-tab-active' : '' ) . '">' . __( 'Redirects', ZYNITH_SEO_TEXT_DOMAIN ) . '</a>
			<a href="' . admin_url( '/admin.php?page=zynith-redirects-404' ) . '" class="nav-tab' . ( $redirects_404_active ? ' nav-tab-active' : '' ) . '">' . __( '404 errors', ZYNITH_SEO_TEXT_DOMAIN ) . '</a>
			<a href="' . admin_url( '/admin.php?page=zynith-redirects-settings' ) . '" class="nav-tab' . ( $redirects_settings_active ? ' nav-tab-active' : '' ) . '">' . __( 'Settings', ZYNITH_SEO_TEXT_DOMAIN ) . '</a>
		</h2>' . "\n";
	}
	
	public function do_redirect() {
		global $wp, $wpdb;

		if ( ! is_404() ) {
			return;
		}
		
		$data = $wpdb->get_row("SELECT `http`, `to`, `type`, `referrer`, `hits` FROM `{$wpdb->base_prefix}zynith_redirects` WHERE NOT `http` = 404 AND `from` = '{$wp->request}' AND `active` = 1 LIMIT 1");
		
		if ( is_null( $data ) ) {
			return;
		}
		
		$referring_source = htmlspecialchars( filter_input( INPUT_SERVER, 'HTTP_REFERER' ) );
		
		$hits = ! empty( $data->hits ) ? (int) $data->hits + 1 : 1;
		$referrer = json_decode( ! empty( $data->referrer ) ? $data->referrer : '[]', true );
		
		if ( ! empty( $referring_source ) && ! in_array( $referring_source, $referrer ) ) {
			$referrer[] = $referring_source;
		}
		
		$referrer_encoded = json_encode( $referrer );
		
		$query = "UPDATE `{$wpdb->base_prefix}zynith_redirects` SET `referrer` = %s, `hits` = %d WHERE `from` = %s";
		$prepare = $wpdb->prepare( $query, $referrer_encoded, $hits, $wp->request );
		$wpdb->query( $prepare );
		
		$redirect_to = $data->to;
		if ( $data->type !== 'url' ) {
			$redirect_to = get_permalink( $data->to );
		}
		
		if ( empty( $redirect_to ) ) {
			$query = "UPDATE `{$wpdb->base_prefix}zynith_redirects` SET `http` = 404 WHERE `from` = %s";
			$prepare = $wpdb->prepare( $query, $wp->request );
			$wpdb->query( $prepare );

			return;
		}
		
		if ( (int) $data->http === 302 ) {
			nocache_headers();
		}
		
		wp_redirect( $redirect_to, (int) $data->http, 'Zynith SEO Redirect' );
		exit;
	}
	
	public function redirect_attachments() {
		if ( ! is_attachment() ) {
			return;
		}

		$redirect_settings = get_option( 'zynith_redirect_settings', [] );
		$redirect_attachments = (bool) ( $redirect_settings['redirect_attachments'] ?? true );

		if ( ! $redirect_attachments ) {
			return;
		}

		$post = get_post();
		$parent = $post->post_parent;
		
		if ( ! empty( $parent ) ) {
			wp_redirect( get_permalink( $parent ), 301, 'Zynith SEO Redirect' );
		} else {
			wp_redirect( home_url(), 301, 'Zynith SEO Redirect' );
		}
		
		exit;
	}
	
	public function log_404s() {
		if ( ! is_404() ) {
			return;
		}
		
		if ( is_admin() ) {
			return;
		}
		
		global $wp, $wpdb;
		
		if ( empty( trim( $wp->request ) ) ) {
			return;
		}
		
		$referring_source = htmlspecialchars( filter_input( INPUT_SERVER, 'HTTP_REFERER' ) );
		
		if ( empty( $referring_source ) ) {
			return;
		}
		
		$data = $wpdb->get_row("SELECT `referrer`, `hits` FROM `{$wpdb->base_prefix}zynith_redirects` WHERE `from` = '{$wp->request}' LIMIT 1");
		$hits = ! empty( $data->hits ) ? (int) $data->hits + 1 : 1;
		$referrer = json_decode( ! empty( $data->referrer ) ? $data->referrer : '[]', true );
		
		if ( ! in_array( $referring_source, $referrer ) ) {
			$referrer[] = $referring_source;
		}
		
		$referrer_encoded = json_encode( $referrer );
		
		$query = "INSERT INTO `{$wpdb->base_prefix}zynith_redirects` (`from`, `referrer`, `hits`) VALUES (%s, %s, %d) ON DUPLICATE KEY UPDATE `hits` = %d, `referrer` = %s";
		$prepare = $wpdb->prepare( $query, $wp->request, $referrer_encoded, $hits, $hits, $referrer_encoded );
		$wpdb->query( $prepare );
	}
	
	public function redirect_to_lowercase() {
		$uri = filter_input( INPUT_SERVER, 'REQUEST_URI' );
		$qs = filter_input( INPUT_SERVER, 'QUERY_STRING' );

		// If URI contains a dot, it's likely a file
		if ( preg_match( '/[\.]/', $uri ) ) {
			return;
		}

		// If URI contains no uppercase letters, skip it
		if ( ! preg_match( '/[A-Z]/', $uri ) ) {
			return;
		}

		$redirect_settings = get_option( 'zynith_redirect_settings', [] );
		$force_lowercase = (bool) ( $redirect_settings['force_lowercase'] ?? true );

		if ( ! $force_lowercase ) {
			return;
		}
		
		$formatted_uri = $this->format_uri( $uri );
		$lc_uri = empty( $qs ) ? $formatted_uri : $formatted_uri . '?' . $qs;

		if ( $lc_uri !== $uri ) {
			wp_redirect( home_url( $lc_uri ), 301, 'Zynith SEO Redirect' );
			exit;
		}
	}
	
	private function format_uri( $uri ) {
		$clean_uri = strpos( $uri, '?' ) !== false ? substr( $uri, 0, strrpos( $uri, '?' ) ) : $uri;
		$uri_parts = explode( '/', $clean_uri );
		$return_uri = [];
		
		foreach ( $uri_parts as $part ) {
			$decoded = urldecode( $part );
			$return_uri[] = urlencode( strtolower( $decoded ) );
		}
		
		return implode( '/', $return_uri );
	}
	
	public function create_redirects_table() {
		global $wpdb;

		$queue_table = "{$wpdb->base_prefix}zynith_redirects";
		$query = $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $queue_table ) );

		if ( $wpdb->get_var( $query ) === $queue_table ) {
			return;
		}

		$sql = "CREATE TABLE `{$queue_table}` (
			`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
			`http` smallint(3) UNSIGNED DEFAULT 404 NOT NULL,
			`from` varchar(255) DEFAULT '' NOT NULL,
			`type` varchar(255) DEFAULT '',
			`to` varchar(255) DEFAULT '',
			`referrer` longtext DEFAULT '[]',
			`active` tinyint(1) UNSIGNED DEFAULT 0 NOT NULL,
			`ignored` tinyint(1) UNSIGNED DEFAULT 0 NOT NULL,
			`hits` mediumint(8) UNSIGNED DEFAULT 0 NOT NULL,
			`added` datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
			PRIMARY KEY (`id`),
			INDEX (`http`),
			UNIQUE (`from`),
			INDEX (`to`)
		) ENGINE = InnoDB CHARSET=utf8mb4 COLLATE utf8mb4_unicode_520_ci;";
		
		$wpdb->query( $sql );
	}
	
	public function get_posts_recursive( $parent_id, $children, &$return, $level = 0 ) {
		$level++;
		$padding = str_repeat( '&nbsp;', $level*3 );
		
		if ( ! empty( $children[ $parent_id ] ) ) {
			foreach ( $children[ $parent_id ] as $child ) {
				$return[ $child->ID ] = $padding . $child->post_title;
				$this->get_posts_recursive( $child->ID, $children, $return, $level );
			}
			
			return $return;
		}
	}

	// This also exist in Settings.php
	public function dropdown_pages( $args = [] ) {
		$return = [];
		$defaults = [
			'posts_per_page'   => -1,
			'offset'           => 0,
			'category'         => '',
			'orderby'          => 'menu_order',
			'order'            => 'DESC',
			'include'          => '',
			'exclude'          => '',
			'meta_key'         => '',
			'meta_value'       => '',
			'post_type'        => 'page',
			'post_status'      => 'publish',
			'suppress_filters' => false,
		];
		
		$posts = get_posts( array_merge( $defaults, $args ) );
		$parents = [];
		$children = [];
		
		foreach ( $posts as $p ) {
			$parent = $p->post_parent;
			
			if ( $parent === 0 ) {
				$parents[] = $p;
			} else {
				$children[ $parent ][] = $p;
			}
		}
		
		if ( empty( $parents ) ) {
			return;
		}
		
		foreach ( $parents as $parent ) {
			$return[ $parent->ID ] = $parent->post_title;
			
			if ( ! empty( $children ) ) {
				$this->get_posts_recursive( $parent->ID, $children, $return );
			}
		}
		
		return $return;
	}
	
}
