<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class ZynithSEOBreadcrumbs {

    public $post_types;
    public $args;

    public function __construct() {
		$this->post_types = array_keys( ZynithSEOPostTypes::get_post_types() );
		$this->args = apply_filters( 'zynith_breadcrumb_args', [
			'wrap_start' => '<div class="breadcrumbs">',
			'wrap_end' => '</div>',
			'separator' => ' <span class="sep">&raquo;</span> ',
		] );

        add_shortcode( 'zynith-breadcrumbs', [ $this, 'render_breadcrumbs' ] );
    }

    public static function init() {
        return new self();
    }

    private function get_object_taxonomies( $post_type ) {
        $object_taxonomies = get_object_taxonomies( $post_type, 'objects' );
        $taxonomies = [];

        if ( ! empty( $object_taxonomies ) ) {
            foreach ( $object_taxonomies as $tax_name => $taxonomy ) {
                if ( $taxonomy->public && $taxonomy->hierarchical ) {
                    $taxonomies[] = $tax_name;
                }
            }
        }

        return $taxonomies;
    }

	// Copied from the WP docs, modified by Zynith
	private function get_term_parents_list( $term_id, $taxonomy, $args = [] ) {
		$list = '';
		$term = get_term( $term_id, $taxonomy );
	
		if ( is_wp_error( $term ) || ! $term ) {
			return $list;
		}
	
		$term_id = $term->term_id;
		$schema_items = [
			[
				'@type' => 'ListItem',
				'position' => 1,
				'item' => [
					'@id' => home_url(),
					'name' => _x( 'Home', 'Breadcrumbs Home', ZYNITH_SEO_TEXT_DOMAIN ),
				],
			]
		];
		$defaults = [
			'format'    => 'name',
			'separator' => '/',
			'link'      => true,
			'inclusive' => true,
		];
	
		$args = wp_parse_args( $args, $defaults );
	
		foreach ( [ 'link', 'inclusive' ] as $bool ) {
			$args[ $bool ] = wp_validate_boolean( $args[ $bool ] );
		}
	
		$parents = get_ancestors( $term_id, $taxonomy, 'taxonomy' );
	
		if ( $args['inclusive'] ) {
			array_unshift( $parents, $term_id );
		}

		$item_position = 2;
	
		foreach ( array_reverse( $parents ) as $term_id ) {
			$parent = get_term( $term_id, $taxonomy );
			$name   = $parent->name;
	
			if ( $args['link'] ) {
				$url = esc_url( get_term_link( $parent->term_id, $taxonomy ) );
				$schema_items[] = [
					'@type' => 'ListItem',
					'position' => $item_position,
					'item' => [
						'@id' => $url,
						'name' => $name,
					],
				];

				$list .= '<a href="' . $url . '">' . $name . '</a>' . $args['separator'];
				$item_position++;
			} else {
				$list .= $name . $args['separator'];
			}
		}
	
		return [
			'html' => $list,
			'schema' => $schema_items,
		];
	}

	public function render_breadcrumbs() {
		if ( is_front_page() ) {
			return;
		}

		$breadcrumbs_generated = false;
		$add_schema = (bool) get_option( 'zynith_add_breadcrumbs_schema', false );
		$schema_array = [
			'@context' => 'https://schema.org',
			'@type' => 'BreadcrumbList',
			'itemListElement' => [
				[
					'@type' => 'ListItem',
					'position' => 1,
					'item' => [
						'@id' => home_url(),
						'name' => _x( 'Home', 'Breadcrumbs Home', ZYNITH_SEO_TEXT_DOMAIN ),
					],
				]
			],
		];

		$breadcrumbs = $this->args['wrap_start'];
		$breadcrumbs .= '<a href="' . home_url() . '">' . _x( 'Home', 'Breadcrumbs Home', ZYNITH_SEO_TEXT_DOMAIN ) . '</a>' . $this->args['separator'];

		if ( is_singular( $this->post_types ) || is_category() || is_tax() || is_author() ) {
			$breadcrumbs_generated = true;

			if ( is_author() ) {
				$breadcrumbs .= get_the_author_meta( 'display_name' );
			} elseif ( is_singular( $this->post_types ) ) {
				$post = get_post();
				
				if ( $post->post_type === 'post' ) {
					$categories = get_the_category();

					if ( ! empty( $categories ) ) {
						$list = $this->get_term_parents_list( $categories[0], 'category', [
							'separator' => $this->args['separator'],
							'link'      => true,
						] );

						if ( ! empty( $list['html'] ) ) {
							$breadcrumbs .= $list['html'];
						}

						if ( ! empty( $list['schema'] ) ) {
							$schema_array['itemListElement'] = $list['schema'];
						}
					}
				} else {
					$taxonomies = $this->get_object_taxonomies( $post->post_type );

					if ( ! empty( $taxonomies ) ) {
						$terms = get_the_terms( $post, $taxonomies[0] );

						if ( ! empty( $terms ) ) {
							$list = $this->get_term_parents_list( $terms[0], $taxonomies[0], [
								'separator' => $this->args['separator'],
								'link'      => true,
							] );

							if ( ! empty( $list['html'] ) ) {
								$breadcrumbs .= $list['html'];
							}

							if ( ! empty( $list['schema'] ) ) {
								$schema_array['itemListElement'] = $list['schema'];
							}
						}
					}
				}
				
				$breadcrumbs .= $post->post_title;
			} elseif (is_category()) {
				$list = $this->get_term_parents_list( get_queried_object(), 'category', [
					'separator' => $this->args['separator'],
					'link'      => true,
				] );

				if ( ! empty( $list['html'] ) ) {
					$breadcrumbs .= $list['html'];
				}

				if ( ! empty( $list['schema'] ) ) {
					$schema_array['itemListElement'] = $list['schema'];
				}
			} elseif ( $term = get_queried_object() ) {
				if ( is_a( $term, 'WP_Term' ) ) {
					$breadcrumbs .= $term->name;
				} else {
					$breadcrumbs_generated = false;
				}
			}
		}

		if ( ! $breadcrumbs_generated ) {
			$uri = htmlspecialchars( trim( filter_input( INPUT_SERVER, 'REQUEST_URI' ), '/' ) );
			$url = ! empty( $uri ) ? explode( '/', $uri ) : [];

			if ( empty( array_filter( $url ) ) ) {
				return '';
			}
			
			$url = array_filter( $url );
			$breadcrumb_url = '/';
			$item_position = 2;

			for ( $i = 1; $i <= count( $url ); $i++ ) {
				$breadcrumb_url .= $url[ $i ] . '/';
				$label = ucfirst( str_replace( '-', ' ', $url[ $i ] ) );

				$schema_array['itemListElement'][] = [
					'@type' => 'ListItem',
					'position' => $item_position,
					'item' => [
						'@id' => esc_url( $breadcrumb_url ),
						'name' => $label,
					],
				];
		
				if ( $i === count( $url ) ) {
					$breadcrumbs .= $label;
				} else {
					$breadcrumbs .= '<a href="' . esc_url( $breadcrumb_url ) . '">' . $label . '</a>' . $this->args['separator'];
				}

				$breadcrumbs_generated = true;
			}
		}

		$breadcrumbs .= $this->args['wrap_end'];

		if ( $add_schema ) {
			$breadcrumbs .= '<script type="application/ld+json">' . json_encode( $schema_array, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>';
		}

		return $breadcrumbs_generated ? $breadcrumbs : '';
	}

}
