<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class ZynithSEOContentUtility {

    public static function calculate_keyword_density( $content, $keyword ) {
        $keyword = strtolower( trim( $keyword ) );
        $content = strtolower( wp_strip_all_tags( $content ) );
        $word_count = str_word_count( $content );
        $keyword_count = substr_count( $content, $keyword );

        if ( $word_count < 1 ) {
            return 0;
        }

        $density = ( $keyword_count / $word_count ) * 100;

        return round( $density, 2 );
    }

    // TODO: Consider counting the post title as h1? Or switch to DomDocument instead
    public static function get_all_headings( $content ) {
		
        // Check for headings in the content
        preg_match_all( '/<h([1-6])[^>]*>(.*?)<\/h[1-6]>/ui', $content, $headings, PREG_SET_ORDER );
    
        // Array to store the grouped headings
        $grouped_headings = [];
    
        foreach ( $headings as $heading ) {
            $level = $heading[1];
            $text = $heading[2];

            $grouped_headings["h$level"][] = $text;
        }
    
        return $grouped_headings;
    }

    public static function check_missing_alt_tags( $content ) {
        preg_match_all( '/<img[^>]+>/i', $content, $img_tags );
    
        if ( empty( $img_tags[0] ) ) {
            return false;
        }
    
        foreach ( $img_tags[0] as $img_tag ) {
            preg_match('/alt="([^"]*)"/i', $img_tag, $alt_attr);
            if ( empty( $alt_attr ) || empty( $alt_attr[1] ) ) {
                return true;
            }
        }
    
        return false;
    }

    public static function is_content_ai_generated( $content ) {
        // Define regular expressions for nouns, verbs, and adjectives
        $noun_regex = '/\b(?:[a-z]*ing|tion|ment|ness|ity|ty|sion|ence|ance|er|or)\b/i';
        $verb_regex = '/\b(?:[a-z]*ed|[a-z]*en|[a-z]*es)\b/i';
        $adjective_regex = '/\b(?:[a-z]*y|[a-z]*ous|[a-z]*ful|[a-z]*ish|[a-z]*ive|[a-z]*al|[a-z]*ic)\b/i';
    
        // Count the occurrences of each part of speech in the content
        $nouns = preg_match_all( $noun_regex, $content );
        $verbs = preg_match_all( $verb_regex, $content );
        $adjectives = preg_match_all( $adjective_regex, $content );
    
        // Define a threshold ratio for adjectives to nouns
        $adjective_noun_ratio = 0.5;
    
        // Calculate the ratio of adjectives to nouns in the content
        $ratio = ($nouns > 0) ? $adjectives / $nouns : 0;
    
        // If the ratio exceeds the predefined threshold, assume the content is AI-generated
        return (bool) ( $ratio >= $adjective_noun_ratio );
    }

    public static function check_content_length( $content ) {
        $word_count = str_word_count( wp_strip_all_tags( $content ) );

        return (bool) ( $word_count >= 1400 );
    }

    public static function detect_broken_links( $content, $object ) {
        $key = get_class( $object );
        $broken_links = [];

        if ( $key === 'WP_Post' ) {
            $object_id = $object->ID;
            $option = 'broken_links_posts';
            $title = $object->post_title;
            $edit = admin_url( '/post.php?post=' . $object_id . '&action=edit' );
        } elseif ( $key === 'WP_Term' ) {
            $object_id = $object->term_id;
            $option = 'broken_links_terms';
            $title = $object->name;
            $edit = admin_url( '/term.php?taxonomy=' . $object->taxonomy . '&tag_ID=' . $object_id );
        } elseif ( $key === 'WP_User' ) {
            $object_id = $object->ID;
            $option = 'broken_links_authors';
            $title = $object->display_name;
            $edit = admin_url( '/user-edit.php?user_id=' . $object_id );
        } else {
            return $broken_links;
        }

        $broken_links_options = get_option( $option, [] );
        unset( $broken_links_options[ $object_id ] );

        preg_match_all( '/<a[^>]+href=["\'](.*?)["\']/', $content, $links );
        foreach ( $links[1] as $link ) {
            if ( ! filter_var( $link, FILTER_VALIDATE_URL ) || get_headers( $link )[0] == 'HTTP/1.1 404 Not Found') {
                $broken_links[] = $link;
            }
        }

        if ( ! empty( $broken_links ) ) {
            $broken_links_options[ $object_id ] = [
                'broken_links' => $broken_links,
                'title' => $title,
                'edit' => $edit,
            ];
        }

        update_option( $option, $broken_links_options );

        return $broken_links;
    }

    // Old version of link counter
    public static function check_link_ratios( $content ) {
        $internal_links_count = preg_match_all( '/<a[^>]*href=["\'](?:(?!mailto:|tel:|javascript:|#|.*\.(pdf|docx?|xlsx?|pptx?|zip|rar|jpg|jpeg|png|gif|bmp|mp3|mp4|wav|ogg|avi|mov|mkv))(?:https?:\/\/)?(?:www\.)?' . preg_quote( $_SERVER['HTTP_HOST'] ) . '[^"\']*)["\'][^>]*>/i', $content, $internal_matches );
        $external_links_count = preg_match_all( '/<a[^>]*href=["\']((?:(?!mailto:|tel:|javascript:|#|.*\.(pdf|docx?|xlsx?|pptx?|zip|rar|jpg|jpeg|png|gif|bmp|mp3|mp4|wav|ogg|avi|mov|mkv))(?:https?:\/\/)?(?:www\.)?)[^"\']+)["\'][^>]*>/i', $content, $external_matches );
        
        // Remove internal links from the external links array
        $external_links_count = $external_links_count - $internal_links_count;
        
        $word_count = str_word_count( wp_strip_all_tags( $content ) );
    
        $internal_link_ratio = $internal_links_count / ( $word_count / 1000 );
        $external_link_ratio = $external_links_count / ( $word_count / 1000 );
    
        $internal_green_light = $internal_links_count > 0 && $internal_links_count < 4 && $internal_link_ratio <= 3;
        $internal_red_light = $internal_links_count == 0 || ( $internal_links_count >= 4 && $internal_link_ratio > 3 );
    
        $external_green_light = $external_links_count > 0 && $external_links_count <= 3 && $external_link_ratio <= 3;
        $external_red_light = $external_links_count > 3 && $external_link_ratio > 3;
    
        return [
            'internal_green_light' => $internal_green_light,
            'internal_red_light' => $internal_red_light,
            'external_green_light' => $external_green_light,
            'external_red_light' => $external_red_light,
            'internal_links' => $internal_links_count,
            'external_links' => $external_links_count
        ];
    }

    // New version of link counter
    public static function check_link_counts( $content ) {
        if ( empty( $content ) ) {
            return [
                'internal_red_light' => true,
                'external_red_light' => true,
                'internal_links' => 0,
                'external_links' => 0,
            ];
        }
        
        $home_url = home_url();
        $internal_links = 0;
        $external_links = 0;

        $doc = new DOMDocument();
        libxml_use_internal_errors( true );
        $doc->loadHTML( $content );
        libxml_clear_errors();
        $links = $doc -> getElementsByTagName( 'a' );

        foreach ( $links as $link ) {
            $href = $link->getAttribute( 'href' );
            if (strpos($href, $home_url) === 0 || strpos($href, '/') === 0) { $internal_links++; }
            else { $external_links++; }
        }

        return [
            'internal_red_light' => (bool) ( $internal_links < 3 ),
            'external_red_light' => (bool) ( $external_links < 3 ),
            'internal_links' => $internal_links,
            'external_links' => $external_links,
        ];
    }

    public static function calculate_html_to_text_ratio( $content ) {
        if ( empty( $content ) ) {
            return 0;
        }
    
        // Calculate the ratio
        $html_length = strlen( $content );
        $text_length = strlen( strip_tags( $content ) );

        return round( ( $text_length / $html_length ) * 100, 2 );
    }

}
