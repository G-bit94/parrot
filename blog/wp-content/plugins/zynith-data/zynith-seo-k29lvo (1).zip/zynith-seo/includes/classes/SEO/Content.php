<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class ZynithSEOContent {

    public $post_types;
    public $taxonomies;

    public function __construct() {
        $this->post_types = array_keys( ZynithSEOPostTypes::get_post_types() );
        $this->taxonomies = array_keys( ZynithSEOTaxonomies::get_taxonomies() );

        add_action( 'wp_head', [ $this, 'output_meta_data' ], 1 );
        add_action( 'wp_head', [ $this, 'output_open_graph_image' ], 1 );
        add_action( 'wp_head', [ $this, 'output_canonical_url' ], 2 );
        add_action( 'wp_head', [ $this, 'scripts_insert_head' ] );
        add_action( 'wp_footer', [ $this, 'scripts_insert_body' ] );

        add_filter( 'pre_get_document_title', [ $this, 'modify_document_title' ], 10 );

        add_filter( 'wp_robots', [ $this, 'modify_robots_post_meta' ] );
    }

    public static function init() {
        return new self();
    }

    private function is_supported_taxonomy( $term ) {
        if ( is_a( $term, 'WP_Term' ) && ! empty( $term->taxonomy ) ) {
            return (bool) in_array( $term->taxonomy, $this->taxonomies );
        }

        return false;
    }

    public function output_meta_data() {
        if ( ! is_singular( $this->post_types ) ) {
            return;
        }

        $post = get_post();
        $meta_description = get_post_meta( $post->ID, '_custom_meta_description', true );
        $schema = get_post_meta( $post->ID, '_custom_schema', true );

        if ( ! empty( $meta_description ) ) {
            echo '<meta name="description" content="' . esc_attr( $meta_description ) . '">';
        }

        if ( ! empty( $schema ) ) {
            echo '<script type="application/ld+json">' . $schema . '</script>' . "\n";
        }
    }

    public function output_canonical_url() {
        $canonical_url = null;

        if ( is_home() ) {
            $canonical_url = home_url();
        } elseif ( is_singular( $this->post_types ) ) {
            $post = get_post();

            $canonical_url = get_permalink( $post->ID );
        } elseif ( is_category() || is_tag() || is_tax() ) {
            $term = get_queried_object();

            if ( ! empty( $term->taxonomy ) ) {
                $canonical_url = get_term_link( $term->term_id, $term->taxonomy );
            }
        } elseif ( is_archive() ) {
            if ( is_date() ) {
                if ( is_day() ) {
                    $canonical_url = get_day_link( get_query_var('year'), get_query_var('monthnum'), get_query_var('day') );
                } elseif ( is_month() ) {
                    $canonical_url = get_month_link( get_query_var('year'), get_query_var('monthnum') );
                } elseif ( is_year() ) {
                    $canonical_url = get_year_link( get_query_var('year') );
                }
            } elseif ( is_author() ) {
                $canonical_url = get_author_posts_url( get_query_var('author'), get_query_var('author_name') );
            } elseif ( is_post_type_archive() ) {
                $canonical_url = get_post_type_archive_link( get_query_var('post_type') );
            }
        }

        if ( empty( $canonical_url ) ) {
            return;
        }

        echo '<link rel="canonical" href="' . esc_url( $canonical_url ) . '">' . "\n";
    }

    public function scripts_insert_head() {
        echo get_option( 'gtm_header_script' );
    }

    public function scripts_insert_body() {
        echo get_option( 'gtm_body_script' );
    }

    public function modify_robots_post_meta( $directives ) {
        $blog_public = (bool) get_option( 'blog_public' );
    
        // If the website is not public, return the default
        if ( ! $blog_public ) {
            return $directives;
        }

        if ( is_singular( $this->post_types ) ) {
            $post = get_post();
        
            // If post is not found, simply return the default
            if ( empty( $post ) ) {
                return $directives;
            }
        
            $noindex = get_post_meta( $post->ID, '_custom_noindex', true );
            $nofollow = get_post_meta( $post->ID, '_custom_nofollow', true );
            $noindex_post_types = get_option( 'zynith_noindex_post_types' );
            $nofollow_post_types = get_option( 'zynith_nofollow_post_types' );
        
            // Now, we established that we're in a public post, and want to do our own robots meta. Unset whatever parameters you are modifying
            unset( $directives['noindex'], $directives['nofollow'] );

            // If noindex is set, add it to the directives array
            if ( ! empty( $noindex_post_types ) && in_array( $post->post_type, array_keys( $noindex_post_types ) ) ) {
                $directives['noindex'] = true;
            }

            if ( $noindex === 'yes' ) {
                $directives['noindex'] = true;
            }

            // If nofollow is set, add it to the directives array
            if ( ! empty( $nofollow_post_types ) && in_array( $post->post_type, array_keys( $nofollow_post_types ) ) ) {
                $directives['nofollow'] = true;
            }

            if ( $nofollow === 'yes' ) {
                $directives['nofollow'] = true;
            }
    
            if ( ZYNITH_SEO_IS_WOOCOMMERCE ) {
                if ( is_cart() || is_checkout() || is_account_page() || is_view_order_page() || is_checkout_pay_page() || is_edit_account_page() || is_order_received_page() || is_add_payment_method_page() || is_lost_password_page() ) {
                    $directives['noindex'] = true;
                }
            }
        }

        if ( $term = get_queried_object() ) {
			if ( $this->is_supported_taxonomy( $term ) ) {
                $noindex = get_term_meta( $term->term_id, '_custom_noindex', true );
                $nofollow = get_term_meta( $term->term_id, '_custom_nofollow', true );
                $noindex_taxonomies = get_option( 'zynith_noindex_taxonomies' );
                $nofollow_taxonomies = get_option( 'zynith_nofollow_taxonomies' );

                unset( $directives['noindex'], $directives['nofollow'] );

                // If noindex is set, add it to the directives array
                if ( ! empty( $noindex_taxonomies ) && in_array( $term->taxonomy, array_keys( $noindex_taxonomies ) ) ) {
                    $directives['noindex'] = true;
                }
    
                if ( $noindex === 'yes' ) {
                    $directives['noindex'] = true;
                }
    
                // If nofollow is set, add it to the directives array
                if ( ! empty( $nofollow_taxonomies ) && in_array( $term->taxonomy, array_keys( $nofollow_taxonomies ) ) ) {
                    $directives['nofollow'] = true;
                }
    
                if ( $nofollow === 'yes' ) {
                    $directives['nofollow'] = true;
                }
            }
        }

        // Archives
        if ( is_author() || is_date() || is_search() ) {
            $noindex = false;
            $nofollow = false;
            $type = '';

            if ( is_author() ) {
                $user_id = get_the_author_meta( 'ID' );
                
                $noindex = get_user_meta( $user_id, '_custom_noindex', true );
                $nofollow = get_user_meta( $user_id, '_custom_nofollow', true );
                $type = 'author';
            }

            if ( is_date() ) {
                $type = 'date';
            }

            if ( is_search() ) {
                $type = 'search';
            }

            $noindex_archives = get_option( 'zynith_noindex_archives' );
            $nofollow_archives = get_option( 'zynith_nofollow_archives' );

            unset( $directives['noindex'], $directives['nofollow'] );

            // If noindex is set, add it to the directives array
            if ( ! empty( $noindex_archives ) && in_array( $type, array_keys( $noindex_archives ) ) ) {
                $directives['noindex'] = true;
            }

            if ( $noindex === 'yes' ) {
                $directives['noindex'] = true;
            }

            // If nofollow is set, add it to the directives array
            if ( ! empty( $nofollow_archives ) && in_array( $type, array_keys( $nofollow_archives ) ) ) {
                $directives['nofollow'] = true;
            }

            if ( $nofollow === 'yes' ) {
                $directives['nofollow'] = true;
            }
        }

        if ( ! empty( $directives['noindex'] ) || ! empty( $directives['nofollow'] ) ) {
            unset( $directives['max-image-preview'] );
        }
        
        // Always return the directives array, no matter the settings
        return $directives;
    }

    function output_open_graph_image() {
        $og_image_url = null;

        if ( is_singular( $this->post_types ) ) {
            $post = get_post();
            $og_image_url = get_post_meta( $post->ID, '_custom_meta_og_image', true );
        }

        if ( $term = get_queried_object() ) {
			if ( $this->is_supported_taxonomy( $term ) ) {
                $og_image_url = get_term_meta( $term->term_id, '_custom_meta_og_image', true );
            }
        }

        if ( is_author() ) {
            $user_id = get_the_author_meta( 'ID' );
            $og_image_url = get_user_meta( $user_id, '_custom_meta_og_image', true );
        }
    
        if ( ! empty( $og_image_url ) ) {
            echo '<meta property="og:image" content="' . esc_url( $og_image_url ) . '">';
        }
    }

    public function modify_document_title( $title ) {
        if ( is_singular( $this->post_types ) ) {
            $post = get_post();
            $meta_title = get_post_meta( $post->ID, '_custom_meta_title', true );
            
            if ( ! empty( $meta_title ) ) {
                $title = esc_html( $meta_title );
            }
        }

        if ( $term = get_queried_object() ) {
			if ( $this->is_supported_taxonomy( $term ) ) {
                $meta_title = get_term_meta( $term->term_id, '_custom_meta_title', true );
                
                if ( ! empty( $meta_title ) ) {
                    $title = esc_html( $meta_title );
                }
            }
        }

        if ( is_author() ) {
            $user_id = get_the_author_meta( 'ID' );
            $meta_title = get_user_meta( $user_id, '_custom_meta_title', true );
            
            if ( ! empty( $meta_title ) ) {
                $title = esc_html( $meta_title );
            }
        }
	
        return $title;
    }

}
