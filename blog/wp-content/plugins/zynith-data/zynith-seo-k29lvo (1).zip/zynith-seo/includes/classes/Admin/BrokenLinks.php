<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class ZynithSEOBrokenLinks {

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'add_broken_links_pages' ], 99 );
    }

    public static function init() {
        return new self();
    }

    public function add_broken_links_pages() {
        // add_menu_page( esc_html__( 'Broken Links Overview', ZYNITH_SEO_TEXT_DOMAIN ), esc_html__( 'Broken Links', ZYNITH_SEO_TEXT_DOMAIN ), 'edit_posts', 'broken-links', [ $this, 'add_broken_links_table' ], 'dashicons-editor-unlink', 95 );
        add_submenu_page( 'zynith-seo-settings', __( 'Broken Links Overview', ZYNITH_SEO_TEXT_DOMAIN ), __( 'Broken Links', ZYNITH_SEO_TEXT_DOMAIN ), 'edit_posts', 'broken-links', [ $this, 'add_broken_links_table' ] );
    }

    public function add_broken_links_table() {
        echo '<div class="wrap">
            <h1>' . sprintf( __( 'Zynith Broken Links Overview', ZYNITH_SEO_TEXT_DOMAIN ) ) . '</h1>';
        
            $this->add_tabs();

            $current_tab = filter_input( INPUT_GET, 'tab' );
            $tabs = $this->get_tabs();

            if ( empty( $current_tab ) ) {
                foreach ( $tabs as $key => $tab ) {
                    if ( ! empty( $tab['active'] ) ) {
                        $current_tab = $key;
                    }
                }
            }

            $label = $tabs[ $current_tab ]['label'];
            $links = $tabs[ $current_tab ]['links'];

            if ( empty( $links ) ) {
                echo '<div class="tab-content">
                    <p>' . __( 'We did not find any broken links. Well done!', ZYNITH_SEO_TEXT_DOMAIN ) . '</p>
                </div>';

                return;
            }

            echo '<h3>' . $label . '</h3>
            <div class="tab-content">
                <table id="analysis-table" class="form-table" cellpadding="0" cellspacing="0">
                    <tr>
                        <th>' . __( 'Title/Edit', ZYNITH_SEO_TEXT_DOMAIN ) . '</th>
                        <th>' . __( 'Broken Links', ZYNITH_SEO_TEXT_DOMAIN ) . '</th>
                    </tr>';

                    foreach ( $links as $link ) {
                        echo '<tr>
                            <td data-label="' . __( 'Title/Edit', ZYNITH_SEO_TEXT_DOMAIN ) . '"><a href="' . $link['edit'] . '">' . $link['title'] . '</a></td>
                            <td data-label="' . __( 'Broken Links', ZYNITH_SEO_TEXT_DOMAIN ) . '">' . implode( '<br>', $link['broken_links'] ) . '</td>
                        </tr>';
                    }

                echo '</table>
            </div>';

        echo '</div>';
    }

    private function get_tabs() {
        $current_tab = filter_input( INPUT_GET, 'tab' );
        $current_tab_set = false;
        $all_tabs = [];

        $post_links = get_option( 'broken_links_posts', [] );
        $term_links = get_option( 'broken_links_terms', [] );
        $author_links = get_option( 'broken_links_authors', [] );

        $all_tabs = [
            'posts' => [
                'label' => sprintf( __( 'Posts (%s)', ZYNITH_SEO_TEXT_DOMAIN ), count( $post_links ) ),
                'links' => $post_links,
                'active' => (bool) ( $current_tab === 'posts' || ( empty( $current_tab ) && ! $current_tab_set ) ? true : false ),
            ],
            'terms' => [
                'label' => sprintf( __( 'Terms (%s)', ZYNITH_SEO_TEXT_DOMAIN ), count( $term_links ) ),
                'links' => $term_links,
                'active' => (bool) ( $current_tab === 'terms' ? true : false ),
            ],
            'authors' => [
                'label' => sprintf( __( 'Authors (%s)', ZYNITH_SEO_TEXT_DOMAIN ), count( $author_links ) ),
                'links' => $author_links,
                'active' => (bool) ( $current_tab === 'authors' ? true : false ),
            ],
        ];

        return $all_tabs;
    }

    private function add_tabs() {
        $page = filter_input( INPUT_GET, 'page' );
        $all_tabs = $this->get_tabs();
		
		echo '<h2 class="nav-tab-wrapper zynith-tabs">';

        $i = 1;

        foreach ( $all_tabs as $key => $tab ) {
            $label = $tab['label'];
            $current_tab_active = (bool) $tab['active'];

            echo '<a href="' . admin_url( "/admin.php?page=$page&tab=$key" ) . '" class="nav-tab' . ( $current_tab_active ? ' nav-tab-active' : '' ) . '">' . $label . '</a>';

            ++$i;
        }
        
		echo '</h2>' . "\n";
    }

}
