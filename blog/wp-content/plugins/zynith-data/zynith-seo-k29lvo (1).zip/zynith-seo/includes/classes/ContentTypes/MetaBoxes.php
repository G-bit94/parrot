<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class ZynithSEOMetaBoxes {

    public function __construct() {
		if ( is_admin() ) {
            add_action( 'load-post.php', [ $this, 'init_metaboxes' ] );
            add_action( 'load-post-new.php', [ $this, 'init_metaboxes' ] );
        }
	}

    public static function init() {
        return new self();
    }

    public function init_metaboxes() {
        add_action( 'add_meta_boxes', [ $this, 'add_metaboxes' ] );
        add_action( 'save_post', [ $this, 'save_metabox' ], 10, 2 );
    }

    public function add_metaboxes() {
        $post_types = array_keys( ZynithSEOPostTypes::get_post_types() );
				
        add_meta_box(
            'custom_seo_metabox',
            __('Zynith SEO', ZYNITH_SEO_TEXT_DOMAIN),
            [$this, 'custom_seo_metabox'],
            $post_types,
            'normal',
            'high'
        );
		/*
        add_meta_box(
            'dynamic_schema_metabox',
            __( 'Dynamic Schema', ZYNITH_SEO_TEXT_DOMAIN ),
            [ $this, 'dynamic_schema_metabox' ],
            $post_types,
            'normal',
            'high'
        );

        $seo_signals_metabox_enabled = get_option( 'seo_signals_metabox_enabled', 'yes' );
        $is_metabox_enabled = (bool) ( $seo_signals_metabox_enabled === 'yes' );

        if ( $is_metabox_enabled ) {
            add_meta_box(
                'seo_signals_metabox', // id
				__( 'SEO Signals', ZYNITH_SEO_TEXT_DOMAIN ),
                [ $this, 'seo_signals_metabox' ],
                $post_types,
                'advanced',
                'low'
            );
        }
		*/
    }

	// Static function to make it available for all content types
	public static function get_custom_seo_metabox( $object, $type = 'post' ) {
        if ( $type === 'taxonomy' ) {
			$object_id = $object->term_id;
			$meta_title = get_term_meta( $object_id, '_custom_meta_title', true );
			$meta_description = get_term_meta( $object_id, '_custom_meta_description', true );
			$noindex = get_term_meta( $object_id, '_custom_noindex', true );
			$nofollow = get_term_meta( $object_id, '_custom_nofollow', true );
			$target_keyword = get_term_meta( $object_id, '_custom_target_keyword', true );
			$meta_og_image = get_term_meta( $object_id, '_custom_meta_og_image', true );
            $content = apply_filters( 'the_content', term_description( $object_id ) );
			$schema = get_term_meta( $object_id, '_custom_schema', true );
			$author_name = get_the_author_meta( 'display_name', get_current_user_id() );
			$title = $object->name;
			$post_date = date( 'c' );
			$modified_date = date( 'c' );
			$url = get_term_link( $object_id, $object->taxonomy );
        }
		elseif ( $type === 'author' ) {
			$object_id = $object->ID;
			$meta_title = get_user_meta( $object_id, '_custom_meta_title', true );
			$meta_description = get_user_meta( $object_id, '_custom_meta_description', true );
			$noindex = get_user_meta( $object_id, '_custom_noindex', true );
			$nofollow = get_user_meta( $object_id, '_custom_nofollow', true );
			$target_keyword = get_user_meta( $object_id, '_custom_target_keyword', true );
			$meta_og_image = get_user_meta( $object_id, '_custom_meta_og_image', true );
            $content = apply_filters( 'the_content', get_the_author_meta( 'description', $object_id ) );
			$schema = get_user_meta( $object_id, '_custom_schema', true );
			$author_name = $object->display_name;
			$title = sprintf( __( 'Archives for %s', ZYNITH_SEO_TEXT_DOMAIN ), $author_name );
			$registered = new DateTime( $object->user_registered );
			$post_date = $registered->format( 'c' );
			$modified_date = $post_date;
			$url = get_author_posts_url( $object_id, $object->user_nicename );
        }
		elseif ( $type === 'post' ) {
			$object_id = $object->ID;
			$meta_title = get_post_meta( $object_id, '_custom_meta_title', true );
			$meta_description = get_post_meta( $object_id, '_custom_meta_description', true );
			$noindex = get_post_meta( $object_id, '_custom_noindex', true );
			$nofollow = get_post_meta( $object_id, '_custom_nofollow', true );
			$target_keyword = get_post_meta( $object_id, '_custom_target_keyword', true );
			$meta_og_image = get_post_meta( $object_id, '_custom_meta_og_image', true );
            $content = apply_filters( 'the_content', $object->post_content );
			$schema = get_post_meta( $object_id, '_custom_schema', true );
			$author_name = get_the_author_meta( 'display_name', $object->post_author );
			$title = get_the_title( $object_id );
			$post_date = get_the_date( 'c', $object_id );
			$modified_date = get_the_modified_date( 'c', $object_id );
			$url = get_permalink( $object_id );
        }
		else { return ''; }
    	
		$business_name = get_option( 'zynith_business_name' );
		$phone_number = get_option( 'zynith_phone_number' );
		$business_email = get_option( 'zynith_business_email' );
		$street_address = get_option( 'zynith_street_address' );
		$address_locality = get_option( 'zynith_address_locality' );
		$address_region = get_option( 'zynith_address_region' );
		$postal_code = get_option( 'zynith_postal_code' );
		$address_country = get_option( 'zynith_address_country' );
		$logo_url = get_option( 'zynith_logo' );
		
		// Signals
		/*
		$seo_signals_metabox_enabled = get_option( 'seo_signals_metabox_enabled', 'yes' );
        $is_metabox_enabled = (bool) ( $seo_signals_metabox_enabled === 'yes' );
		*/
		$signal_options = get_option('zynith_seo_signals_enabled');
		$signals_enabled['fk_grade'] = isset($signal_options['seo_signals_fk_grade_enabled']) && $signal_options['seo_signals_fk_grade_enabled'] === '1';
		$signals_enabled['content_length'] = isset($signal_options['seo_signals_content_length_enabled']) && $signal_options['seo_signals_content_length_enabled'] === '1';
		$signals_enabled['html_ratio'] = isset($signal_options['seo_signals_html_ratio_enabled']) && $signal_options['seo_signals_html_ratio_enabled'] === '1';
		$signals_enabled['broken_links'] = isset($signal_options['seo_signals_broken_links_enabled']) && $signal_options['seo_signals_broken_links_enabled'] === '1';
		$signals_enabled['internal_links'] = isset($signal_options['seo_signals_internal_links_enabled']) && $signal_options['seo_signals_internal_links_enabled'] === '1';
		$signals_enabled['external_links'] = isset($signal_options['seo_signals_external_links_enabled']) && $signal_options['seo_signals_external_links_enabled'] === '1';
		$signals_enabled['ai_content'] = isset($signal_options['seo_signals_ai_content_enabled']) && $signal_options['seo_signals_ai_content_enabled'] === '1';
		$show_signals = false;
		foreach ($signals_enabled as $value) {
    		if ($value === true) {
        		$show_signals = true;
				break;
    		}
		}
		if ($show_signals) {
			$color_blue = "#4285F4"; // Zynith blue: #055DD8
			$color_red = "#D84437"; // Hot pink: #FF00FA
			$color_green = "#81ce71"; // Bright green: #5FDA05;
			$content_length_result = ZynithSEOContentUtility::check_content_length( $content );
			$word_count = str_word_count( wp_strip_all_tags( $content ) );
			$link_counts_result = ZynithSEOContentUtility::check_link_counts( $content );
			$content = get_post_field( 'post_content', get_the_ID() );
			$is_ai_generated = ZynithSEOContentUtility::is_content_ai_generated( $content );
			$broken_links = ZynithSEOContentUtility::detect_broken_links( $content, $object );
			$num_broken_links = count( $broken_links );
			$broken_links_color = ($num_broken_links > 0) ? $color_red : $color_green;
			$broken_links_text = ($num_broken_links > 0) ? __( 'Fail', ZYNITH_SEO_TEXT_DOMAIN ) : __( 'Pass', ZYNITH_SEO_TEXT_DOMAIN );	
			$flesch_kincaid_label = __( 'Flesch-Kincaid Grade Level', ZYNITH_SEO_TEXT_DOMAIN );
			$flesch_kincaid_grade_level = round( ZynithSEOReadability::flesch_kincaid_grade_level( $content ), 2 );
			$flesch_kincaid_difficulty = ZynithSEOReadability::flesch_kincaid_difficulty( $flesch_kincaid_grade_level );
			$flesch_kincaid_color = $color_green;
			if ($flesch_kincaid_grade_level > 12 ) {
				$flesch_kincaid_color = $color_red;
			}
			elseif ($flesch_kincaid_grade_level >= 6) {
				$flesch_kincaid_color = $color_blue;
			}
		}
		
		$grouped_headings = ZynithSEOContentUtility::get_all_headings($content);
		
		// Start of Meta Box
		$html_element = '<h2 class="nav-tab-wrapper">' .
						'<a class="nav-tab nav-tab-active" href="#seo-settings">Settings</a>' .
						'<a class="nav-tab" href="#dynamic-schema">Schema</a>';
		if ($show_signals) { $html_element .= '<a class="nav-tab" href="#seo-signals">Signals</a>'; }
		if (count($grouped_headings) > 0) { $html_element .= '<a class="nav-tab" href="#headings">Headings</a>'; }
		$html_element .= '</h2>';
		
		// * Settings Tab *
		$html_element .=	'<div id="seo-settings" class="tab-content">';
		
		// SERP Preview
		$html_element .=	'<div class="serp-preview">' .
			            		'<h4>' . __('Google SERP Preview:', ZYNITH_SEO_TEXT_DOMAIN) . '</h4>' .
            					'<div class="div_row">' .
                					'<div class="div_col_1">' .
                    					'<p class="serp-preview-title">' . (! empty( $meta_title ) ? esc_html( $meta_title ) : 'Page Title' ) . '</p>' .
                    					'<p class="serp-preview-description">' . ( ! empty( $meta_description ) ? esc_html( $meta_description ) : __( 'Page description will appear here', ZYNITH_SEO_TEXT_DOMAIN ) ) . '</p>' .
                					'</div><!-- End: .div_col_1 -->';
    
        // Add the featured image to the div if available
        if (has_post_thumbnail()) {
            $thumbnail = get_the_post_thumbnail(null, [ 96, 96 ], [ 'class' => 'featured-image' ]);
            $html_element .=		'<div class="div_col_2">' . $thumbnail . '</div><!-- End: .div_col_2 -->';
        }
		$html_element .= 		'</div><!-- End: .div_row -->'.
							'</div><!-- End: .serp-preview -->';
		
		// Meta fields
		$html_element .=	'<label for="custom_meta_title">' . __( 'Meta Title:', ZYNITH_SEO_TEXT_DOMAIN ) . '</label>' .
							'<input type="text" id="custom_meta_title" name="custom_meta_title" value="' . esc_attr( $meta_title ) . '" placeholder="' . __( 'Enter your Meta Title here...', ZYNITH_SEO_TEXT_DOMAIN ) . '" />' .
							'<label for="custom_meta_description">' . __( 'Meta Description:', ZYNITH_SEO_TEXT_DOMAIN ) . '</label>' .
							'<textarea id="custom_meta_description" name="custom_meta_description" placeholder="' . __( 'Enter your Meta Description here...', ZYNITH_SEO_TEXT_DOMAIN ) . '" rows="3">' . esc_textarea( $meta_description ) . '</textarea>';
									
		// Open Graph Image
        $html_element .=	'<label for="custom_meta_og_image">' . __( 'Open Graph Image:', ZYNITH_SEO_TEXT_DOMAIN ) . '</label>' .
            				'<input type="text" id="custom_meta_og_image" name="custom_meta_og_image" value="' . esc_attr( $meta_og_image ) . '" placeholder="' . __( 'Enter the Open Graph Image URL here...', ZYNITH_SEO_TEXT_DOMAIN ) . '" />' .
            				'<div class="div_button_container">' .
								'<button type="button" class="button" id="custom_meta_og_image_button">' . __( 'Choose Image', ZYNITH_SEO_TEXT_DOMAIN ) . '</button>' .
							'</div><!-- End: .div_button_container -->';
		
        // Keyword density
		$html_element .=	'<label for="custom_target_keyword">' . __( 'Target Keyword:', ZYNITH_SEO_TEXT_DOMAIN ) . '</label>' .
            				'<p>' . __( 'Note: Keyword density has been proven to be an inaccurate metric. Please use it at your own risk!', ZYNITH_SEO_TEXT_DOMAIN ) . '</p>' .
            				'<input type="text" id="custom_target_keyword" name="custom_target_keyword" value="' . esc_attr( $target_keyword ) . '"  placeholder="' . __( 'Enter your Keyword here...', ZYNITH_SEO_TEXT_DOMAIN ) . '" />';
		 
        if (! empty( $target_keyword ) ) {
            $keyword_density = ZynithSEOContentUtility::calculate_keyword_density($content, $target_keyword );
            $html_element .= '<p id="p_density">' . sprintf( __('Keyword Density: %s', ZYNITH_SEO_TEXT_DOMAIN ), $keyword_density ) . '%</p>';
        }
        
		// Other SEO Options
		$html_element .= 	'<label>' . __( 'Other SEO Options:', ZYNITH_SEO_TEXT_DOMAIN ) . '</label>
							<div class="checkboxes">
								<label for="custom_noindex">
									<label class="switch">
										<input type="checkbox" id="custom_noindex" name="custom_noindex"' . checked( $noindex, 'yes', false ) . '>
										<span class="slider round"></span>
									</label>
									<span>Noindex</span>
								</label>
								<label for="custom_nofollow">
									<label class="switch">
										<input type="checkbox" id="custom_nofollow" name="custom_nofollow"' . checked( $nofollow, 'yes', false ) . '>
										<span class="slider round"></span>
									</label>
									<span>Nofollow</span>
								</label>' .
							'</div><!-- End: .checkboxes -->';
        
        // Add the missing alt tags message if needed
        if (ZynithSEOContentUtility::check_missing_alt_tags($content)) {
            $html_element .= '<p class="missing-alt-tags-warning">' . sprintf( __('%sWarning:%s Some images on this page are missing alt tags.', ZYNITH_SEO_TEXT_DOMAIN ), '<span>', '</span>' ) . '</p>';
        }    
        
		$html_element .= '</div><!-- End: #seo-settings -->';
		
		// * Schema Tab *
		$html_element .=	'<div id="dynamic-schema" class="tab-content">' .
							wp_nonce_field( 'dynamic_schema_save_postdata', 'dynamic_schema_meta_box_nonce' ) .
							'<label for="dynamic_schema_field">' . __( 'Schema (auto wrapped in JSON-LD):', ZYNITH_SEO_TEXT_DOMAIN ) . '</label>
							<div class="div_button_menu_container">
								<button class="" id="insert_article_schema" type="button" onclick="toggle_schema(this.id);">Article</button>
								<button class="" id="insert_blog_schema" type="button" onclick="toggle_schema(this.id);">Blog</button>
								<button class="" id="insert_creative_work_schema" type="button" onclick="toggle_schema(this.id);">Creative Work</button>
								<button class="" id="insert_event_schema" type="button" onclick="toggle_schema(this.id);">Event</button>
								<button class="" id="insert_faq_schema" type="button" onclick="toggle_schema(this.id);">FAQ</button>
								<button class="" id="insert_local_schema" type="button" onclick="toggle_schema(this.id);">Local</button>
								<button class="" id="insert_person_schema" type="button" onclick="toggle_schema(this.id);">Person</button>
								<button class="" id="insert_place_schema" type="button" onclick="toggle_schema(this.id);">Place</button>
								<button class="" id="insert_recipe_schema" type="button" onclick="toggle_schema(this.id);">Recipe</button>
								<button class="" id="insert_review_schema" type="button" onclick="toggle_schema(this.id);">Review</button>
								<button class="" id="insert_video_schema" type="button" onclick="toggle_schema(this.id);">Video</button>
								<button class="" id="insert_web_page_schema" type="button" onclick="toggle_schema(this.id);">Web Page</button>
							</div>
							<textarea id="dynamic_schema_field" name="dynamic_schema_field" rows="14" placeholder="' . __( 'Enter your Schema here...', ZYNITH_SEO_TEXT_DOMAIN ) . '">' . esc_textarea($schema) . '</textarea>' .
							'</div><!-- End: #dynamic-schema -->';
		
		// * Signals Tab
		if ($show_signals) {
			$html_element .=	'<div id="seo-signals" class="tab-content">';
			
			if ($signals_enabled['fk_grade'] === true) {
				$html_element .=	'<div class="signal_card">'.
									'<div class="signal_code" style="background-color: ' . $flesch_kincaid_color . ';"></div>' .
									'<div class="signal">' .
										'<div class="signal_desc">' . $flesch_kincaid_label . '</div>' .
										'<div class="signal_score">' . $flesch_kincaid_grade_level . '</div>' .
										'<div class="signal_result" style="color: ' . $flesch_kincaid_color . ';">' . $flesch_kincaid_difficulty . '</div>' .
									'</div><!-- End: .signal -->'.
									'</div><!-- End: .signal_card -->';
			}
			
			if ($signals_enabled['content_length'] === true) {
				$content_length_color = $color_red;
				$content_length_label = __( '&lt; 1400 words', ZYNITH_SEO_TEXT_DOMAIN );
				if ($content_length_result) {
					$content_length_color = $color_blue;
					$content_length_label = __( '1400+ words', ZYNITH_SEO_TEXT_DOMAIN );
				}

				$html_element .= '<div class="signal_card"><div class="signal_code" style="background-color: ' . $content_length_color . ';"></div><div class="signal"><div class="signal_desc">Content Length</div><div class="signal_score">' . $word_count . '</div><div class="signal_result" style="color: ' . $content_length_color . ';">' . $content_length_label . '</div></div></div><!-- End: .signal_card -->';
			}

			if ($signals_enabled['html_ratio'] === true) {
				$html_to_text_ratio = ZynithSEOContentUtility::calculate_html_to_text_ratio( $content );
				if ( $html_to_text_ratio > 0 ) {
					$signal_code = ( $html_to_text_ratio >= 80 ) ? $color_blue : $color_red;
					$signal_result = ( $html_to_text_ratio >= 80 ) ? __( 'Ideal', ZYNITH_SEO_TEXT_DOMAIN ) : __( 'Not Ideal', ZYNITH_SEO_TEXT_DOMAIN );
					$html_element .= '<div class="signal_card"><div class="signal_code" style="background-color: ' . $signal_code . ';"></div><div class="signal"><div class="signal_desc">' . __( 'HTML to Text Ratio', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div class="signal_score">' . $html_to_text_ratio . '%</div><div class="signal_result" style="color: ' . $signal_code . ';">' . $signal_result . '</div></div></div>';
				}
			}

			if ($signals_enabled['broken_links'] === true) {
				$html_element .= '<div class="signal_card"><div class="signal_code" style="background-color: ' . $broken_links_color . ';"></div><div class="signal"><div class="signal_desc">' . __( 'Broken Links', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div class="signal_score">' . $num_broken_links . '</div><div class="signal_result" style="color: ' . $broken_links_color . ';">' . $broken_links_text . '</div></div></div>';
			}

			if ($signals_enabled['internal_links'] === true) {
				if ( $link_counts_result['internal_red_light'] ) {
					$html_element .= '<div class="signal_card"><div class="signal_code" style="background-color: ' . $color_red . ';"></div><div class="signal"><div class="signal_desc">' . __( 'Internal Links', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div class="signal_score">' . $link_counts_result['internal_links'] . '</div><div class="signal_result" style="color: ' . $color_red . ';">' . __( '&lt; 3 links', ZYNITH_SEO_TEXT_DOMAIN ) . '</div></div></div>';
				}
				else {
					$html_element .= '<div class="signal_card"><div class="signal_code" style="background-color:' . $color_green . ';"></div><div class="signal"><div class="signal_desc">' . __( 'Internal Links', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div class="signal_score">' . $link_counts_result['internal_links'] . '</div><div class="signal_result" style="color: ' . $color_green . ';">' . __( '&gt;= 3 links', ZYNITH_SEO_TEXT_DOMAIN ) . '</div></div></div>';
				}
			}

			if ($signals_enabled['external_links'] === true) {
				if ( $link_counts_result['external_red_light'] ) {
					$html_element .= '<div class="signal_card"><div class="signal_code" style="background-color: ' . $color_red . ';"></div><div class="signal"><div class="signal_desc">' . __( 'External Links', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div class="signal_score">' . $link_counts_result['external_links'] . '</div><div class="signal_result" style="color: ' . $color_red . ';">' . __( '&lt; 3 links', ZYNITH_SEO_TEXT_DOMAIN ) . '</div></div></div>';
				}
				else {
					$html_element .= '<div class="signal_card"><div class="signal_code" style="background-color: ' . $color_green . ';"></div><div class="signal"><div class="signal_desc">' . __( 'External Links', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div class="signal_score">' . $link_counts_result['external_links'] . '</div><div class="signal_result" style="color: ' . $color_green . ';">' . __( '&gt;= 3 links', ZYNITH_SEO_TEXT_DOMAIN ) . '</div></div></div>';
				}
			}

			if ($signals_enabled['external_links'] === true) {
				if ( $is_ai_generated ) {
					$html_element .= '<div class="signal_card"><div class="signal_code" style="background-color: ' . $color_red . ';"></div><div class="signal"><div class="signal_desc">' . __( 'AI Generated Content', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div class="signal_score" style="color: ' . $color_red . ';">' . __( 'Likely AI', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div id="beta" aria-label="' . __( 'Warning this is a beta.', ZYNITH_SEO_TEXT_DOMAIN ) . '">' . __( 'Beta', ZYNITH_SEO_TEXT_DOMAIN ) . '<span>⚠️</span></div></div></div>';
				}
				else {
					$html_element .= '<div class="signal_card"><div class="signal_code" style="background-color: ' . $color_blue . ';"></div><div class="signal"><div class="signal_desc">' . __( 'AI Generated Content', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div class="signal_score" style="color: ' . $color_blue . ';">' . __( 'Likely Human', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div id="beta" aria-label="' . __( 'Warning this is a beta.', ZYNITH_SEO_TEXT_DOMAIN ) . '">' . __( 'Beta', ZYNITH_SEO_TEXT_DOMAIN ) . '<span>⚠️</span></div></div></div>';
				}
				
			}
			$html_element .=	'</div><!-- End: #seo-signals -->';
		}
		
		// * Headings Tab
		$grouped_headings = ZynithSEOContentUtility::get_all_headings($content);
		if (count($grouped_headings) > 0) {
			$html_element .=	'<div id="headings" class="tab-content">' .
        							'<label>' . __('On Page Headings:', ZYNITH_SEO_TEXT_DOMAIN) . '</label>' .
									'<div class="headings-list">';
        	foreach ($grouped_headings as $level => $headings) {
            	$html_element .=		'<div class="div_heading_container heading_closed" id="div_' . $level . '_heading">' .
											'<div class="div_heading"><p class="heading_closed">' . sprintf( __( '%s Tags:', ZYNITH_SEO_TEXT_DOMAIN ), $level ) . '</p></div>' .
            								'<ul>';
            	foreach ($headings as $heading ) {
                	$html_element .=			'<li>' . $heading . '</li>';
            	}
            	$html_element .=			'</ul>' .
										'</div>';
        	}
        	$html_element .=		'</div>' .
								'</div><!-- End: #headings -->';
		}
		
		?>
		<script>
			const SCHEMA = [{id: "insert_article_schema",value: `{
				"@context": "http://schema.org/",
				"@type": "Article",
				"headline": "<?php echo $title; ?>",
				"datePublished": "<?php echo $post_date; ?>",
				"dateModified": "<?php echo $modified_date; ?>",
				"author": {
					"@type": "Person",
					"name": "<?php echo $author_name; ?>"
				},
				"image": "http://www.example.com/image.jpg",
				"description": "<?php echo $meta_description; ?>"
			},`},
							{id: "insert_blog_schema", value: `{
				"@context": "https://schema.org",
				"@type": "BlogPosting",
				"headline": "<?php echo $title; ?>",
				"datePublished": "<?php echo $post_date; ?>",
				"url": "<?php echo $url; ?>"
			},`},
							{id: "insert_creative_work_schema",value: `{
				"@context": "http://schema.org/",
				"@type": "Book",
				"name": "Example Book",
				"author": {
					"@type": "Person",
					"name": "<?php echo $author_name; ?>"
				},
				"datePublished": "<?php echo $post_date; ?>",
				"publisher": {
					"@type": "Organization",
					"name": "<?php echo get_option( 'zynith_business_name' ); ?>"
				}
			},`},
							{id: "insert_event_schema",value: `{
				"@context": "http://schema.org/",
				"@type": "Event",
				"name": "<?php echo $title; ?>",
				"startDate": "2022-05-01T09:00:00-07:00",
				"endDate": "2022-05-01T17:00:00-07:00",
				"location": {
					"@type": "Place",
					"name": "Example Venue",
					"address": {
						"@type": "PostalAddress",
						"streetAddress": "123 Main St",
						"addressLocality": "Exampleville",
						"addressRegion": "CA",
						"postalCode": "12345",
						"addressCountry": "US"
					}
				}
			},`},
							{id: "insert_faq_schema",value: `{
				"@context": "http://schema.org/",
				"@type": "FAQPage",
				"mainEntity": [
					{
						"@type": "Question",
						"name": "Example Question 1",
						"acceptedAnswer": {
							"@type": "Answer",
							"text": "This is an example answer to question 1."
						}
					},
					{
						"@type": "Question",
						"name": "Example Question 2",
						"acceptedAnswer": {
							"@type": "Answer",
							"text": "This is an example answer to question 2."
						}
					},
					{
						"@type": "Question",
						"name": "Example Question 3",
						"acceptedAnswer": {
							"@type": "Answer",
							"text": "This is an example answer to question 3."
						}
					}
				]
			},`},
							{id: "insert_local_schema",value: `{
        "@context": "https://schema.org",
        "@type": "LocalBusiness",
        "name": "<?php echo $business_name; ?>",
        "url": "<?php echo home_url(); ?>",
        "telephone": "<?php echo $phone_number; ?>", 
        "email": "<?php echo $business_email; ?>",
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "<?php echo $street_address; ?>", 
            "addressLocality": "<?php echo $address_locality; ?>", 
            "addressRegion": "<?php echo $address_region; ?>", 
            "postalCode": "<?php echo $postal_code; ?>", 
            "addressCountry": "<?php echo $address_country; ?>" 
        },
        "image": "<?php echo $logo_url; ?>", 
        "description": "<?php echo get_bloginfo( 'description' ); ?>"}`},
							{id: "insert_person_schema",value: `{
				"@context": "http://schema.org/",
				"@type": "Person",
				"name": "<?php echo $author_name; ?>",
				"jobTitle": "Actor",
				"birthDate": "1970-01-01",
				"gender": "http://schema.org/Male",
				"image": "http://www.example.com/image.jpg",
				"description": "This is an example celebrity."
			},`},
							{id: "insert_place_schema",value: `{
				"@context": "http://schema.org/",
				"@type": "LandmarksOrHistoricalBuildings",
				"name": "<?php echo $title; ?>",
				"address": {
					"@type": "PostalAddress",
					"streetAddress": "123 Main St",
					"addressLocality": "Exampleville",
					"addressRegion": "CA",
					"postalCode": "12345",
					"addressCountry": "US"
				},
				"geo": {
					"@type": "GeoCoordinates",
					"latitude": "37.1234",
					"longitude": "-122.1234"
				}
			},`},
							{id: "insert_recipe_schema",value: `{
				"@context": "http://schema.org/",
				"@type": "Recipe",
				"name": "<?php echo $title; ?>",
				"author": {
					"@type": "Person",
					"name": "<?php echo $author_name; ?>"
				},
				"datePublished": "<?php echo $post_date; ?>",
				"description": "<?php echo $meta_description; ?>",
				"image": "http://www.example.com/image.jpg",
				"recipeIngredient": [
					"2 cups flour",
					"1 cup sugar",
					"1/2 cup milk",
					"1/2 cup butter",
					"2 eggs",
					"1 tsp baking powder",
					"1/2 tsp baking soda",
					"1/2 tsp salt"
				],
				"recipeInstructions": [
					{
						"@type": "HowToStep",
						"text": "Preheat oven to 350°F."
					},
					{
						"@type": "HowToStep",
						"text": "In a large bowl, mix together flour, sugar, baking powder, baking soda, and salt."
					},
					{
						"@type": "HowToStep",
						"text": "In another bowl, beat eggs, then add milk and melted butter."
					},
					{
						"@type": "HowToStep",
						"text": "Add wet ingredients to dry ingredients, and mix until just combined."
					},
					{
						"@type": "HowToStep",
						"text": "Pour batter into a greased 9x9 inch baking dish."
					},
					{
						"@type": "HowToStep",
						"text": "Bake for 25-30 minutes, or until a toothpick inserted into the center comes out clean."
					}
				],
				"nutrition": {
					"@type": "NutritionInformation",
					"servingSize": "1 slice",
					"calories": "250",
					"fatContent": "9g",
					"carbohydrateContent": "38g",
					"proteinContent": "4g"
				}
			},`},
							{id: "insert_review_schema",value: `{
				"@context": "http://schema.org/",
				"@type": "Review",
				"itemReviewed": {
					"@type": "Product",
					"name": "<?php echo $title; ?>"
				},
				"reviewRating": {
					"@type": "Rating",
					"ratingValue": "4.5",
					"bestRating": "5",
					"worstRating": "1"
				},
				"author": {
					"@type": "Person",
					"name": "<?php echo $author_name; ?>"
				},
				"datePublished": "<?php echo $post_date; ?>",
				"description": "<?php echo $meta_description; ?>"
			},`},
							{id: "insert_video_schema",value: `{
				"@context": "http://schema.org/",
				"@type": "VideoObject",
				"name": "<?php echo $title; ?>",
				"description": "<?php echo $meta_description; ?>",
				"thumbnailUrl": "http://www.example.com/thumbnail.jpg",
				"uploadDate": "2022-04-30T12:00:00Z",
				"duration": "PT2M30S",
				"publisher": {
					"@type": "Organization",
					"name": "<?php echo $business_name; ?>"
				},
				"contentUrl": "http://www.example.com/video.mp4"
			},`},
							{id: "insert_web_page_schema",value: `{
				"@context": "http://schema.org/",
				"@type": "WebPage",
				"name": "<?php echo $title; ?>",
				"description": "<?php echo $meta_description; ?>",
				"breadcrumb": [
					{
						"@type": "ListItem",
						"position": 1,
						"name": "Home",
						"item": "http://www.example.com"
					},
					{
						"@type": "ListItem",
						"position": 2,
						"name": "Category",
						"item": "http://www.example.com/category"
					},
					{
						"@type": "ListItem",
						"position": 3,
						"name": "Subcategory",
						"item": "http://www.example.com/category/subcategory"
					},
					{
						"@type": "ListItem",
						"position": 4,
						"name": "Current Page",
						"item": "http://www.example.com/category/subcategory/current-page"
					}
				]
			},`}];
			
			function toggle_schema(el_id) {
				let new_schema = "";
				if (document.getElementById(el_id).classList.contains("button_selected")) { document.getElementById(el_id).classList.remove("button_selected"); }
				else { document.getElementById(el_id).classList.add("button_selected"); }				
				for (let index = 0; index < SCHEMA.length; index++) {
					if (document.getElementById(SCHEMA[index].id).classList.contains("button_selected")) {
						new_schema += SCHEMA[index].value + "\n";
					}
				}
				document.getElementById("dynamic_schema_field").value = new_schema;
			}
		</script>
		<?php
        return $html_element;
	}

    public function custom_seo_metabox( $post ) {
        // Add nonce for security
        wp_nonce_field( 'seo_metabox_nonce_action', 'seo_metabox_nonce' );
    
        // Retrieve and store existing metadata
        echo self::get_custom_seo_metabox( $post );
    }

    public function save_metabox( $post_id, $post ) {
        
		if ( ! isset( $_POST['seo_metabox_nonce'] ) || ! wp_verify_nonce( $_POST['seo_metabox_nonce'], 'seo_metabox_nonce_action' ) ) {
            return;
        }

        if ( ! isset( $_POST['dynamic_schema_meta_box_nonce'] ) || ! wp_verify_nonce( $_POST['dynamic_schema_meta_box_nonce'], 'dynamic_schema_save_postdata' ) ) {
            return;
        }
    
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
    
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
    
        $meta_title = sanitize_text_field( $_POST['custom_meta_title'] );
        $meta_description = sanitize_textarea_field( $_POST['custom_meta_description'] );
        $noindex = isset( $_POST['custom_noindex'] ) && $_POST['custom_noindex'] == 'on' ? 'yes' : 'no';
        $nofollow = isset( $_POST['custom_nofollow'] ) && $_POST['custom_nofollow'] == 'on' ? 'yes' : 'no';
        $schema = sanitize_textarea_field( $_POST['custom_schema'] );
        $target_keyword = sanitize_text_field( $_POST['custom_target_keyword'] );
        $meta_og_image = sanitize_text_field( $_POST['custom_meta_og_image'] );
    
        update_post_meta( $post_id, '_custom_meta_title', $meta_title );
        update_post_meta( $post_id, '_custom_meta_description', $meta_description );
        update_post_meta( $post_id, '_custom_noindex', $noindex );
        update_post_meta( $post_id, '_custom_nofollow', $nofollow );
        update_post_meta( $post_id, '_custom_schema', $schema );
        update_post_meta( $post_id, '_custom_target_keyword', $target_keyword );
        update_post_meta( $post_id, '_custom_meta_og_image', $meta_og_image );
    }
	
}