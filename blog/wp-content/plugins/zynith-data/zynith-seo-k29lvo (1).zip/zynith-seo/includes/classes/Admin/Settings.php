<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class ZynithSEOSettings {
	
	public $option_prefix = 'zynith_';
	public $settings = [];
	
	public function __construct() {
		add_action('admin_menu', [ $this, 'pre_render_settings' ] );
		add_action('admin_init', [ $this, 'register_settings' ] );
		add_action('admin_menu', [ $this, 'add_settings_menus' ] );

		add_action('admin_init', [ $this, 'purge_option' ] );
		add_action('admin_init', [ $this, 'purge_zynith_meta' ] );
		add_action('settings_page_zynith-seo-settings', [ $this, 'add_purge_option' ] );

		add_action('admin_notices', [ $this, 'show_updated_notice' ] );
		add_action('admin_notices', [ $this, 'show_license_notice' ] );
		
		add_action('admin_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
		add_action('admin_post_purge_zynith_meta_keys', [ $this, 'purge_zynith_meta_keys' ] );
	}

	public function pre_render_settings() {
		$this->settings = $this->get_settings();
	}
	
	public function get_settings() {
		$category_example1 = '<code>' . home_url( '/category/uncategorized/' ) . '</code>';
		$category_example2 = '<code>' . home_url( '/uncategorized/' ) . '</code>';
		$settings['zynith-seo-settings'] = [
			'full_title' => __('Zynith SEO Settings', ZYNITH_SEO_TEXT_DOMAIN ),
			'menu_title' => __('Zynith SEO', ZYNITH_SEO_TEXT_DOMAIN ),
			//'tab_title' => 'Settings',
			'groups' => [
				[
					'title' => __('SEO Signals', ZYNITH_SEO_TEXT_DOMAIN),
					'fields' => [
						[
							'id' => 'seo_signals_enabled',
							'type' => 'checkbox_group',
							'label' => __('Show SEO signals:', ZYNITH_SEO_TEXT_DOMAIN ),
							'options' => [
								'seo_signals_fk_grade_enabled' => __( 'Flesch-Kincaid Grade Level', ZYNITH_SEO_TEXT_DOMAIN ),
								'seo_signals_content_length_enabled' => __( 'Content Length', ZYNITH_SEO_TEXT_DOMAIN ),
								'seo_signals_html_ratio_enabled' => __( 'HTML to Text Ratio', ZYNITH_SEO_TEXT_DOMAIN ),
								'seo_signals_broken_links_enabled' => __( 'Broken Links', ZYNITH_SEO_TEXT_DOMAIN ),
								'seo_signals_internal_links_enabled' => __( 'Iternal Links', ZYNITH_SEO_TEXT_DOMAIN ),
								'seo_signals_external_links_enabled' => __( 'External Links', ZYNITH_SEO_TEXT_DOMAIN ),
								'seo_signals_ai_content_enabled' => __( 'AI Generated Content', ZYNITH_SEO_TEXT_DOMAIN )
							],
							'default' => null
						]
					]
				],
				[
					'title' => __( 'Styles', ZYNITH_SEO_TEXT_DOMAIN ),
					'fields' => [
						[
							'id' => 'style_select',
							'type' => 'select',
							'label' => __( 'Select Zynith style:', ZYNITH_SEO_TEXT_DOMAIN ),
							'options' => [
								'default' => __( 'Default', ZYNITH_SEO_TEXT_DOMAIN ),
								'dark' => __( 'Dark Mode', ZYNITH_SEO_TEXT_DOMAIN ),
								'synthwave' => __( 'Synth Wave', ZYNITH_SEO_TEXT_DOMAIN ),
							],
							'default' => 'default',
						],
					],
				],
				[
					'title' => __( 'Category Base', ZYNITH_SEO_TEXT_DOMAIN ),
					'fields' => [
						[
							'id' => 'remove_category_base',
							'type' => 'checkbox',
							'label' => __( 'Category base:', ZYNITH_SEO_TEXT_DOMAIN ),
							'description' => sprintf( __( 'Remove the category base from URLs. Eg. %s becomes %s', ZYNITH_SEO_TEXT_DOMAIN ), $category_example1, $category_example2 ),
							'default' => '',
						],
						[
							'id' => 'notes',
							'type' => 'message',
							'label' => __( 'Professional advice:', ZYNITH_SEO_TEXT_DOMAIN ),
							'description' => '<span style="font-weight: 500; color: #B00020">' . __( 'The option above is generally not recommended, as it can lead to conflicts with page URLs and end up damaging your SEO.', ZYNITH_SEO_TEXT_DOMAIN ) . '</span>',
							'default' => '',
						],
					],
				],
				[
					'title' => __( 'Security', ZYNITH_SEO_TEXT_DOMAIN ),
					'fields' => [
						[
							'id' => 'remove_generator_tags',
							'type' => 'checkbox',
							'label' => __( 'Generator tags:', ZYNITH_SEO_TEXT_DOMAIN ),
							'description' => __( 'Remove generator tags from the source code.', ZYNITH_SEO_TEXT_DOMAIN ),
							'default' => '',
						],
					],
				],
			]
		];
		
		// Business Info
		$settings['zynith-seo-business-info'] = [
			'full_title' => __( 'Business Info', ZYNITH_SEO_TEXT_DOMAIN ),
			'menu_title' => __( 'Business Info', ZYNITH_SEO_TEXT_DOMAIN ),
			//'tab_title' => 'Business Info',
			'groups' => [
				[
					'title' => __( 'General', ZYNITH_SEO_TEXT_DOMAIN ),
					'fields' => [
						[
							'id' => 'business_name',
							'type' => 'text',
							'label' => __( 'Business Name', ZYNITH_SEO_TEXT_DOMAIN ),
							'default' => '',
						],
						[
							'id' => 'business_email',
							'type' => 'text',
							'label' => __( 'Business Email', ZYNITH_SEO_TEXT_DOMAIN ),
							'default' => '',
						],
						[
							'id' => 'phone_number',
							'type' => 'text',
							'label' => __( 'Phone Number', ZYNITH_SEO_TEXT_DOMAIN ),
							'default' => '',
						],
						[
							'id' => 'street_address',
							'type' => 'text',
							'label' => __( 'Street Address', ZYNITH_SEO_TEXT_DOMAIN ),
							'default' => '',
						],
						[
							'id' => 'address_locality',
							'type' => 'text',
							'label' => __( 'Locality', ZYNITH_SEO_TEXT_DOMAIN ),
							'default' => '',
						],
						[
							'id' => 'address_region',
							'type' => 'text',
							'label' => __( 'Region', ZYNITH_SEO_TEXT_DOMAIN ),
							'default' => '',
						],
						[
							'id' => 'postal_code',
							'type' => 'text',
							'label' => __( 'Postal Code', ZYNITH_SEO_TEXT_DOMAIN ),
							'default' => '',
						],
						[
							'id' => 'address_country',
							'type' => 'text',
							'label' => __( 'Country', ZYNITH_SEO_TEXT_DOMAIN ),
							'default' => '',
						],
						[
							'id' => 'logo',
							'type' => 'image',
							'label' => __( 'Logo', ZYNITH_SEO_TEXT_DOMAIN ),
							'default' => '',
						],
					],
				],
			]
		];
		
		// Scripts
		$settings['zynith-seo-gtm'] = [
			'full_title' => __( 'Zynith SEO Scripts', ZYNITH_SEO_TEXT_DOMAIN ),
			'menu_title' => __( 'Scripts', ZYNITH_SEO_TEXT_DOMAIN ),
			//'tab_title' => 'Scripts',
			'groups' => [
				[
					'title' => __( 'Google Tag Manager Scripts', ZYNITH_SEO_TEXT_DOMAIN ),
					'fields' => [
						[
							'id' => 'gtm_header_script',
							'type' => 'textarea',
							'label' => __( 'GTM Header Script', ZYNITH_SEO_TEXT_DOMAIN ),
							'default' => '',
						],
						[
							'id' => 'gtm_body_script',
							'type' => 'textarea',
							'label' => __( 'GTM Body Script', ZYNITH_SEO_TEXT_DOMAIN ),
							'default' => '',
						],
					],
				],
			]
		];
		
		// Robots.txt settings
		$robots_txt_path = ABSPATH . 'robots.txt';
        $robots_txt_content = '';
    
        if ( file_exists( $robots_txt_path ) ) {
            $robots_txt_content = @file_get_contents( $robots_txt_path );
        }

		$settings['zynith-seo-robots-txt'] = [
			'full_title' => __( 'Zynith SEO Robots.txt', ZYNITH_SEO_TEXT_DOMAIN ),
			'menu_title' => __( 'Robots.txt', ZYNITH_SEO_TEXT_DOMAIN ),
			//'tab_title' => 'Robots.txt',
			'groups' => [
				[
					'title' => __( 'SEO Robots.txt Editor', ZYNITH_SEO_TEXT_DOMAIN ),
					'description' => [ $this, 'robots_txt_description' ],
					'fields' => [
						[
							'id' => 'robots_txt_content',
							'type' => 'textarea',
							'label' => __( 'SEO Robots.txt Editor', ZYNITH_SEO_TEXT_DOMAIN ),
							'default' => $robots_txt_content,
						],
					],
				],
			]
		];

		// Robots meta settings
		$settings['zynith-seo-robots-meta'] = [
			'full_title' => __( 'Zynith SEO Robots Meta', ZYNITH_SEO_TEXT_DOMAIN ),
			'menu_title' => __( 'Robots Meta', ZYNITH_SEO_TEXT_DOMAIN ),
			//'tab_title' => 'Robots Meta',
			'groups' => [
				[
					'title' => __( 'Global noindex', ZYNITH_SEO_TEXT_DOMAIN ),
					'fields' => [
						[
							'id' => 'noindex_post_types',
							'type' => 'checkbox_group',
							'label' => __( 'Apply noindex to Post Types', ZYNITH_SEO_TEXT_DOMAIN ),
							'options' => ZynithSEOPostTypes::get_post_types(),
							'default' => '',
						],
						[
							'id' => 'noindex_taxonomies',
							'type' => 'checkbox_group',
							'label' => __( 'Apply noindex to Taxonomies', ZYNITH_SEO_TEXT_DOMAIN ),
							'options' => ZynithSEOTaxonomies::get_taxonomies(),
							'default' => '',
						],
						[
							'id' => 'noindex_archives',
							'type' => 'checkbox_group',
							'label' => __( 'Apply noindex to Archives', ZYNITH_SEO_TEXT_DOMAIN ),
							'options' => [
								'author' => __( 'Author', ZYNITH_SEO_TEXT_DOMAIN ),
								'date' => __( 'Date', ZYNITH_SEO_TEXT_DOMAIN ),
								'search' => __( 'Search', ZYNITH_SEO_TEXT_DOMAIN ),
							],
							'default' => [ 'search' ],
						],
					],
				],
				[
					'title' => __( 'Global nofollow', ZYNITH_SEO_TEXT_DOMAIN ),
					'fields' => [
						[
							'id' => 'nofollow_post_types',
							'type' => 'checkbox_group',
							'label' => __( 'Apply nofollow to Post Types', ZYNITH_SEO_TEXT_DOMAIN ),
							'options' => ZynithSEOPostTypes::get_post_types(),
							'default' => '',
						],
						[
							'id' => 'nofollow_taxonomies',
							'type' => 'checkbox_group',
							'label' => __( 'Apply nofollow to Taxonomies', ZYNITH_SEO_TEXT_DOMAIN ),
							'options' => ZynithSEOTaxonomies::get_taxonomies(),
							'default' => '',
						],
						[
							'id' => 'nofollow_archives',
							'type' => 'checkbox_group',
							'label' => __( 'Apply nofollow to Archives', ZYNITH_SEO_TEXT_DOMAIN ),
							'options' => [
								'author' => __( 'Author', ZYNITH_SEO_TEXT_DOMAIN ),
								'date' => __( 'Date', ZYNITH_SEO_TEXT_DOMAIN ),
								'search' => __( 'Search', ZYNITH_SEO_TEXT_DOMAIN ),
							],
							'default' => '',
						],
					],
				],
			]
		];

		// Breadcrumbs settings
		$settings['zynith-seo-breadcrumbs'] = [
			'full_title' => __( 'Zynith SEO Breadcrumbs', ZYNITH_SEO_TEXT_DOMAIN ),
			'menu_title' => __( 'Breadcrumbs', ZYNITH_SEO_TEXT_DOMAIN ),
			//'tab_title' => 'Breadcrumbs',
			'groups' => [
				[
					'title' => __( 'Implementation', ZYNITH_SEO_TEXT_DOMAIN ),
					'fields' => [
						[
							'id' => 'implementation',
							'type' => 'message',
							'label' => __( 'Instructions', ZYNITH_SEO_TEXT_DOMAIN ),
							'description' => sprintf(
								__( 'You can add breadcrumbs to any content by using the shortcode %s[zynith-breadcrumbs]%s%sTo implement breadcrumbs in your templates, you can use this function %s', ZYNITH_SEO_TEXT_DOMAIN ),
								'<code>',
								'</code>',
								'<br>',
								'<code>&lt;?php zynith_seo_breadcrumbs(); ?&gt;</code>'
							),
							'default' => '',
						],
					],
				],
				[
					'title' => __( 'Schema', ZYNITH_SEO_TEXT_DOMAIN ),
					'fields' => [
						[
							'id' => 'add_breadcrumbs_schema',
							'type' => 'checkbox',
							'label' => __( 'Add breadcrumbs Schema', ZYNITH_SEO_TEXT_DOMAIN ),
							'description' => __( 'Automatically add breadcrumbs Schema when using breadcrumbs', ZYNITH_SEO_TEXT_DOMAIN ),
							'default' => '',
						],
					],
				],
			]
		];

		// License settings
		$settings['zynith-seo-license'] = [
			'full_title' => __( 'Zynith SEO License', ZYNITH_SEO_TEXT_DOMAIN ),
			'menu_title' => __( 'License', ZYNITH_SEO_TEXT_DOMAIN ),
			//'tab_title' => 'License',
			'groups' => [
				[
					'title' => __( 'License Key', ZYNITH_SEO_TEXT_DOMAIN ),
					'fields' => [
						[
							'id' => 'license_key',
							'type' => 'password',
							'label' => __( 'Zynith SEO License Key', ZYNITH_SEO_TEXT_DOMAIN ),
							'description' => __( 'Treat this like a password for security', ZYNITH_SEO_TEXT_DOMAIN ),
							'default' => '',
							'purge_button' => true,
							'purge_button_text' => __( 'Remove Key', ZYNITH_SEO_TEXT_DOMAIN ),
							'confirm_dialog' => __( 'Are you sure you want to remove the license key? You will no longer receive plugin updates!', ZYNITH_SEO_TEXT_DOMAIN ),
						],
					],
				],
			]
		];
		
		return $settings;
	}
	
    public static function init() {
        return new self();
    }

	public function purge_option() {
		$action = htmlspecialchars( filter_input( INPUT_POST, 'action' ) );

		if ( $action !== 'purge-option' ) {
			return;
		}

		$option = htmlspecialchars( filter_input( INPUT_POST, 'option' ) );
		$deleted = (bool) delete_option( $option );
		$message = $deleted ? __( 'We were unable to remove the value.', ZYNITH_SEO_TEXT_DOMAIN ) : '';

		wp_send_json( [ 'success' => $deleted, 'message' => $message ] );
	}

	private function update_robots_txt() {
		$page = filter_input( INPUT_GET, 'page' );

		if ( $page !== 'zynith-seo-robots-txt' ) {
			return false;
		}

		$robots_txt_path = ABSPATH . 'robots.txt';
		$robots_txt = stripslashes_deep( get_option( 'zynith_robots_txt_content' ) );

        // Try to make the file writeable if it isn't already
        @touch( $robots_txt_path );
        @chmod( $robots_txt_path, 0664 );

		if ( @file_put_contents( $robots_txt_path, $robots_txt ) !== false ) {
			$class = 'notice notice-success is-dismissable';
			$message = __( 'Robots.txt file updated successfully.', ZYNITH_SEO_TEXT_DOMAIN );
		} else {
			$class = 'notice error is-dismissable';
			$message = __( 'Robots.txt file could not be saved.', ZYNITH_SEO_TEXT_DOMAIN );
		}

		return sprintf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), esc_html( $message ) );
	}

	public function add_purge_option() {
		$page = filter_input( INPUT_GET, 'page' );
		$action_url = admin_url( 'admin.php?page=' . $page );

		if ( ! empty( $page ) ) {
			$action_url .= '&action=purge-zynith';
			$action_url = add_query_arg( '_wpnonce', wp_create_nonce( 'purge-zynith' ), $action_url );
		}
		
		echo '<hr><div class="postbox zynith_seo purge"><div class="inside">
			<h2>' . __( 'Purge Zynith meta data', ZYNITH_SEO_TEXT_DOMAIN ) . '</h2>
			<a href="' . $action_url . '" id="purge_zynith" class="button button-link-delete delete" onclick="return confirm(\'' . __( 'Are you sure you want to purge Zynith meta data? This cannot be undone.', ZYNITH_SEO_TEXT_DOMAIN ) . '\')">' . __( 'Purge Zynith', ZYNITH_SEO_TEXT_DOMAIN ) . '</a>
		</div></div>';
	}

	public function purge_zynith_meta() {
		$action = filter_input( INPUT_GET, 'action' );

		if ( $action !== 'purge-zynith' ) {
			return;
		}

		$nonce = filter_input( INPUT_GET, '_wpnonce' );

		if ( ! wp_verify_nonce( $nonce, 'purge-zynith' ) ) {
			wp_die( __( 'Verification failed.', ZYNITH_SEO_TEXT_DOMAIN ) );
		}

		global $wpdb;

		$meta_keys = [
			'_custom_meta_title',
			'_custom_meta_description',
			'_custom_noindex',
			'_custom_nofollow',
			'_custom_target_keyword',
			'_custom_schema',
		];

		foreach ($meta_keys as $meta_key) {
			$wpdb->delete( $wpdb->postmeta, [ 'meta_key' => $meta_key ] );
		}

		$page = filter_input( INPUT_GET, 'page' );
		$redirect_url = add_query_arg( 'zynith-purged', 'true', admin_url( 'admin.php?page=' . $page ) );

		wp_redirect( $redirect_url );

		exit;
	}

	public function enqueue_scripts() {
		$zynith_seo_assets = plugin_dir_url( ZYNITH_SEO_FILE ) . 'assets';
		$cdnjs_assets = 'https://cdnjs.cloudflare.com/ajax/libs';

        $selected_style = get_option( 'zynith_style_select', 'default' );
        $admin_stylesheet = 'admin';

        if ( $selected_style !== 'default' ) {
            $admin_stylesheet .= '-' . $selected_style;
        }

        $stylesheet_id = ZYNITH_SEO_TEXT_DOMAIN . '-' . $admin_stylesheet;
		
		wp_enqueue_media();
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_style( $stylesheet_id, $zynith_seo_assets . '/css/' . $admin_stylesheet . '.min.css', [], ZYNITH_SEO_VERSION );
		wp_enqueue_style( 'select2', $cdnjs_assets . '/select2/4.0.13/css/select2.min.css', false, ZYNITH_SEO_VERSION );
		
		wp_register_script( ZYNITH_SEO_TEXT_DOMAIN, $zynith_seo_assets . '/js/admin.min.js', [ 'jquery' ], ZYNITH_SEO_VERSION, true );
		
		wp_enqueue_script( 'select2', $cdnjs_assets . '/select2/4.0.13/js/select2.min.js', [ 'jquery' ], ZYNITH_SEO_VERSION, true );
		wp_enqueue_script( 'wp-color-picker' );
		wp_enqueue_script( ZYNITH_SEO_TEXT_DOMAIN );

		wp_localize_script( ZYNITH_SEO_TEXT_DOMAIN, 'og_image', [
			'title' => __( 'Choose Open Graph Image', ZYNITH_SEO_TEXT_DOMAIN ),
			'button' => __( 'Choose Image', ZYNITH_SEO_TEXT_DOMAIN ),
		] );

        wp_enqueue_script( ZYNITH_SEO_TEXT_DOMAIN );

        wp_localize_script( 'jquery', 'customAdminScript', array(
            'nonce' => wp_create_nonce( 'save_meta_data_nonce' ),
        ) );
	}
	
	public function robots_txt_description() {
		?>
		<p><?php _e( 'Recommended syntax for Robots.txt is the following:', ZYNITH_SEO_TEXT_DOMAIN ); ?></p>
		<p style="padding-left: 10px; border-left: 2px solid #2d80ea;">User-agent: *<br>Disallow: <br>Sitemap: <?php echo home_url( '/sitemap.xml' ); ?></p>
		<?php
	}
	
	public function register_settings() {
		$this->register_settings_fields( $this->settings );
	}
	
	public function add_settings_menus() {
		$counter = 1;
		$main_settings = '';
		
		foreach ($this -> settings as $key => $data ) {
			$full_title = $data['full_title'];
			$menu_title = $data['menu_title'];
			
			if ($counter === 1) {
				$main_settings = $key;
				// add_menu_page( $full_title, $menu_title, 'manage_options', $key, [ $this, 'render_zynith_seo_settings_page' ], 'dashicons-admin-site-alt3', 90 );
				add_menu_page($full_title, $menu_title, 'manage_options', $key, [$this, 'render_zynith_seo_settings_page'], 'dashicons-search', 90);
			}
			else {
				add_submenu_page($main_settings, $full_title, $menu_title, 'manage_options', $key, [$this, 'render_zynith_seo_settings_page']);
			}
			
			// Set the menu name for the first sub-page
			global $submenu;
			if (isset($submenu[$main_settings])) {
				$submenu[$main_settings][0][0] = 'Settings';
			}
			
			++$counter;
		}
		
		
		
	}
	
	public function render_zynith_seo_settings_page() {
		$current_page = htmlspecialchars( filter_input( INPUT_GET, 'page' ) );
		
		if ( ! empty( $this->settings[ $current_page ] ) ) {
			$settings = $this->settings[ $current_page ];
			
			echo '<div class="wrap zynith-wrap">
				<h1>' . $settings['full_title'] . '</h1>
				<form method="post" action="options.php" novalidate="novalidate">';
					//$this->add_tabs();
					settings_fields( $current_page );
					do_settings_sections( $current_page );
					submit_button();
				echo '</form>';

				do_action( 'settings_page_' . $current_page );

			echo '</div>';
		}
	}
	/*
	public function add_tabs() {
		echo'<h2 class="nav-tab-wrapper zynith-tabs">' . "\n";

		$current_page = htmlspecialchars( filter_input( INPUT_GET, 'page' ) );
		foreach ( $this->settings as $key => $section ) {
			$url = admin_url( '/admin.php?page=' . $key );
			$title = $section['tab_title'];
			$active = $current_page == $key ? true : false;

			$class = 'nav-tab';
			if ( ! empty( $active ) ) {
				$class .= ' nav-tab-active';
			}

			echo '<a href="' . esc_attr( $url ) . '" class="' . esc_attr( $class ) . '">' . esc_html( $title ) . '</a>' . "\n";
		}

		echo '</h2>' . "\n";
	}
	*/
	public function register_settings_fields( $settings ) {
		foreach ( $settings as $location => $data ) {
			foreach ( $data['groups'] as $key => $group ) {
				$group_title = $group['title'] ?? '';
				$group_id = sanitize_title( $group_title );
				$description_callback = $group['description'] ?? '__return_empty_string';
				$fields = $group['fields'];
				
				add_settings_section( $group_id, $group_title, $description_callback, $location, [ 'before_section' => '<div class="postbox zynith_seo"><div class="inside">', 'after_section' => '</div></div>' ] );
				
				foreach ( $fields as $field ) {
					if (! is_array($field)) {
						var_dump($field);
						die();
					}
					if ( empty( $field['id'] ) ) {
						$id = md5( ( ! empty( $field['description'] ) ? $field['description'] : $field['type'] ) . microtime( true ) );
						$field['id'] = $this->option_prefix . $id;
					} else {
						$field['id'] = $this->option_prefix . $field['id'];
					}
					
					register_setting( $location, $field['id'] );
					add_settings_field( $field['id'], ( $field['label'] ?? '' ), [ $this, 'render_settings_field' ], $location, $group_id, $field );
				}
			}
		}
	}
	
	public function render_settings_field( $field ) {
		switch ( $field['type'] ) {
			case 'checkbox':
				echo '<fieldset>';
				
				$default = get_option( $field['id'], $field['default'] );
				$disabled = (bool) ( $field['disabled'] ?? false );
				
				echo '<label for="' . esc_attr( $field['id'] ) . '" class="check-switch">';
				echo '<input name="' . esc_attr( $field['id'] ) . '" id="' . esc_attr( $field['id'] ) . '" type="checkbox" value="1"' . ( ! empty( $default ) ? ' checked' : '' ) . ( ! empty( $disabled ) ? ' disabled' : '' ) . '><span class="slider"></span></label>' . $field['description'];
				
				echo '</fieldset>';
				
				break;
			case 'checkbox_group':
				echo '<fieldset>';
				
				if ( ! empty( $field['options'] ) ) {
					$default = get_option( $field['id'], $field['default'] );
					
					if ( ! is_array( $default ) ) {
						$default = [ $default ];
					}
					
					$i = 0;
					foreach ($field['options'] as $key => $label ) {
						if ( ++$i > 1 ) {
							echo '<br>';
						}

						echo '<label for="' . esc_attr( $field['id'] ) . '-' . $i . '" class="check-switch">';
						echo '<input name="' . esc_attr( $field['id'] ) . '[' . $key . ']" id="' . esc_attr( $field['id'] ) . '-' . $i . '" type="checkbox" value="1"' . ( in_array( $key, $default ) || ! empty( $default[ $key ] ) ? ' checked' : '' ) . '><span class="slider"></span></label>' . $label;
					}
				}
				
				if ( ! empty( $field['description'] ) ) {
					echo '<p class="description" id="' . esc_attr( $field['id'] ) . '-description">' . $field['description'] . '</p>';
				}
				
				echo '</fieldset>';
				
				break;
			case 'image':
				$image_id = get_option( $field['id'] );
				$image_object = '';
				
				if ( ! empty( $image_id ) ) {
					$image_object = wp_get_attachment_image( $image_id, 'medium' );
				}
				
				echo '<input name="' . esc_attr( $field['id'] ) . '" id="' . esc_attr( $field['id'] ) . '" type="hidden" value="' . esc_attr( $image_id ) . '">
				<style>#' . esc_attr( $field['id'] ) . '-preview .image img{margin-bottom: 10px;}</style>
				<div id="' . esc_attr( $field['id'] ) . '-preview"><div class="image">' . $image_object . '</div></div>
				<input class="upload-image button" type="button" data-id="' . esc_attr( $field['id'] ) . '" value="' . esc_attr__( 'Choose image', ZYNITH_SEO_TEXT_DOMAIN ) . '">
				<input class="remove-image button" type="button" data-id="' . esc_attr( $field['id'] ) . '" value="' . esc_attr__( 'Remove image', ZYNITH_SEO_TEXT_DOMAIN ) . '"' . ( empty( $image_id ) ? ' style="display: none;"' : '' ) . '>';
				
				if ( ! empty( $field['description'] ) ) {
					echo '<p class="description" id="' . esc_attr( $field['id'] ) . '-description">' . $field['description'] . '</p>';
				}
				
				break;
			case 'select':
				echo '<select name="' . esc_attr( $field['id'] ) . '" id="' . esc_attr( $field['id'] ) . '" class="regular-text styled-select">';
				
				if ( ! empty( $field['options'] ) ) {
					$default = get_option( $field['id'], $field['default'] );
					
					foreach ( $field['options'] as $key => $value ) {
						echo '<option value="' . esc_attr( $key ) . '"' . ( (string) $key === (string) $default ? ' selected' : '' ) . '>' . $value . '</option>';
					}
				}
				
				echo '</select>';
				
				if ( ! empty( $field['description'] ) ) {
					echo '<p class="description" id="' . esc_attr( $field['id'] ) . '-description">' . $field['description'] . '</p>';
				}
				
				break;
			case 'select_multi':
				echo '<select name="' . esc_attr( $field['id'] ) . '[]" id="' . esc_attr( $field['id'] ) . '" class="regular-text styled-select" multiple>';
				
				if ( ! empty( $field['options'] ) ) {
					$default = get_option( $field['id'], $field['default'] );
					
					if ( ! is_array( $default ) ) {
						$default = [ (string) $default ];
					}
					
					foreach ( $field['options'] as $key => $value ) {
						echo '<option value="' . esc_attr( $key ) . '"' . ( in_array( $key, $default ) || ! empty( $default[ $key ] ) ? ' selected' : '' ) . '>' . esc_html( $value ) . '</option>';
					}
				}
				
				echo '</select>';
				
				if ( ! empty( $field['description'] ) ) {
					echo '<p class="description" id="' . esc_attr( $field['id'] ) . '-description">' . $field['description'] . '</p>';
				}
				
				break;
			case 'radio':
				echo '<fieldset>';
				
				if ( ! empty( $field['options'] ) ) {
					$default = get_option( $field['id'], $field['default'] );
					
					$i = 0;
					foreach ( $field['options'] as $key => $value ) {
						if ( ++$i > 1 ) {
							echo '<br>';
						}
						
						echo '<label for="' . esc_attr( $field['id'] ) . '-' . $i . '" class="check-switch"><input name="' . esc_attr( $field['id'] ) . '" id="' . $field['id'] . '-' . $i . '" type="' . esc_attr( $field['type'] ) . '" value="' . esc_attr( $key ) . '"' . ( $key === $default ? ' checked' : '' ) . '><span class="slider"></span></label>' . $value;
					}
				}
				
				if ( ! empty( $field['description'] ) ) {
					echo '<p class="description" id="' . esc_attr( $field['id'] ) . '-description">' . $field['description'] . '</p>';
				}
				
				echo '</fieldset>';
				
				break;
			case 'color':
				$default = get_option( $field['id'], $field['default'] );
				
				echo '<input name="' . esc_attr( $field['id'] ) . '" id="' . esc_attr( $field['id'] ) . '" type="text" value="' . esc_attr( $default ) . '" data-default-color="' . esc_attr( $default ) . '" class="regular-text color-picker">';
				
				if ( ! empty( $field['description'] ) ) {
					echo '<p class="description" id="' . esc_attr( $field['id'] ) . '-description">' . $field['description'] . '</p>';
				}
				
				break;
			case 'textarea':
				$default = get_option( $field['id'], $field['default'] );
				
				echo '<textarea name="' . esc_attr( $field['id'] ) . '" id="' . esc_attr( $field['id'] ) . '" rows="8" class="regular-text code" style="width: 35em">' . esc_html( $default ) . '</textarea>';
				
				if ( ! empty( $field['description'] ) ) {
					echo '<p class="description" id="' . esc_attr( $field['id'] ) . '-description">' . $field['description'] . '</p>';
				}
				
				break;
			case 'number':
				$default = get_option( $field['id'], $field['default'] );
				
				$min = $field['min'] ?? '0';
				$max = $field['max'] ?? null;
				$step = $field['step'] ?? '1';
				$placeholder = $field['placeholder'] ?? '';
				
				echo '<input name="' . esc_attr( $field['id'] ) . '" id="' . esc_attr( $field['id'] ) . '" type="' . esc_attr( $field['type'] ) . '" value="' . esc_attr( $default ) . '" placeholder="' . esc_attr( $placeholder ) . '" min="' . esc_attr( $min ) . '"' . ( ! empty( $max ) ? ' max="' . esc_attr( $max ) . '"' : '' ) . ' step="' . esc_attr( $step ) . '" class="regular-text">';
				
				if ( ! empty( $field['description'] ) ) {
					echo '<p class="description" id="' . esc_attr( $field['id'] ) . '-description">' . $field['description'] . '</p>';
				}
				
				break;
			case 'password':
				$default = get_option( $field['id'] );
				$placeholder = $field['placeholder'] ?? '';
				$purge_button = (bool) ( $field['purge_button'] ?? true );
				$purge_button_text = $field['purge_button_text'] ?? __( 'Purge', ZYNITH_SEO_TEXT_DOMAIN );
				$confirm_dialog = $field['confirm_dialog'] ?? __( 'Are you sure?', ZYNITH_SEO_TEXT_DOMAIN );
				
				echo '<input name="' . esc_attr( $field['id'] ) . '" id="' . esc_attr( $field['id'] ) . '" type="' . esc_attr( $field['type'] ) . '" value="' . esc_attr( $default ) . '" placeholder="' . esc_attr( $placeholder ) . '" class="regular-text">';
				
				if ( ! empty( $default ) && $purge_button ) {
					echo '<a href="#" class="zynith-button purge" data-confirm="' . $confirm_dialog . '">' . $purge_button_text . '</a>';
				}

				if ( ! empty( $field['description'] ) ) {
					echo '<p class="description" id="' . esc_attr( $field['id'] ) . '-description">' . $field['description'] . '</p>';
				}
				
				break;
			case 'editor':
				$default = get_option( $field['id'] );

				wp_editor( $default, esc_attr( $field['id'] ) );
				
				if ( ! empty( $field['description'] ) ) {
					echo '<p class="description" id="' . esc_attr( $field['id'] ) . '-description">' . $field['description'] . '</p>';
				}
				
				break;
			case 'message':
				if ( ! empty( $field['description'] ) ) {
					echo '<div class="description">' . $field['description'] . '</div>';
				}
				
				break;
			case 'text_group':
				echo '<fieldset>';
				
				if ( ! empty( $field['options'] ) ) {
					$saved = get_option( $field['id'], [] );
					
					$i = 0;
					foreach ( $field['options'] as $key => $value ) {
						$default = $saved[ $key ] ?? '';
						
						if ( ++$i > 1 ) {
							echo '<br>';
						}
						
						echo '<label for="' . esc_attr( $field['id'] ) . '-' . $i . '" class="text-group">' . $value . '</label>';
						echo '<input name="' . esc_attr( $field['id'] ) . '[' . $key . ']" id="' . esc_attr( $field['id'] ) . '-' . $i . '" type="text" value="' . esc_attr( $default ) . '" class="regular-text">';
					}
				}
				
				if ( ! empty( $field['description'] ) ) {
					echo '<p class="description" id="' . esc_attr( $field['id'] ) . '-description">' . $field['description'] . '</p>';
				}
				
				echo '</fieldset>';
				
				break;
			default:
				$default = get_option( $field['id'], $field['default'] );
				$placeholder = $field['placeholder'] ?? '';
				
				echo '<input name="' . esc_attr( $field['id'] ) . '" id="' . esc_attr( $field['id'] ) . '" type="' . esc_attr( $field['type'] ) . '" value="' . esc_attr( $default ) . '" placeholder="' . esc_attr( $placeholder ) . '" class="regular-text">';
				
				if ( ! empty( $field['description'] ) ) {
					echo '<p class="description" id="' . esc_attr( $field['id'] ) . '-description">' . $field['description'] . '</p>';
				}
		}
	}

	public function show_updated_notice() {
		if ( ! is_admin() ) {
			return;
		}
		
		$sitemap_error = get_option( 'sitemap_error' );
        if ( ! empty( $sitemap_error ) ) {
            $class = 'notice notice-error';
            $message = __( 'There was a problem generating your sitemap. Our generator returned the following error: ' . $sitemap_error, ZYNITH_SEO_TEXT_DOMAIN );
    
            printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), esc_html( $message ) );
        }

		$purged = filter_input( INPUT_GET, 'zynith-purged' );
        if ( ! empty( $purged ) ) {
            $class = 'notice notice-success is-dismissable';
            $message = __( 'Zynith SEO meta data purged', ZYNITH_SEO_TEXT_DOMAIN );
    
            printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), esc_html( $message ) );
        }

		$settings_pages = array_keys( $this->settings );
		
		$page = filter_input( INPUT_GET, 'page' );
		if ( ! in_array( $page, $settings_pages ) ) {
			return;
		}
		
		$updated = filter_input( INPUT_GET, 'settings-updated' );
		if ( empty( $updated ) ) {
			return;
		}

		$update_robots_txt = $this->update_robots_txt();

		if ( ! $update_robots_txt ) {
			$class = 'notice notice-success is-dismissable';
			$message = __( 'Settings saved', ZYNITH_SEO_TEXT_DOMAIN );
	
			printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), esc_html( $message ) );
		} else {
			echo $update_robots_txt;
		}

		flush_rewrite_rules();
	}

	public function show_license_notice() {
		if ( ! is_admin() ) {
			return;
		}
		
		$license_key = get_option( 'zynith_license_key' );
        if ( ! empty( $license_key ) ) {
            return;
        }

		$class = 'notice notice-error';
		$message = sprintf( __( 'You will not be able to update Zynith SEO until you enter a valid license key. %sClick here%s to enter your key.', ZYNITH_SEO_TEXT_DOMAIN ), '<a href="' . admin_url( '/admin.php?page=zynith-seo-license' ) . '">', '</a>' );

		printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), $message );
	}
	
}
