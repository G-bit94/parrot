<?php

class ZynithMetaBoxes extends ZynithPostTypes {

    public function __construct() {
        add_action( 'load-post.php', [ $this, 'init_metaboxes' ] );
        add_action( 'load-post-new.php', [ $this, 'init_metaboxes' ] );
    }

    public static function init() {
        return new self();
    }

    public function init_metaboxes() {
        if ( ! is_admin() ) {
            return;
        }

        add_action( 'add_meta_boxes', [ $this, 'add_metaboxes' ] );
        add_action( 'save_post', [ $this, 'save_seo_metabox' ], 10 );
    }

    public function add_metaboxes() {
        $post_types = array_keys( parent::get_post_types() );

        add_meta_box(
            'custom_seo_metabox',
            __( 'SEO Settings', ZYNITH_SEO_TEXT_DOMAIN ),
            [ $this, 'custom_seo_metabox' ],
            $post_types,
            'advanced',
            'high'
        );

        $seo_signals_metabox_enabled = get_option( 'seo_signals_metabox_enabled', 'yes' );
        $is_metabox_enabled = (bool) ( $seo_signals_metabox_enabled === 'yes' );

        if ( $is_metabox_enabled ) {
            add_meta_box(
                'seo_signals_metabox', // id
                'SEO Signals',
                [ $this, 'seo_signals_metabox' ],
                $post_types,
                'advanced',
                'low'
            );
        }
    }

    public function custom_seo_metabox( $post ) {
        // Add nonce for security
        wp_nonce_field( 'seo_metabox_nonce_action', 'seo_metabox_nonce' );
    
        // Retrieve and store existing metadata
        $meta_title = get_post_meta( $post->ID, '_custom_meta_title', true );
        $meta_description = get_post_meta( $post->ID, '_custom_meta_description', true );
        $noindex = get_post_meta( $post->ID, '_custom_noindex', true );
        $nofollow = get_post_meta( $post->ID, '_custom_nofollow', true );
        $schema = get_post_meta( $post->ID, '_custom_schema', true );
        $target_keyword = get_post_meta( $post->ID, '_custom_target_keyword', true );
        $meta_og_image = get_post_meta( $post->ID, '_custom_meta_og_image', true );
    
        // Create the HTML form elements for the meta box
        $html_element = '<label for="custom_meta_title">' . __( 'Meta Title:', ZYNITH_SEO_TEXT_DOMAIN ) . '</label>
            <input type="text" id="custom_meta_title" name="custom_meta_title" value="' . esc_attr( $meta_title ) . '" placeholder="' . __( 'Enter your Meta Title here...', ZYNITH_SEO_TEXT_DOMAIN ) . '">
            <label for="custom_meta_description">' . __( 'Meta Description:', ZYNITH_SEO_TEXT_DOMAIN ) . '</label>
            <textarea id="custom_meta_description" name="custom_meta_description" placeholder="' . __( 'Enter your Meta Description here...', ZYNITH_SEO_TEXT_DOMAIN ) . '">' . esc_textarea( $meta_description ) . '</textarea>
            
            <label for="custom_schema">' . __( 'Schema (auto wrapped in JSON LD):', ZYNITH_SEO_TEXT_DOMAIN ) . '</label>
            <div class="div_button_menu_container">
                <button class="" id="insert_article_schema" type="button" onclick="toggle_schema(this.id);">Article</button>
                <button class="" id="insert_creative_work_schema" type="button" onclick="toggle_schema(this.id);">Creative Work</button>
                <button class="" id="insert_event_schema" type="button" onclick="toggle_schema(this.id);">Event</button>
                <button class="" id="insert_faq_schema" type="button" onclick="toggle_schema(this.id);">FAQ</button>
                <button class="" id="insert_local_schema" type="button" onclick="toggle_schema(this.id);">Local Business</button>
                <button class="" id="insert_person_schema" type="button" onclick="toggle_schema(this.id);">Person</button>
                <button class="" id="insert_place_schema" type="button" onclick="toggle_schema(this.id);">Place</button>
                <button class="" id="insert_recipe_schema" type="button" onclick="toggle_schema(this.id);">Recipe</button>
                <button class="" id="insert_review_schema" type="button" onclick="toggle_schema(this.id);">Review</button>
                <button class="" id="insert_video_schema" type="button" onclick="toggle_schema(this.id);">Video</button>
                <button class="" id="insert_web_page_schema" type="button" onclick="toggle_schema(this.id);">Web Page</button>
            </div>
            <textarea id="custom_schema" name="custom_schema" placeholder="' . __( 'Enter your Schema here...', ZYNITH_SEO_TEXT_DOMAIN ) . '">' . esc_textarea( $schema ) . '</textarea>
            <label for="custom_target_keyword">' . __( 'Target Keyword:', ZYNITH_SEO_TEXT_DOMAIN ) . '</label>
            <p>' . __( 'Note: Keyword density has been proven to be an inaccurate metric. Please use it at your own risk!', ZYNITH_SEO_TEXT_DOMAIN ) . '</p>
            <input type="text" id="custom_target_keyword" name="custom_target_keyword" value="' . esc_attr( $target_keyword ) . '"  placeholder="' . __( 'Enter your Keyword here...', ZYNITH_SEO_TEXT_DOMAIN ) . '">';
    
        // Calculate keyword density if target keyword is set
        if ( ! empty( $target_keyword ) ) {
            $keyword_density = ZynithContentUtility::calculate_keyword_density( $post->post_content, $target_keyword );
            $html_element .= '<p id="p_density">' . sprintf( __( 'Keyword Density: %s', ZYNITH_SEO_TEXT_DOMAIN ), $keyword_density ) . '%</p>';
        }
        
        // Upload Open Graph Image
        $html_element .= '<label for="custom_meta_og_image">' . __( 'Open Graph Image:', ZYNITH_SEO_TEXT_DOMAIN ) . '</label>
            <input type="text" id="custom_meta_og_image" name="custom_meta_og_image" value="' . esc_attr( $meta_og_image ) . '" placeholder="' . __( 'Enter the Open Graph Image URL here...', ZYNITH_SEO_TEXT_DOMAIN ) . '">
            <div class="div_button_container"><button type="button" style="margin-left: 10px;" class="button" id="custom_meta_og_image_button">' . __( 'Choose Image', ZYNITH_SEO_TEXT_DOMAIN ) . '</button></div>
            <label>' . __( 'Other SEO Options:', ZYNITH_SEO_TEXT_DOMAIN ) . '</label>
            <div class="checkboxes">
            <label for="custom_noindex">
                <label class="switch">
                    <input type="checkbox" id="custom_noindex" name="custom_noindex"' . checked( $noindex, 'yes', false ) . '>
                    <span class="slider round"></span>
                </label>
                <span>Noindex</span>
            </label>
            <label for="custom_nofollow">
                <label class="switch">
                    <input type="checkbox" id="custom_nofollow" name="custom_nofollow"' . checked( $nofollow, 'yes', false ) . '>
                    <span class="slider round"></span>
                </label>
                <span>Nofollow</span>
            </label>
        </div>';
                
        // Get the headings
        $grouped_headings = ZynithContentUtility::get_all_headings( $post->ID );
        $html_element .= '<label>' . __( 'On Page Headings:', ZYNITH_SEO_TEXT_DOMAIN ) . '</label><div class="headings-list">';
    
        foreach ( $grouped_headings as $level => $headings ) {
            $html_element .= '<div class="div_heading_container heading_closed" id="div_' . $level . '_heading"><div class="div_heading"><p class="heading_closed">' . sprintf( __( '%s Tags:', ZYNITH_SEO_TEXT_DOMAIN ), $level ) . '</p></div>';
            $html_element .= '<ul>';

            foreach ( $headings as $heading ) {
                $html_element .= "<li>$heading</li>";
            }

            $html_element .= '</ul></div>';
        }
    
        $html_element .= '</div>';
    
        // Add the missing alt tags message if needed
        if ( ZynithContentUtility::check_missing_alt_tags( $post->ID ) ) {
            $html_element .= '<p class="missing-alt-tags-warning">' . sprintf( __( '%sWarning:%s Some images on this page are missing alt tags.', ZYNITH_SEO_TEXT_DOMAIN ), '<span>', '</span>' ) . '</p>';
        }
            
        $html_element .= '</div><div class="serp-preview">
            <h4>' . __( 'Google SERP Preview:', ZYNITH_SEO_TEXT_DOMAIN ) . '</h4>
            <div class="div_row">
                <div class="div_col_1">
                    <p class="serp-preview-title">' . ( ! empty( $meta_title ) ? esc_html( $meta_title ) : 'Page Title' ) . '</p>
                    <p class="serp-preview-description">' . ( ! empty( $meta_description ) ? esc_html( $meta_description ) : __( 'Page description will appear here', ZYNITH_SEO_TEXT_DOMAIN ) ) . '</p>
                </div><!-- End: .div_col_1 -->';
    
        // Add the featured image to the div if available
        if ( has_post_thumbnail() ) {
            $thumbnail = get_the_post_thumbnail( null, [ 96, 96 ], [ 'class' => 'featured-image' ] );
            $html_element .= '<div class="div_col_2">' . $thumbnail . '</div><!-- End: .div_col_2 -->';
        }
    
        $html_element .= '</div><!-- End: .div_row -->';

        echo $html_element;
    }

    public function seo_signals_metabox( $post ) {
        $content = get_post_field( 'post_content', $post->ID );
        $content_length_result = ZynithContentUtility::check_content_length( $content );
        $word_count = str_word_count( wp_strip_all_tags( $content ) );
        $link_counts_result = ZynithContentUtility::check_link_counts( $post );
        $meta_box_html = '<div class="signal_card"><div class="signal_code" style="background-color: ';
        $content = get_post_field( 'post_content', get_the_ID() );
        $is_ai_generated = ZynithContentUtility::is_content_ai_generated( $content );
        $color_blue = "#4285F4"; // Zynith blue: #055DD8
        $color_red = "#D84437"; // Hot pink: #FF00FA
        $color_green = "#81ce71"; // Bright green: #5FDA05;
        $broken_links = ZynithContentUtility::detect_broken_links( $content );
        $num_broken_links = count( $broken_links );
        $broken_links_color = ($num_broken_links > 0) ? $color_red : $color_green;
        $broken_links_text = ($num_broken_links > 0) ? __( 'Fail', ZYNITH_SEO_TEXT_DOMAIN ) : __( 'Pass', ZYNITH_SEO_TEXT_DOMAIN );	

        $flesch_kincaid_label = __( 'Flesch-Kincaid Grade Level', ZYNITH_SEO_TEXT_DOMAIN );
        $flesch_kincaid_grade_level = round( ZynithReadability::flesch_kincaid_grade_level( $content ), 2 );
        $flesch_kincaid_difficulty = ZynithReadability::flesch_kincaid_difficulty( $flesch_kincaid_grade_level );
        $flesch_kincaid_color = $color_green;
        
        // Flesch-Kincaid Grade Level
        if ( $flesch_kincaid_grade_level > 12 ) {
            $flesch_kincaid_color = $color_red;
        } elseif ($flesch_kincaid_grade_level >= 6) {
            $flesch_kincaid_color = $color_blue;
        }
        
        $meta_box_html .= $flesch_kincaid_color . ';"></div><div class="signal"><div class="signal_desc">' . $flesch_kincaid_label . '</div><div class="signal_score">' . $flesch_kincaid_grade_level . '</div><div class="signal_result" style="color: ' . $flesch_kincaid_color . ';">' . $flesch_kincaid_difficulty . '</div></div></div>';
    
        // Content Length
        $content_length_color = $color_red;
        $content_length_label = __( '&lt; 1400 words', ZYNITH_SEO_TEXT_DOMAIN );
        if ($content_length_result) {
            $content_length_color = $color_blue;
            $content_length_label = __( '1400+ words', ZYNITH_SEO_TEXT_DOMAIN );
        }

        $meta_box_html .= '<div class="signal_card"><div class="signal_code" style="background-color: ' . $content_length_color . ';"></div><div class="signal"><div class="signal_desc">Content Length</div><div class="signal_score">' . $word_count . '</div><div class="signal_result" style="color: ' . $content_length_color . ';">' . $content_length_label . '</div></div></div>';
        
        // HTML to Text Ratio
        $html_to_text_ratio = ZynithContentUtility::calculate_html_to_text_ratio( $post );
        if ( $html_to_text_ratio > 0 ) {
            $signal_code = ( $html_to_text_ratio >= 80 ) ? $color_blue : $color_red;
            $signal_result = ( $html_to_text_ratio >= 80 ) ? __( 'Ideal', ZYNITH_SEO_TEXT_DOMAIN ) : __( 'Not Ideal', ZYNITH_SEO_TEXT_DOMAIN );
            $meta_box_html .= '<div class="signal_card"><div class="signal_code" style="background-color: ' . $signal_code . ';"></div><div class="signal"><div class="signal_desc">' . __( 'HTML to Text Ratio', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div class="signal_score">' . $html_to_text_ratio . '%</div><div class="signal_result" style="color: ' . $signal_code . ';">' . $signal_result . '</div></div></div>';
        }

        // Broken Links
        $meta_box_html .= '<div class="signal_card"><div class="signal_code" style="background-color: ' . $broken_links_color . ';"></div><div class="signal"><div class="signal_desc">' . __( 'Broken Links', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div class="signal_score">' . $num_broken_links . '</div><div class="signal_result" style="color: ' . $broken_links_color . ';">' . $broken_links_text . '</div></div></div>';
        
        // Internal Links
        if ( $link_counts_result['internal_red_light'] ) {
            $meta_box_html .= '<div class="signal_card"><div class="signal_code" style="background-color: ' . $color_red . ';"></div><div class="signal"><div class="signal_desc">' . __( 'Internal Links', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div class="signal_score">' . $link_counts_result['internal_links'] . '</div><div class="signal_result" style="color: ' . $color_red . ';">' . __( '&lt; 3 links', ZYNITH_SEO_TEXT_DOMAIN ) . '</div></div></div>';
        } else {
            $meta_box_html .= '<div class="signal_card"><div class="signal_code" style="background-color:' . $color_green . ';"></div><div class="signal"><div class="signal_desc">' . __( 'Internal Links', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div class="signal_score">' . $link_counts_result['internal_links'] . '</div><div class="signal_result" style="color: ' . $color_green . ';">' . __( '&gt;= 3 links', ZYNITH_SEO_TEXT_DOMAIN ) . '</div></div></div>';
        }
    
        // External Links
        if ( $link_counts_result['external_red_light'] ) {
            $meta_box_html .= '<div class="signal_card"><div class="signal_code" style="background-color: ' . $color_red . ';"></div><div class="signal"><div class="signal_desc">' . __( 'External Links', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div class="signal_score">' . $link_counts_result['external_links'] . '</div><div class="signal_result" style="color: ' . $color_red . ';">' . __( '&lt; 3 links', ZYNITH_SEO_TEXT_DOMAIN ) . '</div></div></div>';
        } else {
            $meta_box_html .= '<div class="signal_card"><div class="signal_code" style="background-color: ' . $color_green . ';"></div><div class="signal"><div class="signal_desc">' . __( 'External Links', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div class="signal_score">' . $link_counts_result['external_links'] . '</div><div class="signal_result" style="color: ' . $color_green . ';">' . __( '&gt;= 3 links', ZYNITH_SEO_TEXT_DOMAIN ) . '</div></div></div>';
        }
    
        // Check if content is AI generated
        if ( $is_ai_generated ) {
            $meta_box_html .= '<div class="signal_card"><div class="signal_code" style="background-color: ' . $color_red . ';"></div><div class="signal"><div class="signal_desc">' . __( 'AI Generated Content', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div class="signal_score" style="color: ' . $color_red . ';">' . __( 'Likely AI', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div id="beta" aria-label="' . __( 'Warning this is a beta.', ZYNITH_SEO_TEXT_DOMAIN ) . '">' . __( 'Beta', ZYNITH_SEO_TEXT_DOMAIN ) . '<span>⚠️</span></div></div></div>';
        } else {
            $meta_box_html .= '<div class="signal_card"><div class="signal_code" style="background-color: ' . $color_blue . ';"></div><div class="signal"><div class="signal_desc">' . __( 'AI Generated Content', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div class="signal_score" style="color: ' . $color_blue . ';">' . __( 'Likely Human', ZYNITH_SEO_TEXT_DOMAIN ) . '</div><div id="beta" aria-label="' . __( 'Warning this is a beta.', ZYNITH_SEO_TEXT_DOMAIN ) . '">' . __( 'Beta', ZYNITH_SEO_TEXT_DOMAIN ) . '<span>⚠️</span></div></div></div>';
        }

        echo $meta_box_html;
    }

    public function save_seo_metabox( $post_id ) {
        if ( ! isset( $_POST['seo_metabox_nonce'] ) || ! wp_verify_nonce( $_POST['seo_metabox_nonce'], 'seo_metabox_nonce_action' ) ) {
            return;
        }
    
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
    
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
    
        $meta_title = sanitize_text_field( $_POST['custom_meta_title'] );
        $meta_description = sanitize_textarea_field( $_POST['custom_meta_description'] );
        $noindex = isset( $_POST['custom_noindex'] ) && $_POST['custom_noindex'] == 'on' ? 'yes' : 'no';
        $nofollow = isset( $_POST['custom_nofollow'] ) && $_POST['custom_nofollow'] == 'on' ? 'yes' : 'no';
        $schema = sanitize_textarea_field( $_POST['custom_schema'] );
        $target_keyword = sanitize_text_field( $_POST['custom_target_keyword'] );
        $meta_og_image = sanitize_text_field( $_POST['custom_meta_og_image'] );
    
        update_post_meta( $post_id, '_custom_meta_title', $meta_title );
        update_post_meta( $post_id, '_custom_meta_description', $meta_description );
        update_post_meta( $post_id, '_custom_noindex', $noindex );
        update_post_meta( $post_id, '_custom_nofollow', $nofollow );
        update_post_meta( $post_id, '_custom_schema', $schema );
        update_post_meta( $post_id, '_custom_target_keyword', $target_keyword );
        update_post_meta( $post_id, '_custom_meta_og_image', $meta_og_image );
    }
}
