<?php

class ZynithPostTypes {

    public function __construct() {
        //
    }

    public static function init() {
        return new self();
    }

    public static function get_post_types() {
        $post_types_initial = get_post_types( [ 'public' => true ], 'objects' );
		$post_types_return = [];
		
		unset( $post_types_initial['attachment'] );
		
		foreach ( $post_types_initial as $post_type ) {
			$post_types_return[ $post_type->name ] = $post_type->label;
		}
		
		return $post_types_return;
    }

}
