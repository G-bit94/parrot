<?php

class ZynithSettings {

    public $post_types;

    public function __construct() {
        $this->post_types = array_keys(ZynithPostTypes::get_post_types() );
		
		add_action('admin_menu', [$this, 'add_zynith_menu']);
        add_action( 'admin_init', [ $this, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'load_admin_assets' ] );
        add_action( 'admin_notices', [ $this, 'add_admin_notices' ] );
        add_action( 'admin_post_purge_zynith_meta_keys', [ $this, 'purge_zynith_meta_keys' ] );

        // Move to another file
        add_action( 'wp_head', [ $this, 'scripts_insert_head' ] );
        add_action( 'wp_footer', [ $this, 'scripts_insert_body' ] );
    }

    public static function init() {
        return new self();
    }

    public function load_admin_assets() {
        $zynith_assets = plugin_dir_url( ZYNITH_SEO_FILE ) . 'assets';
		
		wp_register_script( ZYNITH_SEO_TEXT_DOMAIN, $zynith_assets . '/js/admin.min.js', [ 'jquery' ], ZYNITH_SEO_VERSION, true );

		wp_localize_script( ZYNITH_SEO_TEXT_DOMAIN, 'og_image', [
			'title' => __( 'Choose Open Graph Image', ZYNITH_SEO_TEXT_DOMAIN ),
			'button' => __( 'Choose Image', ZYNITH_SEO_TEXT_DOMAIN ),
		] );

        wp_enqueue_script( ZYNITH_SEO_TEXT_DOMAIN );

        $selected_style = get_option( 'zynith_style_select', 'default' );
        $admin_stylesheet = 'admin';

        if ( $selected_style !== 'default' ) {
            $admin_stylesheet .= '-' . $selected_style;
        }

        $stylesheet_id = ZYNITH_SEO_TEXT_DOMAIN . '-' . $admin_stylesheet;
        wp_enqueue_style( $stylesheet_id, $zynith_assets . '/css/' . $admin_stylesheet . '.min.css', [], ZYNITH_SEO_VERSION );

        wp_localize_script( 'jquery', 'customAdminScript', array(
            'nonce' => wp_create_nonce( 'save_meta_data_nonce' ),
        ) );
    }

    // Register and define the settings
    public function register_settings() {
        register_setting( 'gtm_scripts_options_group', 'gtm_header_script' );
        register_setting( 'gtm_scripts_options_group', 'gtm_body_script' );
    }

    // Add GTM scripts to the head section
    public function scripts_insert_head() {
        echo get_option( 'gtm_header_script' );
    }

    // Add GTM scripts to the body section
    public function scripts_insert_body() {
        echo get_option( 'gtm_body_script' );
    }

    public function add_admin_notices() {
        $sitemap_error = get_option( 'sitemap_error' );
        if ( ! empty( $sitemap_error ) ) {
            $class = 'notice notice-error';
            $message = __( 'There was a problem generating your sitemap. Our generator returned the following error: ' . $sitemap_error, ZYNITH_SEO_TEXT_DOMAIN );
    
            printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), esc_html( $message ) );
        }

        $settings_updated = filter_input( INPUT_GET, 'settings-updated' );
		if ( ! empty( $settings_updated ) ) {
            $class = 'notice notice-success';
            $message = __( 'Settings saved', ZYNITH_SEO_TEXT_DOMAIN );
    
            printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), esc_html( $message ) );
		}
    }
	
	public function add_zynith_menu() {
        add_menu_page(
			'Zynith', // Page title
			'Zynith', // Menu title
			'manage_options', // Capability
			'zynith', // Menu slug
			[$this, 'seo_robots_txt_editor_page'], // Callback function
			'dashicons-admin-site-alt3', // Menu icon
			100 // Menu position
		);
		
		add_submenu_page(
			'zynith', // Main menu slug
			'Robots.txt Editor', // Page title
			'Robots.txt Editor', // Menu title
			'manage_options', // Capability
			'zynith', // Sub-menu slug
			[$this, 'seo_robots_txt_editor_page'], // Callback function
		);
		
		add_submenu_page(
			'zynith', // Main menu slug
			'Scripts', // Page title
			'Scripts', // Menu title
			'manage_options', // Capability
			'zynith-scripts', // Sub-menu slug
			[$this, 'scripts_options_page'] // Callback function
		);
		
		add_submenu_page(
			'zynith', // Main menu slug
			'Zynith Settings', // Page title
			'Settings', // Menu title
			'manage_options', // Capability
			'zynith-settings', // Sub-menu slug
			[$this, 'zynith_settings_page'] // Callback function
		);
		
    }
	
    public function seo_robots_txt_editor_page() {
		if (!current_user_can('manage_options')) {
            wp_die( __( 'You do not have sufficient permissions to access this page.', ZYNITH_SEO_TEXT_DOMAIN ) );
        }
        
		$robots_txt_path = ABSPATH . 'robots.txt';
        $robots_txt_content = '';
    
        if ( file_exists( $robots_txt_path ) ) {
            $robots_txt_content = @file_get_contents( $robots_txt_path );
        }
    
        if ( isset( $_POST['save_robobts_txt'] ) ) {
            if ( wp_verify_nonce( $_POST['custom_robots_txt_action'], 'robots_txt_content' ) ) {
                $updated_content = stripslashes_deep( $_POST['robots_txt_content'] );

                if ( @file_put_contents( $robots_txt_path, $updated_content ) !== false ) {
                    $robots_txt_content = $updated_content;

                    echo '<div id="message" class="updated notice is-dismissible"><p>' . __( 'Robots.txt file updated successfully.', ZYNITH_SEO_TEXT_DOMAIN ) . '</p></div>';
                } else {
                    echo '<div id="message" class="error notice is-dismissible"><p>' . __( 'Robots.txt file could not be saved.', ZYNITH_SEO_TEXT_DOMAIN ) . '</p></div>';
                }
            } else {
                echo '<div id="message" class="error notice is-dismissible"><p>' . __( 'Robots.txt file could not be saved.', ZYNITH_SEO_TEXT_DOMAIN ) . '</p></div>';
            }
        }
		
		?>
        <div class="wrap">
            <h1><?php _e( 'SEO Robots.txt Editor', ZYNITH_SEO_TEXT_DOMAIN ); ?></h1>
            <p><?php _e( 'Recommended syntax for Robots.txt is the following:', ZYNITH_SEO_TEXT_DOMAIN ); ?></p>
            <p>User-agent: *<br>Disallow: <br>ZynithSitemap: https://www.example.com/sitemap.xml</p>

            <form method="post" action="">
                <?php wp_nonce_field( 'robots_txt_content', 'custom_robots_txt_action' ); ?>
                
                <table class="form-table">
                    <tr>
                        <td style="padding:0 0;">
                            <textarea name="robots_txt_content" rows="10" cols="80" class="large-text code"><?php echo esc_textarea( $robots_txt_content ); ?></textarea>
                        </td>
                    </tr>
                </table>

                <p class="submit">
                    <input type="submit" name="save_robobts_txt" id="submit" class="button button-primary" value="<?php _e( 'Save Changes', ZYNITH_SEO_TEXT_DOMAIN ); ?>">
                </p>
            </form>
        </div>
		<?php
    }

	public function scripts_options_page() {
		?>
		<div class="wrap">
            <h1><?php _e( 'Google Tag Manager Scripts', ZYNITH_SEO_TEXT_DOMAIN ); ?></h1>
			<form method="post" action="options.php">
				<?php
					settings_fields('gtm_scripts_options_group');
					do_settings_sections('gtm_scripts_options_group');
				?>
				<table class="form-table">
					<tr valign="top">
						<th scope="row"><?php _e( 'GTM Header Script', ZYNITH_SEO_TEXT_DOMAIN ); ?></th>
						<td><textarea name="gtm_header_script" rows="10" cols="50"><?php echo esc_textarea( get_option('gtm_header_script') ); ?></textarea></td>
					</tr>
					<tr valign="top">
						<th scope="row"><?php _e( 'GTM Body Script', ZYNITH_SEO_TEXT_DOMAIN ); ?></th>
						<td><textarea name="gtm_body_script" rows="10" cols="50"><?php echo esc_textarea( get_option('gtm_body_script') ); ?></textarea></td>
					</tr>
				</table>
                
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
	
	public function zynith_settings_page() {
		// Handle the metabox toggle.
        if ( isset( $_GET['zynith_purged'] ) && $_GET['zynith_purged'] === 'true' ) {
    		echo '<div id="message" class="updated notice is-dismissible"><p>' . __( 'Zynith meta keys purged successfully.', ZYNITH_SEO_TEXT_DOMAIN ) . '</p></div>';
		}

        if ( isset( $_POST['toggle_metabox'] ) ) {
            if ( wp_verify_nonce( $_POST['seo_toggle_metabox_action'], 'seo_toggle_metabox' ) ) {
                $seo_signals_metabox_enabled = ! empty( $_POST['seo_signals_metabox_enabled'] ) ? 'yes' : 'no';
                update_option( 'seo_signals_metabox_enabled', $seo_signals_metabox_enabled );

                $style_select = htmlspecialchars( $_POST['style_select'] ?? 'default' );
                update_option( 'zynith_style_select', $style_select );

                echo '<div id="message" class="updated notice is-dismissible"><p>' . __( 'Signals metabox settings updated successfully.', ZYNITH_SEO_TEXT_DOMAIN ) . '</p></div>';
            } else {
                echo '<div id="message" class="error notice is-dismissible"><p>' . __( 'Signals metabox settings could not be saved.', ZYNITH_SEO_TEXT_DOMAIN ) . '</p></div>';
            }
        }
    
        // Get the current metabox status.
        $seo_signals_metabox_enabled = get_option( 'seo_signals_metabox_enabled', 'yes' );
        $is_metabox_enabled = (bool) ( $seo_signals_metabox_enabled === 'yes' );
        $style_select = get_option( 'zynith_style_select', 'default' );
    
        ?>
        <!-- Metabox toggle form -->
        <div class="wrap">
            <h2><?php _e( 'SEO Signals Metabox', ZYNITH_SEO_TEXT_DOMAIN ); ?></h2>

            <form method="post" action="">
                <?php wp_nonce_field( 'seo_toggle_metabox', 'seo_toggle_metabox_action' ); ?>
        
                <label for="seo_signals_metabox_enabled" style="margin: 0 22px 0 0;">
                    <input type="checkbox" name="seo_signals_metabox_enabled" id="seo_signals_metabox_enabled" <?php checked( $is_metabox_enabled ); ?>>
                    <?php _e( 'Enable SEO Signals Metabox', ZYNITH_SEO_TEXT_DOMAIN ); ?>
                </label><br><br>

                <label for="style_select">
                    <?php _e( 'Select Style:', ZYNITH_SEO_TEXT_DOMAIN ); ?>
                </label>

                <select name="style_select" id="style_select" style="margin: 0 0 0 11px;">
                    <option value="default" <?php selected($style_select, 'default'); ?>><?php _e( 'Default', ZYNITH_SEO_TEXT_DOMAIN ); ?></option>
                    <option value="dark" <?php selected($style_select, 'dark'); ?>><?php _e( 'Dark Mode', ZYNITH_SEO_TEXT_DOMAIN ); ?></option>
                    <option value="synthwave" <?php selected($style_select, 'synthwave'); ?>><?php _e( 'Synth Wave', ZYNITH_SEO_TEXT_DOMAIN ); ?></option>
                    <!-- Add more styles here -->
                </select>
        
                <p class="submit">
                    <input type="submit" name="toggle_metabox" id="toggle_metabox" class="button button-primary" value="<?php _e( 'Save', ZYNITH_SEO_TEXT_DOMAIN ); ?>">
                </p>
            </form>
        </div>

        <!-- Add a new form for the "Purge Zynith" button -->
		<form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
			<input type="hidden" name="action" value="purge_zynith_meta_keys">
			<?php wp_nonce_field( 'purge_zynith_meta_keys_action', 'purge_zynith_meta_keys_nonce' ); ?>

			<p class="submit">
				<input type="submit" name="purge_zynith" id="purge_zynith" class="button button-secondary" value="<?php _e( 'Purge Zynith', ZYNITH_SEO_TEXT_DOMAIN ); ?>" onclick="return confirm('<?php _e( 'Are you sure you want to purge Zynith meta keys? This cannot be undone.', ZYNITH_SEO_TEXT_DOMAIN ); ?>')">
			</p>
		</form>

        <div class="zynith-authors-box">
            <p><strong>Authors:</strong> This plugin was created by Schieler Mew, Kellie Watson, and Daniel S. Nielsen of Google SEO Mastermind.</p>
        </div>
        <?php
	}
	
    public function purge_zynith_meta_keys() {
        if ( ! isset( $_POST['purge_zynith_meta_keys_nonce'] ) || !wp_verify_nonce( $_POST['purge_zynith_meta_keys_nonce'], 'purge_zynith_meta_keys_action' ) ) {
            wp_die(__('Nonce verification failed.', ZYNITH_SEO_TEXT_DOMAIN));
        }

        global $wpdb;

        $meta_keys = [
            '_custom_meta_title',
            '_custom_meta_description',
            '_custom_noindex',
            '_custom_nofollow',
            '_custom_target_keyword',
            '_custom_schema',
        ];

        foreach ($meta_keys as $meta_key) {
            $wpdb->delete( $wpdb->postmeta, [ 'meta_key' => $meta_key ] );
        }

        $redirect_url = add_query_arg( 'zynith_purged', 'true', home_url( $_POST['_wp_http_referer'] ) );

        wp_redirect( $redirect_url );
        exit;
    }
	
}
