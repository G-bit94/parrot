<?php

class ZynithPostTypesOverview {

    public function __construct() {
        add_filter( 'manage_posts_columns', [ $this, 'add_meta_columns' ] );
        add_filter( 'manage_pages_columns', [ $this, 'add_meta_columns' ] );

        add_action( 'manage_posts_custom_column', [ $this, 'display_meta_columns' ], 10, 2 );
        add_action( 'manage_pages_custom_column', [ $this, 'display_meta_columns' ], 10, 2 );

        add_action( 'wp_ajax_save_meta_data', [ $this, 'save_meta_columns' ] );
    }

    public static function init() {
        return new self();
    }

    public function add_meta_columns( $columns ) {
        $columns['meta_title'] = __( 'Meta Title', ZYNITH_SEO_TEXT_DOMAIN );
        $columns['meta_description'] = __( 'Meta Description', ZYNITH_SEO_TEXT_DOMAIN );

        return $columns;
    }

    public function display_meta_columns( $column, $post_id ) {
        static $printed_inline_script = false;
    
        if ( !$printed_inline_script ) {
            $printed_inline_script = true;
            ?>
            <style>
            .editable {
                cursor: pointer;
                min-height: 19px;
                padding: 11px;
                width: 90%;
                font-size: 15px;
                box-shadow: 0 0 0 transparent;
                border-radius: 4px;
                border: 1px solid #a7aaaf;
                background-color: #fff;
                color: #2c3338;
            }
            </style>
            <script>
            jQuery(document).ready(function ($) {
                function save_meta_data(post_id, meta_key, meta_value) {
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'save_meta_data',
                            post_id: post_id,
                            meta_key: meta_key,
                            meta_value: meta_value,
                            nonce: customAdminScript.nonce
                        },
                        success: function (response) {
                            console.log(response);
                        },
                        error: function (error) {
                            console.error(error);
                        }
                    });
                }
    
                $('body').on('click', '.editable', function () {
                    var originalContent = $(this).text();
                    var post_id = $(this).data('post-id');
                    var meta_key = $(this).data('meta-key');
    
                    $(this).attr('contenteditable', 'true').focus().addClass('editing');
    
                    $(this).on('blur keydown', function (e) {
                        if (e.type === 'blur' || e.which === 13) {
                            e.preventDefault();
    
                            if ($(this).text() !== originalContent) {
                                save_meta_data(post_id, meta_key, $(this).text());
                            }
    
                            $(this).removeAttr('contenteditable').removeClass('editing');
                        }
                    });
                });
            });
            </script>
            <?php
        }
    
        switch ( $column ) {
            case 'meta_title':
                $meta_title = get_post_meta( $post_id, '_custom_meta_title', true );
                echo '<div class="editable" data-post-id="' . esc_attr( $post_id ) . '" data-meta-key="_custom_meta_title">' . esc_html( $meta_title ) . '</div>';
                break;
    
            case 'meta_description':
                $meta_description = get_post_meta( $post_id, '_custom_meta_description', true );
                echo '<div class="editable" data-post-id="' . esc_attr( $post_id ) . '" data-meta-key="_custom_meta_description">' . esc_html( $meta_description ) . '</div>';
                break;
        }
    }

    public function save_meta_columns() {
        check_ajax_referer( 'save_meta_data_nonce', 'nonce' );
    
        $post_id = intval( $_POST['post_id'] );
        $meta_key = sanitize_text_field( $_POST['meta_key'] );
        $meta_value = sanitize_text_field( $_POST['meta_value'] );
    
        update_post_meta( $post_id, $meta_key, $meta_value );
    
        wp_send_json_success( array(
            'message' => __( 'Meta data saved successfully.', ZYNITH_SEO_TEXT_DOMAIN )
        ) );
    }
    

}
