<?php

require_once( __DIR__ . '/autoload.php' );

if ( defined( 'ZYNITH_ENGINE_LOADED' ) ) {
    ZynithSettings::init();
    ZynithPostTypesOverview::init();
    ZynithMetaBoxes::init();
    ZynithImport::init();
    ZynithSitemap::init();
    ZynithContent::init();
}
