<?php

class ZynithSitemap {

    public function __construct() {
        add_action( 'zynith_seo_generate_sitemap', [ $this, 'generate_sitemap' ] );
        add_filter( 'cron_schedules', [ $this, 'add_schedules' ] );

        register_activation_hook( ZYNITH_SEO_FILE, [ $this, 'add_event' ] );
        register_deactivation_hook( ZYNITH_SEO_FILE, [ $this, 'remove_event' ] );
    }

    public static function init() {
        return new self();
    }

    public function add_schedules( $schedules ) {
		$custom_schedules = [
            'every_two_hours' => [
                'interval' => HOUR_IN_SECONDS * 2,
                'display' => __( 'Every Two Hours', ZYNITH_SEO_TEXT_DOMAIN )
            ]
        ];
		
        return array_merge( $schedules, $custom_schedules );
	}

    public function add_event() {
        if ( ! wp_next_scheduled( 'zynith_seo_generate_sitemap' ) ) {
            wp_schedule_event( time(), 'every_two_hours', 'zynith_seo_generate_sitemap' );
        }
    }

    public function remove_event() {
		wp_clear_scheduled_hook( 'zynith_seo_generate_sitemap' );
	}

    public function generate_sitemap() {
        $xml_file_path = ABSPATH . 'sitemap.xml';
        $xml_file_content = '';

        // Try to make the file writeable if it isn't already
        @touch( $xml_file_path );
        @chmod( $xml_file_path, 0664 );
    
        // Write the XML header
        $xml_file_content .= '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml_file_content .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
    
        // Generate URLs for public post types, categories, and authors
        $post_types = array_keys( ZynithPostTypes::get_post_types() );
        $taxonomies = [ 'category' ];

        // Authors are not a taxonomy, so we need to store them seperately
        $authors = [];
    
        foreach ( $post_types as $post_type ) {
            $args = [
                'post_type' => $post_type,
                'post_status' => 'publish',
                'numberposts' => -1
            ];
            
            $posts = get_posts( $args );

            if ( empty( $posts ) ) {
                continue;
            }
    
            foreach ( $posts as $post ) {
                $noindex = get_post_meta( $post->ID, '_custom_noindex', true );

                if ( $noindex === 'yes' || $noindex === true ) {
                    continue;
                }

                // If post is public, store the author ID
                $authors[ $post->post_author ] = $post->post_author;
                
                $url = htmlspecialchars( (string) get_permalink( $post ) );
                $date = get_the_date( 'Y-m-d\TH:i:sP', $post );

                $xml_file_content .= '  <url>' . "\n";
                $xml_file_content .= '    <loc>' . $url . '</loc>' . "\n";
                $xml_file_content .= '    <lastmod>' . $date . '</lastmod>' . "\n";
                $xml_file_content .= '  </url>' . "\n";
            }
        }
    
        foreach ( $taxonomies as $taxonomy ) {
            $terms = get_terms( [
                'taxonomy'   => $taxonomy,
                'hide_empty' => false,
            ] );

            if ( empty( $terms ) ) {
                continue;
            }
    
            foreach ( $terms as $term ) {
                $noindex = get_term_meta( $term->term_id, '_custom_noindex', true );

                if ( $noindex ) {
                    continue;
                }
                
                $url = htmlspecialchars( (string) get_term_link( $term->term_id, $taxonomy ) );

                $xml_file_content .= '  <url>' . "\n";
                $xml_file_content .= '    <loc>' . $url . '</loc>' . "\n";
                $xml_file_content .= '  </url>' . "\n";
            }
        }

        if ( ! empty( $authors ) ) {
            foreach ( $authors as $author_id ) {
                $url = htmlspecialchars( (string) get_author_posts_url( $author_id ) );

                $xml_file_content .= '  <url>' . "\n";
                $xml_file_content .= '    <loc>' . $url . '</loc>' . "\n";
                $xml_file_content .= '  </url>' . "\n";
            }
        }

        $xml_file_content .= '</urlset>'; // End Of File
    
        try {
            file_put_contents( $xml_file_path, $xml_file_content );
            delete_option( 'sitemap_error' );
        } catch( Exception $e ) {
            update_option( 'sitemap_error', $e->getMessage() );
        }
    }

}
