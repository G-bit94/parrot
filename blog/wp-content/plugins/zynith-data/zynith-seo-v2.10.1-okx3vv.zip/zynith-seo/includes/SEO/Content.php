<?php

class ZynithContent {

    public $post_types;

    public function __construct() {
        $this->post_types = array_keys( ZynithPostTypes::get_post_types() );

        add_action( 'wp_head', [ $this, 'output_meta_data' ], 1 );
        add_action( 'wp_head', [ $this, 'output_open_graph_image' ], 1 );
        add_action( 'wp_head', [ $this, 'output_canonical_url' ], 2 );

        add_filter( 'pre_get_document_title', [ $this, 'modify_document_title' ], 10 );

        add_filter( 'wp_robots', [ $this, 'modify_robots_meta' ] );
    }

    public static function init() {
        return new self();
    }

    public function output_meta_data() {
        if ( ! is_singular( $this->post_types ) ) {
            return;
        }

        $post = get_post();

        $meta_description = get_post_meta( $post->ID, '_custom_meta_description', true );
        $schema = get_post_meta( $post->ID, '_custom_schema', true );

        if ( ! empty( $meta_description ) ) {
            echo '<meta name="description" content="' . esc_attr( $meta_description ) . '">';
        }

        if ( ! empty( $schema ) ) {
            echo '<script type="application/ld+json">' . $schema . '</script>';
        }
    }

    public function output_canonical_url() {
        $canonical_url = null;

        if ( is_home() ) {
            $canonical_url = home_url();
        } elseif ( is_singular( $this->post_types ) ) {
            $post = get_post();

            $canonical_url = get_permalink( $post->ID );
        } elseif ( is_category() || is_tag() || is_tax() ) {
            $term = get_queried_object();

            if ( ! empty( $term->taxonomy ) ) {
                $canonical_url = get_term_link( $term->term_id, $term->taxonomy );
            }
        } elseif ( is_archive() ) {
            if ( is_date() ) {
                if ( is_day() ) {
                    $canonical_url = get_day_link( get_query_var('year'), get_query_var('monthnum'), get_query_var('day') );
                } elseif ( is_month() ) {
                    $canonical_url = get_month_link( get_query_var('year'), get_query_var('monthnum') );
                } elseif ( is_year() ) {
                    $canonical_url = get_year_link( get_query_var('year') );
                }
            } elseif ( is_author() ) {
                $canonical_url = get_author_posts_url( get_query_var('author'), get_query_var('author_name') );
            } elseif ( is_post_type_archive() ) {
                $canonical_url = get_post_type_archive_link( get_query_var('post_type') );
            }
        }

        if ( empty( $canonical_url ) ) {
            return;
        }

        echo '<link rel="canonical" href="' . esc_url( $canonical_url ) . '">';
    }

    public function modify_robots_meta( $directives ) {
        if ( ! is_singular( $this->post_types ) ) {
            return $directives;
        }

        $post = get_post();
    
        // If post is not found, simply return the default
        if ( empty( $post ) ) {
            return $directives;
        }
    
        $blog_public = (bool) get_option( 'blog_public' );
    
        // If the website is not public, return the default
        if ( ! $blog_public ) {
            return $directives;
        }
    
        $noindex = get_post_meta( $post->ID, '_custom_noindex', true );
        $nofollow = get_post_meta( $post->ID, '_custom_nofollow', true );
    
        // Now, we established that we're in a public post, and want to do our own robots meta. Unset whatever parameters you are modifying
        // unset( $directives['noindex'], $directives['nofollow'] );
    
        // If noindex is set, add it to the directives array
        if ( $noindex === 'yes' ) {
            $directives['noindex'] = true;
        }
    
        // If nofollow is set, add it to the directives array
        if ( $nofollow === 'yes' ) {
            $directives['nofollow'] = true;
        }
        
        // Always return the directives array, no matter the settings
        return $directives;
    }

    function output_open_graph_image() {
        if ( ! is_singular( $this->post_types ) ) {
            return;
        }

        $post = get_post();

        $og_image_url = get_post_meta( $post->ID, '_custom_meta_og_image', true );
    
        if ( ! empty( $og_image_url ) ) {
            echo '<meta property="og:image" content="' . esc_url( $og_image_url ) . '">';
        }
    }

    public function modify_document_title( $title ) {
        if ( ! is_singular( $this->post_types ) ) {
            return;
        }

        $post = get_post();
        
        $meta_title = get_post_meta( $post->ID, '_custom_meta_title', true );
        
		if ( ! empty( $meta_title ) ) {
            $title = esc_html( $meta_title );
        }
	
        return $title;
    }

}
