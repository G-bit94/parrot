<?php

// Stop all script execution if this file is accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Autoload Language
load_plugin_textdomain( ZYNITH_SEO_TEXT_DOMAIN, false, dirname( plugin_basename( ZYNITH_SEO_FILE ) ) . '/lang/' );

// Class Autoloader
class Zynith_Autoload {
    public $prefix = 'Zynith';

    public function __construct() {
        $files = $this->get_files();
        $includes = [];

        if ( ! empty( $files ) ) {
            foreach ( $files as $file ) {
                if ( strpos( $file, 'PostTypes.php' ) !== false ) {
                    array_unshift( $includes, $file );
                } else {
                    $includes[] = $file;
                }
            }

            foreach ( $includes as $file ) {
                include_once( $file );
            }
        }

        define( 'ZYNITH_ENGINE_LOADED', true );
    }

    public static function init() {
        return new self();
    }

    private function get_files() {
        return glob( __DIR__ . '/*/*.php', GLOB_NOSORT );
    }
}

// Autoload Classes used in this plugin
Zynith_Autoload::init();
