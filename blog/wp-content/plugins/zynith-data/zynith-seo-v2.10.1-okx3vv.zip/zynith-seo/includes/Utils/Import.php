<?php

class ZynithImport {

    public function __construct() {
        register_activation_hook( ZYNITH_SEO_FILE, [ $this, 'update_meta_data' ] );
    }

    public static function init() {
        return new self();
    }

    public function update_meta_data() {
        $posts = get_posts( [
            'post_type' => array_keys( ZynithPostTypes::get_post_types() ),
            'post_status' => 'publish',
            'numberposts' => -1,
        ] );

        if ( empty( $posts ) ) {
            return;
        }
        
        foreach ( $posts as $post ) {
            $this->update_post( $post->ID );
        }
	}

    private function update_post( $post_id ) {
        include_once(ABSPATH . 'wp-admin/includes/plugin.php');

        // Check if Yoast SEO, Rank Math, or All in One SEO is active
        $yoast_active = is_plugin_active( 'wordpress-seo/wp-seo.php' );
        $rank_math_active = is_plugin_active( 'seo-by-rank-math/rank-math.php' );
        $aioseo_active = is_plugin_active( 'all-in-one-seo-pack/all_in_one_seo_pack.php' );

        // If none of the SEO plugins are active, return early
        if ( !$yoast_active && !$rank_math_active && !$aioseo_active ) {
            return;
        }

        // Initialize metadata variables
        $meta_title = '';
        $meta_description = '';
        $target_keyword = '';
        $noindex = '';
        $nofollow = '';

        // Get the SEO metadata values based on which plugin is active
        if ( $yoast_active ) {
            $meta_title = get_post_meta($post_id, '_yoast_wpseo_title', true);
            $meta_description = get_post_meta($post_id, '_yoast_wpseo_metadesc', true);
            $target_keyword = get_post_meta($post_id, '_yoast_wpseo_focuskw', true);
            $noindex = get_post_meta($post_id, '_yoast_wpseo_meta-robots-noindex', true);
            $nofollow = get_post_meta($post_id, '_yoast_wpseo_meta-robots-nofollow', true);
        } elseif ( $rank_math_active ) {
            $meta_title = get_post_meta($post_id, 'rank_math_title', true);
            $meta_description = get_post_meta($post_id, 'rank_math_description', true);
            $target_keyword = get_post_meta($post_id, 'rank_math_focus_keyword', true);
            $noindex = get_post_meta($post_id, 'rank_math_robots', true) && in_array('noindex', get_post_meta($post_id, 'rank_math_robots', true)) ? 'yes' : 'no';
            $nofollow = get_post_meta($post_id, 'rank_math_robots', true) && in_array('nofollow', get_post_meta($post_id, 'rank_math_robots', true)) ? 'yes' : 'no';
        } elseif ( $aioseo_active ) {
            $meta_title = get_post_meta($post_id, '_aioseo_title', true);
            $meta_description = get_post_meta($post_id, '_aioseo_description', true);
            $target_keyword = get_post_meta($post_id, '_aioseo_keywords', true);
            $noindex = get_post_meta($post_id, '_aioseo_robots_noindex', true);
            $nofollow = get_post_meta($post_id, '_aioseo_robots_nofollow', true);
        }

        // If the custom meta fields are not set, use the available metadata value
        $meta_title = get_post_meta( $post_id, '_custom_meta_title', true ) ? get_post_meta( $post_id, '_custom_meta_title', true ) : $meta_title;
        $meta_description = get_post_meta( $post_id, '_custom_meta_description', true ) ? get_post_meta( $post_id, '_custom_meta_description', true ) : $meta_description;
        $noindex = get_post_meta( $post_id, '_custom_noindex', true ) ? get_post_meta( $post_id, '_custom_noindex', true ) : $noindex;
        $nofollow = get_post_meta( $post_id, '_custom_nofollow', true ) ? get_post_meta( $post_id, '_custom_nofollow', true ) : $nofollow;

        // Sanitize the custom fields
        $meta_title = sanitize_text_field( $meta_title );
        $meta_description = sanitize_textarea_field( $meta_description );
        $noindex = ( $noindex === true || $noindex === 'yes') ? 'yes' : 'no';
        $nofollow = ( $nofollow === true || $nofollow === 'yes' ) ? 'yes' : 'no';

        // Update the custom fields
        update_post_meta( $post_id, '_custom_meta_title', $meta_title );
        update_post_meta( $post_id, '_custom_meta_description', $meta_description );
        update_post_meta( $post_id, '_custom_noindex', $noindex );
        update_post_meta( $post_id, '_custom_nofollow', $nofollow );
        update_post_meta( $post_id, '_custom_target_keyword', $target_keyword );
    }

}
