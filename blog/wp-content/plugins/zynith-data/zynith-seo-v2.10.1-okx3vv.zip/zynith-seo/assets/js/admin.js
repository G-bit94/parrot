const SCHEMA = [{id: "insert_article_schema",value: `{
	"@context": "http://schema.org/",
	"@type": "Article",
	"headline": "Example Article",
	"datePublished": "2022-04-30T12:00:00Z",
	"dateModified": "2022-04-30T13:00:00Z",
	"author": {
		"@type": "Person",
		"name": "Jane Doe"
	},
	"image": "http://www.example.com/image.jpg",
	"description": "This is an example article."
},`},{id: "insert_creative_work_schema",value: `{
	"@context": "http://schema.org/",
	"@type": "Book",
	"name": "Example Book",
	"author": {
		"@type": "Person",
		"name": "Jane Doe"
	},
	"datePublished": "2022-04-30T12:00:00Z",
	"publisher": {
		"@type": "Organization",
		"name": "Example Publisher"
	}
},`},{id: "insert_event_schema",value: `{
	"@context": "http://schema.org/",
	"@type": "Event",
  	"name": "Example Event",
  	"startDate": "2022-05-01T09:00:00-07:00",
  	"endDate": "2022-05-01T17:00:00-07:00",
  	"location": {
		"@type": "Place",
		"name": "Example Venue",
		"address": {
	  		"@type": "PostalAddress",
	  		"streetAddress": "123 Main St",
	  		"addressLocality": "Exampleville",
	  		"addressRegion": "CA",
	  		"postalCode": "12345",
	  		"addressCountry": "US"
		}
  	}
},`},{id: "insert_faq_schema",value: `{
	"@context": "http://schema.org/",
  	"@type": "FAQPage",
  	"mainEntity": [
		{
			"@type": "Question",
		  	"name": "Example Question 1",
		  	"acceptedAnswer": {
				"@type": "Answer",
				"text": "This is an example answer to question 1."
		  	}
		},
		{
			"@type": "Question",
		  	"name": "Example Question 2",
		  	"acceptedAnswer": {
				"@type": "Answer",
				"text": "This is an example answer to question 2."
		  	}
		},
		{
			"@type": "Question",
		  	"name": "Example Question 3",
		  	"acceptedAnswer": {
				"@type": "Answer",
				"text": "This is an example answer to question 3."
		  	}
		}
	]
},`},{id: "insert_local_schema",value: `{
	"@context": "http://schema.org/",
	"@type": "LocalBusiness",
	"name": "Example Restaurant",
	"address": {
		"@type": "PostalAddress",
		"streetAddress": "123 Main St",
		"addressLocality": "Exampleville",
		"addressRegion": "CA",
		"postalCode": "12345",
		"addressCountry": "US"
	},
	"telephone": "+1-123-456-7890",
	"url": "http://www.example.com",
	"openingHours": [
		"Mo-Sa 11:00-23:00",
		"Su 12:00-21:00"
	],
	"aggregateRating": {
		"@type": "AggregateRating",
		"ratingValue": "4.5",
		"reviewCount": "100"
	}
}`},{id: "insert_person_schema",value: `{
	"@context": "http://schema.org/",
  	"@type": "Person",
  	"name": "Example Celebrity",
  	"jobTitle": "Actor",
  	"birthDate": "1970-01-01",
  	"gender": "http://schema.org/Male",
  	"image": "http://www.example.com/image.jpg",
  	"description": "This is an example celebrity."
},`},{id: "insert_place_schema",value: `{
	"@context": "http://schema.org/",
  	"@type": "LandmarksOrHistoricalBuildings",
  	"name": "Example Landmark",
  	"address": {
    	"@type": "PostalAddress",
    	"streetAddress": "123 Main St",
    	"addressLocality": "Exampleville",
    	"addressRegion": "CA",
    	"postalCode": "12345",
    	"addressCountry": "US"
	},
  	"geo": {
    	"@type": "GeoCoordinates",
    	"latitude": "37.1234",
    	"longitude": "-122.1234"
  	}
},`},{id: "insert_recipe_schema",value: `{
	"@context": "http://schema.org/",
	"@type": "Recipe",
	"name": "Example Recipe",
	"author": {
		"@type": "Person",
		"name": "Jane Doe"
	},
	"datePublished": "2022-04-30T12:00:00Z",
	"description": "This is an example recipe.",
	"image": "http://www.example.com/image.jpg",
	"recipeIngredient": [
		"2 cups flour",
		"1 cup sugar",
		"1/2 cup milk",
		"1/2 cup butter",
		"2 eggs",
		"1 tsp baking powder",
		"1/2 tsp baking soda",
		"1/2 tsp salt"
	],
	"recipeInstructions": [
		{
			"@type": "HowToStep",
		  	"text": "Preheat oven to 350°F."
		},
		{
		  	"@type": "HowToStep",
		  	"text": "In a large bowl, mix together flour, sugar, baking powder, baking soda, and salt."
		},
		{
		  	"@type": "HowToStep",
		  	"text": "In another bowl, beat eggs, then add milk and melted butter."
		},
		{
		  	"@type": "HowToStep",
		  	"text": "Add wet ingredients to dry ingredients, and mix until just combined."
		},
		{
		  	"@type": "HowToStep",
		  	"text": "Pour batter into a greased 9x9 inch baking dish."
		},
		{
		  	"@type": "HowToStep",
		  	"text": "Bake for 25-30 minutes, or until a toothpick inserted into the center comes out clean."
		}
	],
	"nutrition": {
		"@type": "NutritionInformation",
		"servingSize": "1 slice",
		"calories": "250",
		"fatContent": "9g",
		"carbohydrateContent": "38g",
		"proteinContent": "4g"
	}
},`},{id: "insert_review_schema",value: `{
	"@context": "http://schema.org/",
	"@type": "Review",
	"itemReviewed": {
		"@type": "Product",
		"name": "Example Product"
	},
	"reviewRating": {
		"@type": "Rating",
		"ratingValue": "4.5",
		"bestRating": "5",
		"worstRating": "1"
	},
	"author": {
		"@type": "Person",
		"name": "Jane Doe"
	},
	"datePublished": "2022-04-30T12:00:00Z",
	"description": "This is an example review."
},`},{id: "insert_video_schema",value: `{
	"@context": "http://schema.org/",
	"@type": "VideoObject",
	"name": "Example Video",
	"description": "This is an example video.",
	"thumbnailUrl": "http://www.example.com/thumbnail.jpg",
	"uploadDate": "2022-04-30T12:00:00Z",
	"duration": "PT2M30S",
	"publisher": {
		"@type": "Organization",
		"name": "Example Publisher"
	},
	"contentUrl": "http://www.example.com/video.mp4"
},`},{id: "insert_web_page_schema",value: `{
	"@context": "http://schema.org/",
	"@type": "WebPage",
	"name": "Example Web Page",
	"description": "This is an example web page.",
	"breadcrumb": [
		{
			"@type": "ListItem",
		  	"position": 1,
		  	"name": "Home",
		  	"item": "http://www.example.com"
		},
		{
			"@type": "ListItem",
		  	"position": 2,
		  	"name": "Category",
		  	"item": "http://www.example.com/category"
		},
		{
		  	"@type": "ListItem",
		  	"position": 3,
		  	"name": "Subcategory",
		  	"item": "http://www.example.com/category/subcategory"
		},
		{
		  	"@type": "ListItem",
		  	"position": 4,
		  	"name": "Current Page",
		  	"item": "http://www.example.com/category/subcategory/current-page"
		}
	]
},`}];
function toggle_schema(el_id) {
	let new_schema = "";
	if (document.getElementById(el_id).classList.contains("button_selected")) { document.getElementById(el_id).classList.remove("button_selected"); }
	else { document.getElementById(el_id).classList.add("button_selected"); }				
	for (let index = 0; index < SCHEMA.length; index++) {
		if (document.getElementById(SCHEMA[index].id).classList.contains("button_selected")) { new_schema += SCHEMA[index].value + "\n"; }
	}
	document.getElementById("custom_schema").value = new_schema;
}
function calculateKeywordDensity(content, keyword) {
	keyword = keyword.toLowerCase().trim();
	content = content.toLowerCase().replace(/<\/?[^>]+(>|$)/g, ""); // Strip HTML tags
	const wordCount = content.split(/\s+/).length;
	const keywordCount = content.split(keyword).length - 1;
	if (wordCount === 0) {
		return 0;
	}
	const density = (keywordCount / wordCount) * 100;
	return parseFloat(density.toFixed(2));
}
document.addEventListener("DOMContentLoaded", function() {
	var titleInput = document.getElementById("custom_meta_title");
    var descriptionInput = document.getElementById("custom_meta_description");
    var previewTitle = document.querySelector(".serp-preview-title");
    var previewDescription = document.querySelector(".serp-preview-description");
    titleInput.addEventListener("input", function() {
        var titleValue = titleInput.value.trim();
    	previewTitle.textContent = titleValue.length > 0 ? titleValue : "Page Title";
	});
	descriptionInput.addEventListener("input", function() {
    	var descriptionValue = descriptionInput.value.trim();
        previewDescription.textContent = descriptionValue.length > 0 ? descriptionValue : "Page description will appear here";
    });
	for (let index = 1; index <= 6; index++) {
		let el = document.getElementById("div_h" + index + "_heading");
		if (document.getElementById("div_h" + index + "_heading")) {
        	el.addEventListener("click", function() {
				if (this.classList.contains("heading_open")) {
                	this.classList.remove("heading_open");
                    this.classList.add("heading_closed");
                    this.querySelector("div > p").classList.remove("heading_open");
                    this.querySelector("div > p").classList.add("heading_closed");
				}
                else {
                    this.classList.remove("heading_closed");
					this.classList.add("heading_open");
                    this.querySelector("div > p").classList.remove("heading_closed");
                    this.querySelector("div > p").classList.add("heading_open");
				}
			});
		}
	}
});
jQuery(document).ready(function ($) {
	var custom_uploader;
    $("#custom_meta_og_image_button").click(function(e) {
        e.preventDefault();
        if (custom_uploader) {
            custom_uploader.open();
            return;
        }
        custom_uploader = wp.media.frames.file_frame = wp.media({
            title: og_image.title,
            button: {
                text: og_image.button
            },
            multiple: false
        });
        custom_uploader.on("select", function() {
            attachment = custom_uploader.state().get("selection").first().toJSON();
            $("#custom_meta_og_image").val(attachment.url);
        });
        custom_uploader.open();
    });
    // Function to update keyword density live
    function updateKeywordDensity() {
        const content = $("#content").val();
        const targetKeyword = $("#custom_target_keyword").val();
        const keywordDensity = calculateKeywordDensity(content, targetKeyword);
        $("#p_density").text("Keyword Density: " + keywordDensity + "%");
    }
    $("#content, #custom_target_keyword").on("input", updateKeywordDensity);
});
