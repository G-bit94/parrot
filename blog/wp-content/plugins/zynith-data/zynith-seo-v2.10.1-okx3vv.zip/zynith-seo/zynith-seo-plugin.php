<?php
/**
 * Plugin Name: Z Y N I T H
 * Plugin URI: https://www.facebook.com/groups/368478557332648
 * Description: Your one-stop plugin for elevating search engine rankings, driving traffic, and boosting conversions with streamlined on-page optimization tools and automatic sitemap updates!
 * Version: 2.10.1
 * Author: Google SEO Mastermind
 * Author URI: https://www.facebook.com/groups/368478557332648
 * License: GPL2
 */

/*`....... `..     `..      `..     `...     `..     `..     `... `......     `..     `..
       `..        `..    `..      `. `..   `..     `..          `..         `..     `..
      `..          `.. `..        `.. `..  `..     `..          `..         `..     `..
    `..              `..          `..  `.. `..     `..          `..         `...... `..
   `..               `..          `..   `. `..     `..          `..         `..     `..
 `..                 `..          `..    `. ..     `..          `..         `..     `..
`...........         `..          `..      `..     `..          `..         `..     `..
                                                                                       */

// Warning - Touching this code could lead to catastrophic failure!
// Schieler, Kellie, Daniel  

// Stop all script execution if this file is accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ZYNITH_SEO_FILE', __FILE__ );
define( 'ZYNITH_SEO_VERSION', '2.10.1' ); // Make sure this follows the actual version
define( 'ZYNITH_SEO_TEXT_DOMAIN', 'zynith-seo' );

// Initialize the plugin
require_once( __DIR__ . '/includes/init.php' );

// Add plugin action links
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'zynith_seo_action_links' );
function zynith_seo_action_links( $links ) {
	$links[] = '<a href="' . esc_url( admin_url( 'admin.php?page=seo-robots-txt-editor' ) ) . '">' . __( 'Settings', ZYNITH_SEO_TEXT_DOMAIN ) . '</a>';
	
	return $links;
}

// Add plugin meta links
add_filter( 'plugin_row_meta' , 'zynith_seo_meta_links', 10, 2 );
function zynith_seo_meta_links( $plugin_meta, $plugin_file ) {
	if ( $plugin_file === plugin_basename( ZYNITH_SEO_FILE ) ) {
		$plugin_version_style = 'background: #708090; color: #fff; padding: 4px 8px 6px; border-radius: 4px; user-select: none';
		$author_link_style = 'background-color: #2d80ea; background-image: linear-gradient(to right, #0476e6, #ff09ff); color: #fff; font-weight: 500; padding: 4px 8px 6px; border-radius: 4px;';
		
		$plugin_meta = [
			'<span style="' . esc_attr( $plugin_version_style ) . '">' . __( 'Version', ZYNITH_SEO_TEXT_DOMAIN ) . ' ' . ZYNITH_SEO_VERSION . '</span>
			<a href="https://www.facebook.com/groups/368478557332648" target="_blank" style="' . esc_attr( $author_link_style ) . '"><span class="dashicons dashicons-external"></span> ' . __( 'Google SEO Mastermind', ZYNITH_SEO_TEXT_DOMAIN ) . '</a>',
		];
	}
     
    return $plugin_meta;
}

// Let's keep this file relatively clean
